build       : source checkout (v0.2.0, no VENDOR.json)
source      : PJ14PD20260423284-当前处理人-USER-B6524D-Open-全部-19条.csv
rows        : 19
columns     : 15

-- contract fields --
  [OK  ] defectId     <- 缺陷单号           'BGCM2026110304188'
  [OK  ] title        <- 缺陷标题           '[键盘管理] 本地operator登录主机web，进入用户管理界面，界面一直显示Please w'
  [OK  ] description  <- 缺陷描述           '用例名称：退出安装模式成功_键盘密码输入前置条件：主机已进入安装模式操作步骤：1、键盘点击退出安'
  [OK  ] status       <- 缺陷状态           'Open'
  [MISS] flowStatus   <- (none)         ''
  [OK  ] testModule   <- 测试模块           '键盘管理'
  [OK  ] fieldType    <- 缺陷类型           '缺陷'
  [OK  ] severity     <- 严重级别           '中'
  [OK  ] createdAt    <- 创建时间           '2026-11-03 15:29:11'
  [MISS] duplicateOf  <- (none)         ''

-- unplaced columns (7) --
  当前处理人: 'USER-B6524D'
  当前处理人姓名: 'USER-4B77D1'
  检出活动: '系统测试'
  测试申请单: 'PJ14PD20260423284G01'
  提交人: 'USER-4B5AFC'
  创建日期: '2026-11-03'
  流程实例ID: '1344962884'

-- content --
  rows mappable (id+title) : 19/19
  description present      : 19/19
  description is an unfilled template : 0/19
  testModule present       : 19/19
  testModule semantic-free : 0/19 (0%)  <- 无产品语义的模块名（【公共】/用例集/系统…）
  distinct modules (L1)    : 9

-- verdict --
  looks healthy: rows map, description present, module present

-- module distribution (top 8) --
     8  网络设备管理
     2  CRA安全认证（设备需求）
     2  遥控器管理
     2  CRA安全认证（WEB需求）
     1  键盘管理
     1  报警复核(25Q4)
     1  继电器管理
     1  多语言


