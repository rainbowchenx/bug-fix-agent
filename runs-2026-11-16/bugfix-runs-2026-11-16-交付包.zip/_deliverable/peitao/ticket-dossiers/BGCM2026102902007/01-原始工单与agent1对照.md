# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102902007",
  "缺陷标题": "[遥控器管理] 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触",
  "缺陷状态": "Open",
  "当前处理人": "USER-B6524D,USER-65C153",
  "当前处理人姓名": "USER-4B77D1,USER-D3611A",
  "严重级别": "低",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "遥控器管理",
  "测试申请单": "PJ14PD20260423284G01",
  "提交人": "USER-96B947",
  "创建时间": "2026-10-29 11:48:29",
  "创建日期": "2026-10-29",
  "流程实例ID": "1336156660",
  "缺陷描述": "用例名称：设置按键功能成功_撤防及多个子系统关联前置条件：操作步骤：1、设置遥控器的按键I为以下功能，按键操作，查看结果测试数据：撤防（Disarm）、关联中间任意多个子系统预期结果：1、设置成功2、可以通过该按键对主机进行所配置的操作成功实际结果：遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触问题：1.遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102902007",
  "title": "[遥控器管理] 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触",
  "pool": "strict",
  "clusterId": "PJ14PD20260423284::遥控器管理::遥控器管理::config",
  "testModule": "遥控器管理",
  "titleTag": "遥控器管理",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触",
  "expected": "1、设置成功2、可以通过该按键对主机进行所配置的操作成功",
  "steps": "1、设置遥控器的按键I为以下功能，按键操作，查看结果",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-10-29 11:48:29",
  "duplicate": false,
  "semanticFree": false,
  "priority": 6.0,
  "revisionId": "BGCM2026102902007:v0",
  "sourceObserved": "遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触",
  "sourceExpected": "1、设置成功2、可以通过该按键对主机进行所配置的操作成功",
  "sourceSteps": "1、设置遥控器的按键I为以下功能，按键操作，查看结果",
  "attachmentRefs": null
}
```
