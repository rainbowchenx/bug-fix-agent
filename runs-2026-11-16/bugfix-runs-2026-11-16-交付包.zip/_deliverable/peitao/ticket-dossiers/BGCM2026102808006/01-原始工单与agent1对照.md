# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102808006",
  "缺陷标题": "[遥控器管理] 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项",
  "缺陷状态": "Open",
  "当前处理人": "USER_BV",
  "当前处理人姓名": "USER_AD",
  "严重级别": "中",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "遥控器管理",
  "测试申请单": "PJ14PD20260423284G01",
  "提交人": "USER_W",
  "创建时间": "2026-10-28 16:24:50",
  "创建日期": "2026-10-28",
  "流程实例ID": "1334562712",
  "缺陷描述": "用例名称：设置继电器操作失败_AutomationControl前置条件：遥控器关联用户无AutomationControl操作步骤：1、设置遥控器的按键I为以下功能，按键操作，查看结果测试数据：操作继电器（AutomationControl）预期结果：1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器实际结果：遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项问题：遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项https://zero.hikvision.com.cn/pagespy/#/replay?url=https://zero.hikvision.com.cn/pagespy/api/v1/log/download?fileId=local.74ddd59efa8ec8c0e7a197ec8d0b0787  "
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102808006",
  "title": "[遥控器管理] 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项",
  "pool": "strict",
  "clusterId": "PJ14PD20260423284::遥控器管理::遥控器管理::config",
  "testModule": "遥控器管理",
  "titleTag": "遥控器管理",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项",
  "expected": "1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器",
  "steps": "1、设置遥控器的按键I为以下功能，按键操作，查看结果",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-28 16:24:50",
  "duplicate": false,
  "semanticFree": false,
  "priority": 2.0,
  "revisionId": "BGCM2026102808006:v0",
  "sourceObserved": "遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项",
  "sourceExpected": "1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器",
  "sourceSteps": "1、设置遥控器的按键I为以下功能，按键操作，查看结果",
  "attachmentRefs": null
}
```
