# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102808455",
  "缺陷标题": "[多语言] 多语言中存在日志内容未翻译，显示的是英语",
  "缺陷状态": "Open",
  "当前处理人": "USER-B6524D,USER-B25DAC",
  "当前处理人姓名": "USER-4B77D1,USER-0FF63C",
  "严重级别": "中",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "多语言",
  "测试申请单": "PJ14PD20260423284G01",
  "提交人": "USER-96B947",
  "创建时间": "2026-10-28 16:43:20",
  "创建日期": "2026-10-28",
  "流程实例ID": "1334654666",
  "缺陷描述": "用例名称：导出多语言日志成功_内容一致翻译正确前置条件：操作步骤：1、不同语言版本的日志导出，查看内容测试数据：预期结果：1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确实际结果：多语言中存在日志内容未翻译，显示的是英语问题：1. "
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102808455",
  "title": "[多语言] 多语言中存在日志内容未翻译，显示的是英语",
  "pool": "strict",
  "clusterId": "PJ14PD20260423284::多语言::多语言::i18n",
  "testModule": "多语言",
  "titleTag": "多语言",
  "intent": "i18n",
  "intentSource": "heuristic",
  "intentConfidence": "high",
  "intentRationale": "i18n keywords",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "多语言中存在日志内容未翻译，显示的是英语",
  "expected": "1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确",
  "steps": "1、不同语言版本的日志导出，查看内容",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-28 16:43:20",
  "duplicate": false,
  "semanticFree": false,
  "priority": 3.0,
  "revisionId": "BGCM2026102808455:v0",
  "sourceObserved": "多语言中存在日志内容未翻译，显示的是英语",
  "sourceExpected": "1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确",
  "sourceSteps": "1、不同语言版本的日志导出，查看内容",
  "attachmentRefs": null
}
```
