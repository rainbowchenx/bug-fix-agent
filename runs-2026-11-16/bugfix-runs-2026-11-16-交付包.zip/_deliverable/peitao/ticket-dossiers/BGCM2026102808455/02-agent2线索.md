# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102808455",
  "clusterId": "PJ14PD20260423284::多语言::多语言::i18n",
  "title": "[多语言] 多语言中存在日志内容未翻译，显示的是英语",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/view/operations/maintain/maintainLog/pc/maintainLog.vue",
      "symbol": null,
      "why": "日志列表/导出页: 表头用 I18n.t 翻译, 但 mainType/subType/object/addiInfo 等日志内容取设备原始英文值, 未翻译内容在此渲染",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/view/operations/maintain/maintainLog/mixin.js",
      "symbol": null,
      "why": "日志数据获取与字段组装公共逻辑, 日志枚举值到语言包的映射缺失处",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/view/operations/maintain/maintainLog/mobile/component/logDetail.vue",
      "symbol": null,
      "why": "移动端日志详情直接展示 logDetailsData.mainType/subType/param 原始值, 无 $t 映射",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
