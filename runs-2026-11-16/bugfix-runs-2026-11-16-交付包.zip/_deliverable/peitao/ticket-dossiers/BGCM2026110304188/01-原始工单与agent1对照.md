# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026110304188",
  "缺陷标题": "[键盘管理] 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.",
  "缺陷状态": "Open",
  "当前处理人": "USER-B6524D",
  "当前处理人姓名": "USER-4B77D1",
  "严重级别": "中",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "键盘管理",
  "测试申请单": "PJ14PD20260423284G01",
  "提交人": "USER-4B5AFC",
  "创建时间": "2026-11-03 15:29:11",
  "创建日期": "2026-11-03",
  "流程实例ID": "1344962884",
  "缺陷描述": "用例名称：退出安装模式成功_键盘密码输入前置条件：主机已进入安装模式操作步骤：1、键盘点击退出安装模式按钮，使用以下方式校验权限，查看结果测试数据：Operator键盘密码输入预期结果：1、退出安装模式成功，键盘有操作成功的提示实际结果：本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.问题：1.本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.web调试路径：https://zero.hikvision.com.cn/pagespy/#/replay?url=https://zero.hikvision.com.cn/pagespy/api/v1/log/download?fileId=local.d166abf3c98a0eb29707205ab85a98e1"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026110304188",
  "title": "[键盘管理] 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.",
  "pool": "strict",
  "clusterId": "PJ14PD20260423284::键盘管理::键盘管理::config",
  "testModule": "键盘管理",
  "titleTag": "键盘管理",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.",
  "expected": "1、退出安装模式成功，键盘有操作成功的提示",
  "steps": "1、键盘点击退出安装模式按钮，使用以下方式校验权限，查看结果",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-11-03 15:29:11",
  "duplicate": false,
  "semanticFree": false,
  "priority": 17.0,
  "revisionId": "BGCM2026110304188:v0",
  "sourceObserved": "本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.",
  "sourceExpected": "1、退出安装模式成功，键盘有操作成功的提示",
  "sourceSteps": "1、键盘点击退出安装模式按钮，使用以下方式校验权限，查看结果",
  "attachmentRefs": null
}
```
