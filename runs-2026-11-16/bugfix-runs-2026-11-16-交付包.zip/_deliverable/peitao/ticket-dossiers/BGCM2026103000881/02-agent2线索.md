# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026103000881",
  "clusterId": "PJ14PD20260423284::网络设备管理::网络设备管理::config",
  "title": "[网络设备管理] 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/view/device/ipc/pc/ipcChannelSet.vue",
      "symbol": "save",
      "why": "IPC 参数页保存入口: save 依次 modifyIpcName + 各通道 getAjax, 保存失败经 Response.saveState 提示 Operating failed",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/view/device/ipc/pc/component/singleChannelConfig.vue",
      "symbol": null,
      "why": "单通道参数表单与 getAjax 请求组装(编码/事件/防区), Onvif IPC 保存报错的具体下发参数来源",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/view/device/ipc/otap.js",
      "symbol": null,
      "why": "IPC 通道相关 CGI 封装(setSingleVideoBasicInfo/getVideoCodingParams 等)",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
