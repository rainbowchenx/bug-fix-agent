# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026103000881",
  "缺陷标题": "[网络设备管理] 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.",
  "缺陷状态": "Open",
  "当前处理人": "USER_AS,USER_BV",
  "当前处理人姓名": "USER_CJ,USER_AD",
  "严重级别": "中",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "网络设备管理",
  "测试申请单": "PJ14PD20260423284G01",
  "提交人": "USER_AT",
  "创建时间": "2026-10-30 10:12:44",
  "创建日期": "2026-10-30",
  "流程实例ID": "1338177500",
  "缺陷描述": "用例名称：配置IPC码率类型失败前置条件：通过Onvif协议接入IPC操作步骤：1、配置IPC码率类型测试数据：预期结果：1.无法配置码率类型实际结果：主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.问题：https://zero.hikvision.com.cn/pagespy/#/replay?url=https://zero.hikvision.com.cn/pagespy/api/v1/log/download?fileId=local.832f4c0c3da1c7a5e23a37951108c1e7"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026103000881",
  "title": "[网络设备管理] 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.",
  "pool": "strict",
  "clusterId": "PJ14PD20260423284::网络设备管理::网络设备管理::config",
  "testModule": "网络设备管理",
  "titleTag": "网络设备管理",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.",
  "expected": "1.无法配置码率类型",
  "steps": "1、配置IPC码率类型",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-30 10:12:44",
  "duplicate": false,
  "semanticFree": false,
  "priority": 9.0,
  "revisionId": "BGCM2026103000881:v0",
  "sourceObserved": "主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.",
  "sourceExpected": "1.无法配置码率类型",
  "sourceSteps": "1、配置IPC码率类型",
  "attachmentRefs": null
}
```
