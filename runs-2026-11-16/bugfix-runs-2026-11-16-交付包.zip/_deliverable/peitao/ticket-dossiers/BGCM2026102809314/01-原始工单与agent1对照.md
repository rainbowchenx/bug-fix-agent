# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102809314",
  "缺陷标题": "[CRA安全认证（WEB需求）] 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）",
  "缺陷状态": "Open",
  "当前处理人": "USER_BV",
  "当前处理人姓名": "USER_AD",
  "严重级别": "中",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "CRA安全认证（WEB需求）",
  "测试申请单": "PJ14PD20260423284G01",
  "提交人": "USER_BX",
  "创建时间": "2026-10-28 17:58:57",
  "创建日期": "2026-10-28",
  "流程实例ID": "1334990604",
  "缺陷描述": "用例名称：验证使能Auto Check for Upgrades按钮弹出确认提示前置条件：操作步骤：1. web端进入Maintenance and Security—Maintenance—Upgrade Control Panel 2. 使能Auto Check for Upgrades按钮测试数据：预期结果：1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”实际结果：交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）问题：1.交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102809314",
  "title": "[CRA安全认证（WEB需求）] 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）",
  "pool": "strict",
  "clusterId": "PJ14PD20260423284::CRA安全认证（WEB需求）::CRA安全认证（WEB需求）::unclear",
  "testModule": "CRA安全认证（WEB需求）",
  "titleTag": "CRA安全认证（WEB需求）",
  "intent": "unclear",
  "intentSource": "unclear",
  "intentConfidence": "low",
  "intentRationale": "no strong intent signal",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）",
  "expected": "1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”",
  "steps": "1. web端进入Maintenance and Security—Maintenance—Upgrade Control Panel 2. 使能Auto Check for Upgrades按钮",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-28 17:58:57",
  "duplicate": false,
  "semanticFree": false,
  "priority": 4.0,
  "revisionId": "BGCM2026102809314:v0",
  "sourceObserved": "交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）",
  "sourceExpected": "1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”",
  "sourceSteps": "1. web端进入Maintenance and Security—Maintenance—Upgrade Control Panel 2. 使能Auto Check for Upgrades按钮",
  "attachmentRefs": null
}
```
