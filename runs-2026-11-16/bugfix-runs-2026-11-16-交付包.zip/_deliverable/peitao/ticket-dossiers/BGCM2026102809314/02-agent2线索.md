# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102809314",
  "clusterId": "PJ14PD20260423284::CRA安全认证（WEB需求）::CRA安全认证（WEB需求）::unclear",
  "title": "[CRA安全认证（WEB需求）] 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/view/operations/maintain/upgrade/pc/upgrade.vue",
      "symbol": null,
      "why": "auto check for upgrade 开关(fields 中 autoDetectionEnabled switch)与\"检查更新\"按钮都在此页, 显示不统一的统一处",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/view/operations/maintain/detectorAndPeripheral/pc/components/localOnlineUpdate.vue",
      "symbol": null,
      "why": "子设备在线升级页同款 auto-check 开关 + check update 按钮, 需一并统一的页面",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/view/operations/maintain/upgradeConfig/otap.js",
      "symbol": "getAutoUpgradeCfg",
      "why": "自动升级配置协议(AutoUpgradeCfg get/set), 服务端配置项与 UI 显隐的数据源",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
