# peitao（peitao 报警（device_web））Agent-3 批次评测报告

> 依据 docs/field-eval/agent3/templates/batch-evaluation-report.md 填写；本批只到报告路径（applyFix=false），所有「应用/验收」栏按 N/A 记。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 | runs-2026-11-16/peitao / 2026-11-16 |
| Agent-3 commit / 模型 | 90e4744 / EB-GLM-Pro（Claude Agent SDK） |
| 运行模式 | analyze_mode=sdk，applyFix=false（只出报告），max_turns=24 |
| Agent-1 样本 | 19 条（strict 18 / locatable 1） |
| Agent-2 | enrich=sdk 22 turns $1.44，19/19 有候选 |
| 产物目录 | runs-2026-11-16/peitao/{01-agent1,02-agent2,03-agent3,ticket-dossiers} |

## 2. 样本与验收覆盖

Agent-3 深度分析：6 票（选样见 03-agent3/cases.json）。原批 19 条。

| 样本类别 | 数量 |
|---|---|
| 清晰且当前仓可修（进入 Agent-3） | 6 |
| plan_only 报告产出 | 见 03-agent3/analysis-report.json summary |
| 实际应用补丁 | 0（本批禁止改码） |
| 业务验收 | 0（N/A） |

## 3. 质量指标

| 指标 | n/N | 说明 |
|---|---|---|
| 报告覆盖 | 6/6 | 全部落盘（含诚实阻断票） |
| G0（过程真实） | FAIL | G0=FAIL（1 票 sdk_fallback）loc@1=6/6 loc@3=6/6 outcome=5/6 verdict=process_fail |
| loc@1 / loc@3 | 见 score.json | 6/6 定位全中（含宽前缀票收敛到具体组件）；唯一失败是 BGCM2026102809314 一轮 SDK 会话无 JSON 产出 |
| outcome 一致 | total 6：plan_only 5 / other_blocked 1 | applyFix=false 下可修票只允许 plan_only |
| 补丁应用/验收 | N/A | 本批禁止实际修复 |

## 4. 成本

Agent-2 $1.44；Agent-3 单票 SDK 会话（EB-GLM-Pro），二轮案例另跑一次

## 5. 逐票结果

见 [ticket-review-summary.csv](03-agent3/ticket-review-summary.csv)；逐票档案见 ticket-dossiers/（01 原始对照 / 02 Agent-2 线索 / 03 Claude 过程 / 04 修改与复核）。

## 6. 代表案例

### 成功案例
BGCM2026102808455 maintainLog i18n：三端（pc/mixin/mobile）定位+机制全对；BGCM2026110304188 userManage totalMatches 竞态：mixin.js:367/394/421 命中

### 失败或截断案例
BGCM2026102809314 auto check for upgrade：一轮 sdk_fallback（诚实 other_blocked）；二轮补充后产出 before-change 钩子链断裂机制

### 二次修复案例
有（05-二轮修复.md）：一轮 other_blocked → 用户交互稿补充 → 二轮推翻「移除按钮」表面结论，重查得出 common-form 无 before-change 实现的深层机制

## 7. 环节归因与改进

| 环节 | 问题及票ID | 建议 |
|---|---|---|
| Agent-3 分析 | BGCM2026102809314 一轮 sdk_fallback | SDK 会话末尾 JSON 解析鲁棒性（已在 90e4744 修复链上） |

## 8. 结论

- G0=FAIL（1 票 sdk_fallback）loc@1=6/6 loc@3=6/6 outcome=5/6 verdict=process_fail
- 详细机器评分见 03-agent3/score.json；人工根因评分（G3）已填入 ticket-review-summary.csv manualRootCauseScore 列。