# runs-2026-11-16 交付包说明

三 Agent 缺陷分析工作流（Agent-1 → Agent-2 → Agent-3）在 4 个真实产品线上的运行与评测产物。
Agent-3 只出报告（applyFix=false 全程生效，无一处改码）。运行日期 2026-11-16，架构 commit 90e4744。

## 顶层

- `最终结果报告.md` — 四仓总览、逐仓要点、横向观察、二轮案例摘要。**从这里看起。**
- `<产品线>/` — peitao（报警 device_web）/ transport（交通 device_web）/ hcp（3.2 微前端）/ led（校正 electron 双仓）

## 每仓目录与要求对应关系

| 目录/文件 | 内容 | 对应要求 |
|---|---|---|
| `00-原始工单与agent1/` | 原始工单 CSV 原样拷贝、Agent-1 产物（defect-batch.json 全量 + defect-batch-6.json 六票选样 + preflight.md） | ① 原始工单 vs Agent-1 条目（信息丢失检查）的**数据源** |
| `01-agent2/` | code-knowledge.json（候选与调查理由）+ cartography-说明.md（**本次注入了哪些 skill**、turns/成本、触顶情况） | ② Agent-2 分析 + skill 注入说明的**数据源** |
| `02-agent3报告/` | analysis-report.json（六票正式报告）+ cases.json（grep 真值定义） | ④ 修改判断的**数据源** |
| `ticket-review-summary.csv` | 六票逐票评分表：outcome、loc@1/loc@3、G0、首候选、**人工根因评分（G3）与备注** | 评测汇总 |
| `batch-evaluation-report.md` | 按 `docs/field-eval/agent3/templates/batch-evaluation-report.md` 填写的批次报告 | 评测报告 |
| `ticket-dossiers/<缺陷ID>/` | 逐票档案，只含进入 Agent-3 的 6 票 | 见下 |

## ticket-dossiers 逐票档案（每仓 6 票）

| 文件 | 内容 | 对应要求 |
|---|---|---|
| `01-原始工单与agent1对照.md` | 原始描述/步骤/测试数据 vs defect-batch 条目逐字段对照，信息丢失点标注 | ① |
| `02-agent2线索.md` | 该票的 Agent-2 候选、调查理由、调用关系 | ② |
| `03-claude过程与agent3结果.md` | SDK 会话摘录：resolution、sessionId、机制主张、代码关联、证据（工具观察）、开放问题、编辑决策 | ③ Claude 实际过程 |
| `04-修改与结果.md` | plan_only 建议落点、根因主张、**人工 grep 复核逐条标注（已验证/部分验证/无法评估）**、结论 | ④ 最终修改与结果（未验证如实标注） |
| `05-二轮修复.md` | 仅 peitao/BGCM2026102809314：一轮失败 → 用户补充（交互稿） → 二轮推翻「移除按钮」表面结论重查深层机制 | ⑤ 用户补充后的再修复案例 |

## 数据脱敏

人员标识字段（当前处理人 / 当前处理人姓名 / 提交人 / 解决人 / 发现人）**全部保留**，仅把真实姓名与工号替换为可读代称 `USER_A`、`USER_B` … `USER_DC`：

- 同一真人在全包内映射到同一代称，跨票对照关系仍可追踪
- 多人字段保持逗号分隔形式，如 `USER_AL,USER_BE`
- 缺陷单号、标题、步骤、期望等业务内容原样保留，不影响信息丢失检查
- 原始工单 CSV 的行数与列数未变（各仓 19 / 37 / 26+11 / 137 行）
- 扫描核验：全包 0 处真实人员标识残留

## 已知口径与限制

- **③ 的局限**：`03-claude过程与agent3结果.md` 呈现的是 attempt.json 提取的最终主张（它最终信了什么），「Agent-2 线索 → 采纳/推翻/重查」的逐票显式对比未铺满 24 票（跑偏票在 04 的人工复核里做过）；SDK 原始会话可用 03 档案里的 sessionId 回溯。
- skill 注入说明在仓级（cartography-说明.md），未逐票列出；hcp 的关键发现：仓内 use-hui-intl 业务 skill 缺 `profiles` frontmatter，**未被注入**。
- G3 人工评分为本人（运行者）判定，依据见各 04 档案的复核记录。
- cases.json 的 expectPathPrefix 为 grep 复核的真值口径；hcp 有 2 票真值前缀过窄（详见 hcp/batch-evaluation-report.md）。

## 原始完整产物

本包为整理后的交付视图。全量运行产物（含 Agent-2 run.log、attempt 明细、score.json 等）在
`runs-2026-11-16/` 源目录，结构见其 `README.md`。
