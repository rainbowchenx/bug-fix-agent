# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026051104084",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::data_wrong",
  "title": "[LED Tool-校正工具] 每次重新打开校正工具，环境准备-画面显示页面没有回读屏幕自检颜色，默认选择红色",
  "candidates": [
    {
      "repoPath": "calibrationtool",
      "path": "web/src/stores/modules/projectDetail/environmentInfo.ts",
      "symbol": "getAllSendCardInfoByScreen",
      "why": "重新进入时唯一做屏幕颜色回读的位置：getTestSingleCfg -> colorMap[LEDTestSignalType] -> cameraInfoStore.data.screenColor 并 updateData；映射/时序不对就会退回非回读值",
      "source": "codegraph"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/views/config/EnvironmentPrep.vue",
      "symbol": "onMounted -> getAllSendCardInfoByScreen",
      "why": "环境准备页挂载时触发上述回读；票面点名「环境准备-画面显示页面」即此页的生命周期入口",
      "source": "grep"
    },
    {
      "repoPath": "calibrationtool",
      "path": "electron/electron/controller/projectDetail/index.ts",
      "symbol": "getTestSingleCfg",
      "why": "回读数据的来源接口：转发 /getTestSingleCfg 并原样返回 LED Tool 响应，LEDTestSignalType 的取值结构由这里透传",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null
}
```
