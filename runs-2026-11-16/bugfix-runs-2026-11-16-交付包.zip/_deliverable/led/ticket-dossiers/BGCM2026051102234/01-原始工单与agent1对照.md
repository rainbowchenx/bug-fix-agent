# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "单号": "BGCM2026051102234",
  "标题": "[LED Tool-校正工具] 分区配置界面“切换至手动配置分区模式”按钮名称与UI不一致",
  "状态": "Closed",
  "流程状态": "已结束",
  "当前处理人": "",
  "当前处理人姓名": "",
  "解决人": "USER_AR",
  "解决人姓名": "吕晨阳6",
  "级别": "低",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "发现人": "USER_BM",
  "模块": "结构,校正工具,接收卡",
  "所属软件名": "PBI25033102",
  "版本": "V200R001C001",
  "产品线": "LED",
  "产品系列": "LED配套产品",
  "产品型号": "DS-DT60C-03HDPDI20NO/U",
  "测试申请单": "PJ01PD20251231223G01",
  "创建时间": "2026-05-11 15:32:12",
  "解决时间": "2026-05-20",
  "结束时间": "2026-05-28",
  "缺陷描述": "用例名称：切换手动配置分区模式前置条件：开启全屏校正-亮色度校正操作步骤：1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、在分区配置界面按测试数据操作测试数据：切换手动配置分区模式预期结果：切换手动配置后出现手动配置分区数入口实际结果：“切换至手动配置分区模式”按钮名称与UI不一致问题：1.UI是：切换至手动配置分区模式，实际客户端是：切换至手动分区配置模式"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026051102234",
  "title": "[LED Tool-校正工具] 分区配置界面“切换至手动配置分区模式”按钮名称与UI不一致",
  "pool": "strict",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::ui_layout",
  "testModule": "结构,校正工具,接收卡",
  "titleTag": "LED Tool-校正工具",
  "intent": "ui_layout",
  "intentSource": "ai",
  "intentConfidence": "high",
  "intentRationale": "问题栏说明 UI 文案为「切换至手动配置分区模式」、客户端为「切换至手动分区配置模式」，是界面文案与 UI 规范不一致，不是数据错误",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "“切换至手动配置分区模式”按钮名称与UI不一致",
  "expected": "切换手动配置后出现手动配置分区数入口",
  "steps": "1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、在分区配置界面按测试数据操作",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-05-11 15:32:12",
  "duplicate": false,
  "semanticFree": false,
  "priority": 0.0
}
```
