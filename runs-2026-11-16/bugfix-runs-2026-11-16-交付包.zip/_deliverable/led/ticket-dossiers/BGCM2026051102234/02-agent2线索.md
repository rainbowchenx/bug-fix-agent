# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026051102234",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::ui_layout",
  "title": "[LED Tool-校正工具] 分区配置界面“切换至手动配置分区模式”按钮名称与UI不一致",
  "candidates": [
    {
      "repoPath": "calibrationtool",
      "path": "web/src/views/config/PartitionConfig.vue",
      "symbol": "autoOrManual / toggleManualConfig",
      "why": "分区配置页的手动/自动切换行（manual-config-row, 行 484-489）在 isManualConfig=false 时渲染 switchToManual.name；标题说的按钮即此处文字",
      "source": "grep"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/i18n/zh_CN/projectDetail.json",
      "symbol": "CalibrationTool.projectDetail.partitionConfig.switchToManual.name",
      "why": "第 50 行值为「切换至手动配置分区模式」，与票面 UI 规范的「切换至手动分区配置模式」不一致，是按钮名称的直接来源",
      "source": "grep"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/i18n/en_US/projectDetail.json",
      "symbol": "CalibrationTool.projectDetail.partitionConfig.switchToManual.name",
      "why": "同一 key 的英文资源，改中文文案时需同步核对英文措辞（Switch to manual partition configuration mode）",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null
}
```
