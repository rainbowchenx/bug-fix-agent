# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026051103043",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::ui_layout",
  "title": "[LED Tool-校正工具] 手动配置分区模式分区行*列较大时拓扑预览中的分区显示不全",
  "candidates": [
    {
      "repoPath": "calibrationtool",
      "path": "web/src/views/config/components/partitionPreview.vue",
      "symbol": ".partTopology / gridStyle / .table-content",
      "why": "拓扑预览的本体：grid-template-columns/rows 用 repeat(n, minmax(80px,1fr))，外层 .table-content 才设 overflow:auto，行列变大时网格会被撑出可视区",
      "source": "codegraph"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/views/config/PartitionConfig.vue",
      "symbol": ".partition-topology-preview",
      "why": "预览宿主容器（行 601-607 / 样式 753-764）设置 overflow:hidden + justify-content:center，与内层 max-content 网格叠加后大行列区域被裁掉",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null
}
```
