# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026051104842",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::data_wrong",
  "title": "[LED Tool-校正工具] 环境准备-画面显示：未获取当前设备实际的画面显示颜色",
  "candidates": [
    {
      "repoPath": "calibrationtool",
      "path": "web/src/stores/modules/projectDetail/environmentInfo.ts",
      "symbol": "getAllSendCardInfoByScreen",
      "why": "与 BGCM2026051104084 同一处：回读得到 mappedColor 后写 cameraInfoStore 并落库，未取到实际颜色即在此链路",
      "source": "codegraph"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/composables/useScreenControl.ts",
      "symbol": "screenColor computed / _setScreenParams",
      "why": "画面显示控件绑定的 screenColor 与打屏下发参数同源；回读值未更新时这里展示的仍是旧/默认通道",
      "source": "grep"
    },
    {
      "repoPath": "calibrationtool",
      "path": "electron/electron/controller/projectDetail/index.ts",
      "symbol": "getTestSingleCfg",
      "why": "设备实际画面颜色的透传接口，回读为空/结构变化会直接导致前端未获取到实际颜色",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null
}
```
