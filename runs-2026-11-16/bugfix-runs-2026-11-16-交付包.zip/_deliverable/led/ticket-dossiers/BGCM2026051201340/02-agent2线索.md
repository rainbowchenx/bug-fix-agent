# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026051201340",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::i18n",
  "title": "[LED Tool-校正工具] 相机调节-粗调相机：英文版本未翻译操作提示",
  "candidates": [
    {
      "repoPath": "calibrationtool",
      "path": "web/src/views/config/CameraAdjust.vue",
      "symbol": "roughAdjustSegments / comTipSegments",
      "why": "粗调相机阶段的顶部操作提示由 roughAdjustSegments -> ComTipSegments 拼装并渲染，英文版显示哪几条文字由这里决定",
      "source": "codegraph"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/views/config/components/ComTip.vue",
      "symbol": "操作说明 popover (operationGuide / cameraFramingRange)",
      "why": "粗调提示面板本体：segments 文本 + 操作说明弹层（含按语言切换 cameraPosition_cn/en svg），未翻译的提示可能落在该弹层",
      "source": "codegraph"
    },
    {
      "repoPath": "calibrationtool",
      "path": "web/src/i18n/en_US/projectDetail.json",
      "symbol": "CalibrationTool.cameraAdjust.roughAdjustTip.*",
      "why": "粗调提示文案的英文资源（seg1..seg5 / apertureWarn / framingWarn / microFocusWarn），是英文版是否已翻译的判定依据",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null
}
```
