# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "单号": "BGCM2026051201340",
  "标题": "[LED Tool-校正工具] 相机调节-粗调相机：英文版本未翻译操作提示",
  "状态": "Closed",
  "流程状态": "已结束",
  "当前处理人": "",
  "当前处理人姓名": "",
  "解决人": "USER-6CE54A",
  "解决人姓名": "吕晨阳6",
  "级别": "低",
  "缺陷类型": "缺陷",
  "检出活动": "系统测试",
  "发现人": "USER-CDC593",
  "模块": "结构,校正工具,接收卡",
  "所属软件名": "PBI25033102",
  "版本": "V200R001C001",
  "产品线": "LED",
  "产品系列": "LED配套产品",
  "产品型号": "DS-DT60P-02HI06NO",
  "测试申请单": "PJ01PD20251231223G01",
  "创建时间": "2026-05-12 11:36:31",
  "解决时间": "2026-05-20",
  "结束时间": "2026-06-02",
  "缺陷描述": "用例名称：亮色度校正-相机调节界面查看成功前置条件：操作步骤：1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面测试数据：亮色度校正-相机调节界面查看预期结果：显示英文正常，界面无中文、乱码显示实际结果：相机调节-粗调相机：英文版本未翻译操作提示问题：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026051201340",
  "title": "[LED Tool-校正工具] 相机调节-粗调相机：英文版本未翻译操作提示",
  "pool": "strict",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::i18n",
  "testModule": "结构,校正工具,接收卡",
  "titleTag": "LED Tool-校正工具",
  "intent": "i18n",
  "intentSource": "heuristic",
  "intentConfidence": "high",
  "intentRationale": "i18n keywords",
  "fieldType": "缺陷",
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "相机调节-粗调相机：英文版本未翻译操作提示",
  "expected": "显示英文正常，界面无中文、乱码显示",
  "steps": "1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-05-12 11:36:31",
  "duplicate": false,
  "semanticFree": false,
  "priority": 5.0
}
```
