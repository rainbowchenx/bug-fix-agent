# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026051201741",
  "clusterId": "PJ01PD20251231223::结构,校正工具,接收卡::LED Tool-校正工具::i18n",
  "title": "[LED Tool-校正工具] 相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确",
  "candidates": [
    {
      "repoPath": "calibrationtool",
      "path": "web/src/i18n/en_US/projectDetail.json",
      "symbol": "CalibrationTool.calibrationTarget.selectLuxMeterFirst.msg / luxMeterNotConnected.msg / luxMeterConnectionFailed.msg",
      "why": "亮度计未连接相关报错的英文资源集中在此（Please select and connect the luminance meter first / Luminance meter not connected…），措辞不准确即在此文件",
      "source": "grep"
    },
    {
      "repoPath": "calibration-subsystem",
      "path": "src/locale/en_US/luxMeter.json",
      "symbol": "calibration_subsystem.luxMeter_200003 / luxMeter_200008 / luxMeter_200009",
      "why": "后端亮度计域的英文错误文案（No connected luminance meter found / Device not connected），电泳到界面的未连接报错可能来自这里",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null
}
```
