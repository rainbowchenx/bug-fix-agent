# Agent-2 cartography 运行说明（led）

## 复用产物

本次复用 2026-11-12 产出的 `info/code-knowledge.json`（同一仓、同一批 40 票）：

- enrich=sdk；82 turns；reason=max_turns；cost=$11.65
- cartographyProfile=electron_node（caller-supplied）
- 候选来源分布：grep 108 / codegraph 7
- 39/40 票有候选（1 票空）

理由：仓与票未变（git HEAD 校对见下），重跑 SDK 只会重复消耗；"当前最新架构"的差异集中在 Agent-3（repair feedback 链路为本次新落地），Agent-2 侧 11-12 后无破坏性变更（git log 校对）。

## 注入的 skill

包内置同 peitao/transport（code-cartography SOP 等 4 个 cartography skill）。仓内 `calibrationtool/.claude/skills`（openspec-*、trellis-*）未声明 profiles，未被注入。

## 仓状态

- calibrationtool、calibration-subsystem 各自带 `.codegraph` 索引
- git HEAD 见各仓 `git rev-parse`

- calibrationtool HEAD: 2e3af69
- calibration-subsystem HEAD: 7b9f265
