# led（led 校正（electron_node，双仓 calibration-subsystem + calibrationtool））Agent-3 批次评测报告

> 依据 docs/field-eval/agent3/templates/batch-evaluation-report.md 填写；本批只到报告路径（applyFix=false），所有「应用/验收」栏按 N/A 记。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 | runs-2026-11-16/led / 2026-11-16 |
| Agent-3 commit / 模型 | 90e4744 / EB-GLM-Pro（Claude Agent SDK） |
| 运行模式 | analyze_mode=sdk，applyFix=false（只出报告），max_turns=24 |
| Agent-1 样本 | 复用 11-12 产物 40 条（strict 37） |
| Agent-2 | 复用 11-12 SDK enrich 产物（82 turns max_turns $11.65，39/40 有候选） |
| 产物目录 | runs-2026-11-16/led/{01-agent1,02-agent2,03-agent3,ticket-dossiers} |

## 2. 样本与验收覆盖

Agent-3 深度分析：6 票（选样见 03-agent3/cases.json）。原批 40 条。

| 样本类别 | 数量 |
|---|---|
| 清晰且当前仓可修（进入 Agent-3） | 6 |
| plan_only 报告产出 | 见 03-agent3/analysis-report.json summary |
| 实际应用补丁 | 0（本批禁止改码） |
| 业务验收 | 0（N/A） |

## 3. 质量指标

| 指标 | n/N | 说明 |
|---|---|---|
| 报告覆盖 | 6/6 | 全部落盘（含诚实阻断票） |
| G0（过程真实） | FAIL | G0=FAIL（1 票 analyze_source=sdk_fallback）loc@1=2/6 loc@3=5/6 outcome=5/6 verdict=process_fail |
| loc@1 / loc@3 | 见 score.json | 5/6 loc@3 命中（含 environmentInfo 相邻双缺陷票正确定位）；CameraAdjust 票会话截断 |
| outcome 一致 | total 6：plan_only 5 / other_blocked 1 | applyFix=false 下可修票只允许 plan_only |
| 补丁应用/验收 | N/A | 本批禁止实际修复 |

## 4. 成本

Agent-2 复用旧产物（无新增成本）；Agent-3 单票 SDK 会话

## 5. 逐票结果

见 [ticket-review-summary.csv](03-agent3/ticket-review-summary.csv)；逐票档案见 ticket-dossiers/（01 原始对照 / 02 Agent-2 线索 / 03 Claude 过程 / 04 修改与复核）。

## 6. 代表案例

### 成功案例
BGCM2026051104842 画面颜色：electron catch 无 return + renderer 无空值保护 + sendCardList[0] 无保护，四项主张全验证；BGCM2026051201741 亮度计：主进程硬编码中文 + 词条措辞双链路全验证

### 失败或截断案例
BGCM2026051201340 CameraAdjust i18n：SDK 会话 max_turns 截断（analyze incomplete），诚实记 other_blocked

### 二次修复案例
本仓未跑二轮（二轮案例在 peitao 仓：ticket-dossiers/BGCM2026102809314/05-二轮修复.md）。

## 7. 环节归因与改进

| 环节 | 问题及票ID | 建议 |
|---|---|---|
| Agent-3 分析 | BGCM2026051201340 max_turns 截断 | 复杂 i18n 票可提 BUGFIX_ANALYZE_MAX_TURNS |

## 8. 结论

- G0=FAIL（1 票 analyze_source=sdk_fallback）loc@1=2/6 loc@3=5/6 outcome=5/6 verdict=process_fail
- 详细机器评分见 03-agent3/score.json；人工根因评分（G3）已填入 ticket-review-summary.csv manualRootCauseScore 列。