build       : source checkout (v0.2.0, no VENDOR.json)
source      : PJ01PM20260711040-当前处理人-USER-9267A7-Open-37条.csv
rows        : 37
columns     : 16

-- contract fields --
  [OK  ] defectId     <- 缺陷单号           'BGCM2026110510923'
  [OK  ] title        <- 标题             '[【公共】基本功能检查表-无插件] 录像回放界面的剪辑接口丢失'
  [OK  ] description  <- 缺陷描述           '用例名称：验证连续点击剪辑按钮录像剪辑成功前置条件：剪辑已开启且剪辑所在磁盘剩余空间大于1G操作'
  [OK  ] status       <- 状态             'Open'
  [OK  ] flowStatus   <- 流程状态           '解决缺陷'
  [OK  ] testModule   <- 测试模块           '【公共】基本功能检查表-无插件'
  [MISS] fieldType    <- (none)         ''
  [OK  ] severity     <- 严重级别           '低'
  [OK  ] createdAt    <- 创建时间           '2026-11-05 21:06:03'
  [MISS] duplicateOf  <- (none)         ''

-- unplaced columns (8) --
  当前处理人: 'USER-9267A7'
  当前处理人姓名: 'USER-FABDBD'
  解决人: 'USER-9267A7'
  发现人: 'USER-3EAA7F'
  缺陷/建议: '缺陷'
  检出活动: '系统测试'
  软件名: 'V5.6.0'
  版本号: 'V5.6.0'

-- content --
  rows mappable (id+title) : 37/37
  description present      : 37/37
  description is an unfilled template : 1/37
  testModule present       : 37/37
  testModule semantic-free : 17/37 (46%)  <- 无产品语义的模块名（【公共】/用例集/系统…）
  distinct modules (L1)    : 19

-- verdict --
  * WARN: 17/37 modules (46%) carry no product semantics — they are case-set / 【公共】/ checklist names, not code areas. The column is present, so the funnel will look healthy, but L1 grouping is mostly noise: expect many singleton clusters. Say this in the hand-off instead of reporting the cluster view as if it were meaningful.

-- module distribution (top 8) --
    10  基本功能检查表-卡警模式
     3  【公共】基本功能检查表-无插件
     3  抓拍
     3  【公共】基本功能检查表-抓拍参数
     3  【公共】基本功能检查表-按前端区分
     2  【公共】基本功能检查表-快速配置
     1  双频电警RFID
     1  【公共】详细用例-图片
