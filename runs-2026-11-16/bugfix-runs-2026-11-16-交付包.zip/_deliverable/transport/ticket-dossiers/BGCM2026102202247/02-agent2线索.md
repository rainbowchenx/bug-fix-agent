# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102202247",
  "clusterId": "PJ01PM20260711040::基本功能检查表-按前端区分::基本功能检查表-按前端区分::unclear",
  "title": "[基本功能检查表-按前端区分] 抓拍OSD设置【在图上叠加】时，选择所有叠加项，在小图上拖动osd的位置，osd会消失，保存会提示【字符超出图片范围】",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/RapidConfig/view/index/rapidOSDConfig/rapidOSDConfig.vue",
      "symbol": null,
      "why": "weak basename substring \"osd\" from title/titleTag/testModule/intent",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "not_investigated",
  "searchedScopes": [],
  "openQuestions": []
}
```
