# Agent-3 Claude 会话分析摘录（attempt fc822a1d59dc）

## 结果

- resolution: analysis_only
- sessionId: a3ecd15a-28c8-4100-902a-45d9d15db54e

## 机制（根因主张）

抓拍OSD「图上叠加」(charPosition=0)模式下，snapOverlay.vue 的 setTextOverlay 将所有非锚点叠加项合并为一条以 ' + ' 连接的超长文本传给 jsWebControl 插件(JS_SetTextOverlay)。当用户勾选全部叠加项且在插件小图(小尺寸预览窗口)上拖动 OSD 时：插件端超长合并文本整体移出小图可视边界导致 OSD 消失；保存时前端 checkPicOSD 仅按『起点坐标 + 单个 charSize』校验边界(注释：在边缘时要至少留出一个字符的空间)，未考虑合并文本的实际总宽度，起点落在小图低位时 startPosLeft*width/iPicWidth > width-charSize 判定超界，reject(-2) 触发 $t('osdTips')『叠加的字符超出图片范围』。选择单项时文本短不出界、全屏拖动时窗口大容得下文本，故不复现。

## 代码关联

src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue

## 证据（工具观察）

- [tool_result] src/RapidConfig/view/index/rapidOSDConfig/rapidOSDConfig.vue — weak basename substring "osd" from title/titleTag/testModule/intent
- [code_observation] src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue — 保存校验仅按起点坐标留一个 charSize 的空间(2113 注释『在边缘时要至少留出一个字符的空间』)，未考虑图上叠加模式下所有同位置叠加项合并后的文本总宽度。全选叠加项时合并文本极长，拖动到小图内任意非零位置即判定超界，reject(-2) → saveNotip catch(2994-2997) 弹『叠加的字符超出图片范围』。
- [code_observation] src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue — charPosition=0(图上叠加)时所有非锚点叠加项的 customName 被收集进 szPositionSame，随后(2220-2229)拼成 'a + b + c + …' 单条超长 text 传给插件。全选叠加项 + 小图窗口场景下，该超长文本整体拖出小图可视区导致插件不再绘制(OSD 消失)，且是 checkPicOSD 误判的输入来源。单项选择时文本短、全屏时窗口大，故不复现—
- [code_observation] src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue — 若缺陷中『小图』指车牌小图叠加：此处存在两处硬伤——iPosY 误用 point[0](X分量)计算 Y 坐标；id 严格等于字符串 '1000'，而 setTextOverlay(2214-2218) push 的是数字 id 1000，类型不匹配导致回读失败/坐标错乱，拖动后车牌小图位置数据损坏。
- [code_observation] src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue — locator checkPicOSD in src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue
- [code_observation] src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue — locator setTextOverlay in src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue
- [code_observation] src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue — locator restoreInfo/getTextOverlay回读cb in src/Config/view/snap/snapParam/snapOverlay/pc/snapOverlay.vue

## 开放问题

- 缺陷中「小图」的确切含义：是插件窗口小尺寸模式，还是车牌小图(platePicOverlay)叠加——后者对应另一处坐标回读 bug(见 notes 第3条)，需在真机/插件环境确认拖动对象
- 插件 JS_SetTextOverlay 对超长合并文本的绘制/丢弃行为无法在前端代码中验证，需插件侧日志确认『消失』的直接机制

## 编辑决策

- allowed: False（reason: open questions unresolved; missing evidenceRefs）