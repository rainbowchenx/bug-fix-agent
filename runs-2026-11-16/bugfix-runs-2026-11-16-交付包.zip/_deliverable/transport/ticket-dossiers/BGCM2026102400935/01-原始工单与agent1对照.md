# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102400935",
  "标题": "[基本功能检查表-图像翻转] web预览页面经常出现预览画面窗口残留的情况，只能关闭窗口重新打开",
  "状态": "Open",
  "流程状态": "解决缺陷",
  "当前处理人": "USER-9267A7",
  "当前处理人姓名": "USER-FABDBD",
  "解决人": "USER-9267A7",
  "发现人": "USER-4E1EF1",
  "严重级别": "中",
  "缺陷/建议": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "基本功能检查表-图像翻转",
  "软件名": "V5.6.0",
  "版本号": "V5.6.0",
  "创建时间": "2026-10-24 15:12:53",
  "缺陷描述": "用例名称：图像翻转-抓拍前置条件：操作步骤：1.按照测试数据进行图像翻转，查看翻转后抓拍是否正常。测试数据：1）902）1803）270预期结果：1.翻转后抓拍正常。实际结果：web预览页面经常出现预览画面窗口残留的情况问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102400935",
  "title": "[基本功能检查表-图像翻转] web预览页面经常出现预览画面窗口残留的情况，只能关闭窗口重新打开",
  "pool": "strict",
  "clusterId": "PJ01PM20260711040::基本功能检查表-图像翻转::基本功能检查表-图像翻转::unclear",
  "testModule": "基本功能检查表-图像翻转",
  "titleTag": "基本功能检查表-图像翻转",
  "intent": "unclear",
  "intentSource": "unclear",
  "intentConfidence": "low",
  "intentRationale": "no strong intent signal",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "web预览页面经常出现预览画面窗口残留的情况",
  "expected": "1.翻转后抓拍正常。",
  "steps": "1.按照测试数据进行图像翻转，查看翻转后抓拍是否正常。",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-24 15:12:53",
  "duplicate": false,
  "semanticFree": false,
  "priority": 3.0,
  "revisionId": "BGCM2026102400935:v0",
  "sourceObserved": "web预览页面经常出现预览画面窗口残留的情况",
  "sourceExpected": "1.翻转后抓拍正常。",
  "sourceSteps": "1.按照测试数据进行图像翻转，查看翻转后抓拍是否正常。",
  "attachmentRefs": null
}
```
