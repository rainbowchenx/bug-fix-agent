# Agent-3 Claude 会话分析摘录（attempt 663f27746fdf）

## 结果

- resolution: analysis_only
- sessionId: 723ffa9f-cdad-41d0-9f89-cb8aa73ee83d

## 机制（根因主张）

预览『窗口画面残留』的直接嫌疑在 jsWebControl 插件桥对『图片预览模式（bImagePlay）』的停止逻辑不对称：stop() 在 bImagePlay 为真时只清掉刷新定时器并直接 resolve，从不调用 JS_Stop 清除窗口上已绘制的最后一帧；stopRealPlayAll() 调用 JS_StopRealPlayAll() 前后既不清理 oImageRefresh 的自循环 setTimeout，也不重置 bImagePlay。imagePlay()（jsWebControl.js:5039-5064）在成功/失败两个分支都会用 setTimeout 重新调度自身。因此一旦进入图片预览（无插件/webComponents/快照模式），走『单通道停止』（PreviewChannelList.stopPlay → Plugin.stop）或『全部停止』（Tool.stopAllPlay → Plugin.stopRealPlayAll）都不会真正清屏：最后一张图留在插件窗口，且 imagePlay 定时器可能继续向 0 号窗口刷图——与工单描述『画面窗口残留、只能关闭窗口重新打开』完全吻合。翻转配置本身（videoParam.vue 提交 /ISAPI ImageFlip，3062-3075 行）只是 PUT 下发，不刷新预览端状态，翻转后画面/缓存分辨率不更新属于同一残留现象的诱因之一。

## 代码关联

src/Common/libs/jsWebControl/jsWebControl.js; src/Config/view/video/videoParam/pc/videoParam.vue

## 证据（工具观察）

- [tool_result] src/Preview/view/index/index.vue — 预览页窗口状态与画面清理逻辑，窗口残留（画面未清/未停）的宿主
- [tool_result] src/Common/libs/jsWebControl/jsWebControl.js — 插件窗口停止/清屏实现（JS_Stop），残留通常为停止或清屏调用缺失/失败
- [tool_result] src/Common/components/pc/integration/Tool/Tool.vue — 预览工具栏分屏/全部停止入口，窗口切换后残留状态维护
- [code_observation] src/Common/libs/jsWebControl/jsWebControl.js — 图片预览模式下 stop() 只清刷新定时器，从不调用 JS_Stop 清除插件窗口上已绘制的最后一帧图片，窗口内容原样残留——正是『画面窗口残留，只能关闭窗口重新打开』的单通道停止路径。
- [code_observation] src/Common/libs/jsWebControl/jsWebControl.js — 『全部停止』入口（Tool.vue stopAllPlay:1506 → Plugin.stopRealPlayAll）只调用 JS_StopRealPlayAll，不清理 oImageRefresh 自循环定时器也不重置 bImagePlay；若先前处于图片预览，imagePlay 的 setTimeout 会继续把图刷回 0 号窗口，停止后画面依旧残留/复活。
- [code_observation] src/Common/libs/jsWebControl/jsWebControl.js — imagePlay 在成功与失败两个分支都无条件自我重排（写死窗口 0），任何停止路径只要漏清一次定时器，刷新循环即永续，与 stopRealPlayAll 的遗漏叠加后形成『只能关窗重开』的现象。
- [code_observation] src/Config/view/video/videoParam/pc/videoParam.vue — 翻转下发链路本身正常（已排除为根因），但下发成功后没有任何通知预览页停止/重启取流或刷新缓存分辨率（flipAngle 90/270 交换宽高，等同 index.vue webComponentsSizeChange 中 bCorridor 的换算前提 829-874 行），翻转后预览端沿用旧状态是残留现象的关联诱因，修复时可顺带验证是否需要联动刷新。
- [code_observation] src/Common/libs/jsWebControl/jsWebControl.js — mechanism fragment in E:/working_code_webfront/bug-fix-demo-project/transport/src/Common/libs/jsWebControl/jsWebControl.js: let oPromise = new Promise(resolve => {
      if (this.bImagePlay) {
       
- [code_observation] src/Common/libs/jsWebControl/jsWebControl.js — mechanism fragment in E:/working_code_webfront/bug-fix-demo-project/transport/src/Common/libs/jsWebControl/jsWebControl.js: let oPromise = new Promise((resolve, reject) => {
      this.oPlugin && this
- [code_observation] src/Common/libs/jsWebControl/jsWebControl.js — mechanism fragment in E:/working_code_webfront/bug-fix-demo-project/transport/src/Common/libs/jsWebControl/jsWebControl.js: return new Promise((resolve) => {
      this.oPlugin.JS_PlayWithImg(0, szCur
- [code_observation] src/Config/view/video/videoParam/pc/videoParam.vue — locator submitITCImageEnhance(imageFlip 分支) in src/Config/view/video/videoParam/pc/videoParam.vue

## 开放问题

- 测试时设备处于哪种插件模式（iPluginMode=1 本地插件 / 2 webComponents / 无插件快照模式）？bImagePlay 是否被置位需要运行时确认
- 残留是『最后一帧静止』还是『持续刷新的旧图』？前者对应 stop() 未调 JS_Stop；后者对应 stopRealPlayAll 未清自循环定时器——两者修复都建议做
- 翻转（flipAngle 90/270 会交换宽高，等同 corridor 效果）后 Service.m_aChannelList[].oResolution 缓存不更新，webComponentsSizeChange 模式 3（1x）按旧分辨率设置 #main_plugin 宽高（index.vue:858-874），是否也参与了窗口错位残留，需复测确认

## 编辑决策

- allowed: False（reason: open questions unresolved）