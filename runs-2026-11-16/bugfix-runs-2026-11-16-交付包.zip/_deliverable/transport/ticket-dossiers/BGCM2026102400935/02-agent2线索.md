# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102400935",
  "clusterId": "PJ01PM20260711040::基本功能检查表-图像翻转::基本功能检查表-图像翻转::unclear",
  "title": "[基本功能检查表-图像翻转] web预览页面经常出现预览画面窗口残留的情况，只能关闭窗口重新打开",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Preview/view/index/index.vue",
      "symbol": "stopPlay/wndSizeChange/webComponentsSizeChange",
      "why": "预览页窗口状态与画面清理逻辑，窗口残留（画面未清/未停）的宿主",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/Common/libs/jsWebControl/jsWebControl.js",
      "symbol": "stop/stopRealPlayAll",
      "why": "插件窗口停止/清屏实现（JS_Stop），残留通常为停止或清屏调用缺失/失败",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/Common/components/pc/integration/Tool/Tool.vue",
      "symbol": "stopAllPlay/wndSplit",
      "why": "预览工具栏分屏/全部停止入口，窗口切换后残留状态维护",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
