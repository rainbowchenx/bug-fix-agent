# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102809398",
  "标题": "[基本功能检查表-卡警模式]  98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白而实际车辆被牌识，具体操作详情可见录屏附件",
  "状态": "Open",
  "流程状态": "解决缺陷",
  "当前处理人": "USER_BE",
  "当前处理人姓名": "USER_DA",
  "解决人": "USER_BE",
  "发现人": "USER_BH",
  "严重级别": "中",
  "缺陷/建议": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "基本功能检查表-卡警模式",
  "软件名": "V5.6.0",
  "版本号": "V5.6.0",
  "创建时间": "2026-10-28 18:13:05",
  "缺陷描述": "用例名称：频闪网络连拍前置条件：操作步骤：1.HVT频闪模式下，查看网络连拍及牌识是否正常。测试数据：预期结果：1.网络连拍及牌识正常。实际结果：98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白，而实际车辆被牌识问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102809398",
  "title": "[基本功能检查表-卡警模式]  98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白而实际车辆被牌识，具体操作详情可见录屏附件",
  "pool": "strict",
  "clusterId": "PJ01PM20260711040::基本功能检查表-卡警模式::基本功能检查表-卡警模式::unclear",
  "testModule": "基本功能检查表-卡警模式",
  "titleTag": "基本功能检查表-卡警模式",
  "intent": "unclear",
  "intentSource": "unclear",
  "intentConfidence": "low",
  "intentRationale": "no strong intent signal",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白，而实际车辆被牌识",
  "expected": "1.网络连拍及牌识正常。",
  "steps": "1.HVT频闪模式下，查看网络连拍及牌识是否正常。",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-28 18:13:05",
  "duplicate": false,
  "semanticFree": false,
  "priority": 16.0,
  "revisionId": "BGCM2026102809398:v0",
  "sourceObserved": "98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白，而实际车辆被牌识",
  "sourceExpected": "1.网络连拍及牌识正常。",
  "sourceSteps": "1.HVT频闪模式下，查看网络连拍及牌识是否正常。",
  "attachmentRefs": null
}
```
