# Agent-3 Claude 会话分析摘录（attempt 06de42dba337）

## 结果

- resolution: analysis_only
- sessionId: 71606e7c-f689-4465-ad72-99a590e71859

## 机制（根因主张）

网络连拍（布防收图 WebSocket）高频场景下，alarmWorker.js 用实例级共享 aImgBuffer 拼所有二进制图片帧且不按 szPid 区分，多条 ANPR 事件/多张连拍图交错到达时数据错拼或被丢弃；同时 jsonParsing 收到新结构化数据时无条件 flush 并清空 oBinaryIdsMap，旧事件未收完的帧随后被丢弃。二者导致车牌图片 URL 缺失或 JPEG 数据损坏，前端 dealANPRInfo 对 file 为 undefined 无兜底直接 changeImageSrc，图片区显示白底，而车牌号等文字信息正常 —— 即『牌识别区域纯白但车辆被牌识』。

## 代码关联

src/Common/static/libs/alarmWorker.js; src/Preview/components/base/UploadPic/uploadPicMixin.js

## 证据（工具观察）

- [tool_result] src/Config/view/event/exceptionEvent/HVTTrigger/HVTTrigger.vue — basename contains "hvt" from title/titleTag/testModule/intent
- [tool_result] src/Config/view/snap/triggerMode/postHVT/triggerModePostHVT.vue — basename contains "hvt" from title/titleTag/testModule/intent
- [tool_result] src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js — weak basename substring "hvt" from title/titleTag/testModule/intent
- [code_observation] src/Common/static/libs/alarmWorker.js — aImgBuffer 是 worker 实例级共享缓冲：网络连拍时多条 ANPR 事件/每事件多张连拍图的二进制帧交错到达，不同 pId 的包被拼进同一段数据——长度校验失败则图片被丢（file 为 undefined → 白底），长度碰巧相等则产出错位损坏的 JPEG（渲染为大面积纯白），与『牌识别区域纯白』现象直接对应
- [code_observation] src/Common/static/libs/alarmWorker.js — 单事件缓冲模型：连拍高频场景下新结构化数据到达即无条件 flush 旧数据并清空 pId 映射，旧事件未收完的二进制帧随后在 binaryParsing 中查不到 _oBinartId 而被整体丢弃，车牌图 URL 永远缺失
- [code_observation] src/Preview/components/base/UploadPic/uploadPicMixin.js — 显示层无兜底：worker 侧关联失败时 aResult.Vehicle[pId+'_Url'] 为 undefined，仍把 file: undefined 推入 picUploadArr 并 changeImageSrc(undefined)，图片区渲染为白色空白，而文字牌识正常——正是缺陷报告的表象
- [code_observation] src/Common/static/libs/alarmWorker.js — locator binaryParsing in src/Common/static/libs/alarmWorker.js
- [code_observation] src/Common/static/libs/alarmWorker.js — locator jsonParsing in src/Common/static/libs/alarmWorker.js
- [code_observation] src/Preview/components/base/UploadPic/uploadPicMixin.js — locator dealANPRInfo in src/Preview/components/base/UploadPic/uploadPicMixin.js

## 开放问题

- 录屏附件中『纯白』是图片加载失败的白色空白区，还是解码渲染出的纯白 JPEG？（前者支持 URL 缺失分支，后者支持数据错拼分支）
- 设备上报的原始 JPEG 本身是否正常（需在 ws 层抓帧确认）？若设备图本身过曝纯白则根因在固件而非前端
- HVT 模式连拍时事件上报频率与二进制帧交错程度（决定竞态触发概率）

## 编辑决策

- allowed: False（reason: open questions unresolved; missing evidenceRefs）