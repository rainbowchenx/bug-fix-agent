# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102809398",
  "clusterId": "PJ01PM20260711040::基本功能检查表-卡警模式::基本功能检查表-卡警模式::unclear",
  "title": "[基本功能检查表-卡警模式]  98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白而实际车辆被牌识，具体操作详情可见录屏附件",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Config/view/event/exceptionEvent/HVTTrigger/HVTTrigger.vue",
      "symbol": null,
      "why": "basename contains \"hvt\" from title/titleTag/testModule/intent",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Config/view/snap/triggerMode/postHVT/triggerModePostHVT.vue",
      "symbol": null,
      "why": "basename contains \"hvt\" from title/titleTag/testModule/intent",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js",
      "symbol": null,
      "why": "weak basename substring \"hvt\" from title/titleTag/testModule/intent",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "not_investigated",
  "searchedScopes": [],
  "openQuestions": []
}
```
