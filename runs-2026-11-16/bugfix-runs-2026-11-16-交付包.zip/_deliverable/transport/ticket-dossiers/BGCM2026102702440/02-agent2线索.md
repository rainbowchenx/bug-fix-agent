# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102702440",
  "clusterId": "PJ01PM20260711040::misc/【公共】基本功能检查表-视频::【公共】基本功能检查表-视频::config",
  "title": "[【公共】基本功能检查表-视频] 区域曝光，区域不能重新绘制，只能拖动确认是否正常",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Config/view/video/videoCode/regExposure/regExposure.vue",
      "symbol": "regExposure",
      "why": "区域曝光配置页，区域重新绘制/只能拖动的绘制行为在此",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Common/components/pc/integration/Tool/Tool.vue",
      "symbol": "startRegionExposure/multiexclusion",
      "why": "预览工具栏区域曝光绘制入口与互斥逻辑，绘制模式切换影响可重绘性",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
