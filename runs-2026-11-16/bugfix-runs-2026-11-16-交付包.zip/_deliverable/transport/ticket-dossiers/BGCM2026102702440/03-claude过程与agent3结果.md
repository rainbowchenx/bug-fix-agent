# Agent-3 Claude 会话分析摘录（attempt 8450b0a13e67）

## 结果

- resolution: analysis_only
- sessionId: 10698936-a755-477f-96ea-26bb5b270ab8

## 机制（根因主张）

regExposure.vue 区域曝光页在 enabled 开启后仅通过 displayArea()→setEditAreaInfo() 将设备下发的旧矩形以 editType=0（可拖动）、maxShapeSupport=1（单图形上限）落到插件上，之后既没有清除旧图形重新进入绘制态的代码路径，也没有像 roi.vue/privacyMask.vue 那样的「重绘」入口（无 drawRegion()/draw() 按钮）。旧矩形占满唯一图形槽位且 editType=0 允许拖拽，用户在画面上的操作被插件解释为拖动既有矩形，无法重新绘制新区域。

## 代码关联

src/Config/view/video/videoCode/regExposure/regExposure.vue; src/Config/view/video/videoCode/videoMixin.js; src/Common/libs/jsWebControl/drawTools.js; src/Config/view/video/videoCode/roi/roi.vue

## 证据（工具观察）

- [tool_result] src/Config/view/video/videoCode/regExposure/regExposure.vue — 区域曝光配置页，区域重新绘制/只能拖动的绘制行为在此
- [tool_result] src/Common/components/pc/integration/Tool/Tool.vue — 预览工具栏区域曝光绘制入口与互斥逻辑，绘制模式切换影响可重绘性
- [code_observation] src/Config/view/video/videoCode/regExposure/regExposure.vue — 开启后只展示旧区域并进入绘制态，注释掉的 this.drawRegion() 正是被删除的重绘路径；此后没有任何代码清除旧图形，旧矩形（editType=0、maxShapeSupport=1）一直占着唯一图形槽位，用户只能拖动它，无法画新区域
- [code_observation] src/Config/view/video/videoCode/videoMixin.js — setEditAreaInfo 将旧区域以 editType=0（可拖动）+ MaxRegionNum=1（单图形上限）设入插件，绘制槽位被旧矩形占满；方法内部从未提供清除后重画的能力，是「只能拖动」的直接成因
- [code_observation] src/Common/libs/jsWebControl/drawTools.js — 证实 setFigure 落入插件的矩形 editType 直接取自 XML（此处为 0=可编辑可拖动），且开发者自注释表明 editType 语义在插件侧本就不可靠；与 maxShapeSupport=1 叠加导致只能拖动不能重绘
- [code_observation] src/Config/view/video/videoCode/roi/roi.vue — 对照组：同族 roi 页面通过 draw 开关调 videoMixin.drawRegion()（clearFigure 后 addFigure 重绘）实现重新绘制；regExposure.vue 缺失这套流程即缺陷根因，同时给出修复范本
- [code_observation] src/Config/view/video/videoCode/regExposure/regExposure.vue — locator watch['enabled'] in src/Config/view/video/videoCode/regExposure/regExposure.vue
- [code_observation] src/Config/view/video/videoCode/videoMixin.js — locator setEditAreaInfo in src/Config/view/video/videoCode/videoMixin.js
- [code_observation] src/Common/libs/jsWebControl/drawTools.js — locator setRegionInfo in src/Common/libs/jsWebControl/drawTools.js
- [code_observation] src/Config/view/video/videoCode/roi/roi.vue — locator draw in src/Config/view/video/videoCode/roi/roi.vue

## 开放问题

- 插件 JS_SetRectInfo 在已存在 1 个 maxShapeSupport=1 图形时的确切行为（拒绝新增还是替换）来自闭源插件，无法从源码直接证实，只能从现象与同族页面对照推断
- 产品预期交互是「点击画面任意处直接开始新绘制」还是提供显式「重绘」按钮（roi.vue 是按钮式），需产品确认

## 编辑决策

- allowed: False（reason: open questions unresolved; missing evidenceRefs）