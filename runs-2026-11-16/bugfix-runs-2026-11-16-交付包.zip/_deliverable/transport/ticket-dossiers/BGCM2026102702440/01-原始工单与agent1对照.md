# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102702440",
  "标题": "[【公共】基本功能检查表-视频] 区域曝光，区域不能重新绘制，只能拖动确认是否正常",
  "状态": "Open",
  "流程状态": "解决缺陷",
  "当前处理人": "USER-9267A7",
  "当前处理人姓名": "USER-FABDBD",
  "解决人": "USER-9267A7",
  "发现人": "USER-1CF3DD",
  "严重级别": "中",
  "缺陷/建议": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "【公共】基本功能检查表-视频",
  "软件名": "V5.6.0",
  "版本号": "V5.6.0",
  "创建时间": "2026-10-27 11:33:32",
  "缺陷描述": "用例名称：使能区域曝光功能成功前置条件：操作步骤：1.在区域内画任意大小范围，查看区域曝光是否生效。测试数据：预期结果：1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。实际结果：区域曝光，区域不能重新绘制，只能拖动确认是否正常问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102702440",
  "title": "[【公共】基本功能检查表-视频] 区域曝光，区域不能重新绘制，只能拖动确认是否正常",
  "pool": "strict",
  "clusterId": "PJ01PM20260711040::misc/【公共】基本功能检查表-视频::【公共】基本功能检查表-视频::config",
  "testModule": "misc/【公共】基本功能检查表-视频",
  "titleTag": "【公共】基本功能检查表-视频",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "区域曝光，区域不能重新绘制，只能拖动确认是否正常",
  "expected": "1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。",
  "steps": "1.在区域内画任意大小范围，查看区域曝光是否生效。",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-27 11:33:32",
  "duplicate": false,
  "semanticFree": true,
  "priority": 10.0,
  "revisionId": "BGCM2026102702440:v0",
  "sourceObserved": "区域曝光，区域不能重新绘制，只能拖动确认是否正常",
  "sourceExpected": "1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。",
  "sourceSteps": "1.在区域内画任意大小范围，查看区域曝光是否生效。",
  "attachmentRefs": null
}
```
