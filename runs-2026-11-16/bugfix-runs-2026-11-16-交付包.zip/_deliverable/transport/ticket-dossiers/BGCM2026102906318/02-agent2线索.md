# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102906318",
  "clusterId": "PJ01PM20260711040::基本功能检查表-卡警模式::基本功能检查表-卡警模式::data_wrong",
  "title": "[基本功能检查表-卡警模式] 偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Config/view/network/dataDocking/Integrate/Integrate.vue",
      "symbol": null,
      "why": "package/dir contains \"data\" from title/titleTag/testModule/intent",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Config/view/network/dataDocking/advancedEmail/advancedEmail.vue",
      "symbol": null,
      "why": "package/dir contains \"data\" from title/titleTag/testModule/intent",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Config/view/network/dataDocking/alarmUpload/pc/alarmUpload.vue",
      "symbol": null,
      "why": "package/dir contains \"data\" from title/titleTag/testModule/intent",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "not_investigated",
  "searchedScopes": [],
  "openQuestions": []
}
```
