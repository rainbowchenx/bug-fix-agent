# Agent-3 Claude 会话分析摘录（attempt 33536962a0c9）

## 结果

- resolution: analysis_only
- sessionId: 4f330748-e9c4-49f2-aa49-3a5f7b6849e3

## 机制（根因主张）

卡警（卡口+电警）模式对应 src/Config/view/snap/triggerMode/videoEpolice。切总车道数时 watch 'oTopParams.relatedLaneCount'（videoEpoliceMixin.js:940-951）依次调用 changeLaneNum(newVal) → changeactiveEvent → drawLineAndRegion()。changeLaneNum（:7194）只重建 aTabLanes/aCopyLanes/aLaneSelectTypeOpts/aWaitLaneSelectTypeOpts 等 UI 数组并调用 tabChange，完全不修改 m_xmlObject 中的 LaneParam/ViolationDetectLineList；随后 displayVideoEpoliceLines（:4585）仍从旧 XML 重建车道线：新增车道在 XML 中无 laneLine 数据（坐标全 0 时 :4725 直接跳过，rid > 旧车道数则被 :4629 的 `rid <= relatedLaneCount`/opts.laneLine[rid-1] 过滤）。而行人线 failYieldPedLine（:4825-4844，id 4000+rid）是顶层独立列表，不随车道数增删，每次重绘都会正常画出——与缺陷现象『只更新行人线，未更新车道线』吻合。另外 displayVideoEpoliceLines 尾部 `plugin.clearFigure([2]).then(() => plugin.setFigure(snapLines))`（:4978-4980）是异步链，与 watch 中 changeactiveEvent 触发的其他绘制路径（saveEvent/其它 watcher 也会调 drawLineAndRegion，:954/:959/:969 等）并发执行时 clearFigure 可能后于 setFigure 生效，把刚画好的车道线清掉——这解释『偶现』。setFigure 在 snapLines 为空时还会提前 return（jsWebControl.js:3592-3595），导致线被清除后不再重画。

## 代码关联

src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js

## 证据（工具观察）

- [tool_result] src/Config/view/network/dataDocking/Integrate/Integrate.vue — package/dir contains "data" from title/titleTag/testModule/intent
- [tool_result] src/Config/view/network/dataDocking/advancedEmail/advancedEmail.vue — package/dir contains "data" from title/titleTag/testModule/intent
- [tool_result] src/Config/view/network/dataDocking/alarmUpload/pc/alarmUpload.vue — package/dir contains "data" from title/titleTag/testModule/intent
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — 切总车道数的唯一入口。changeLaneNum 不同步 XML 数据、drawLineAndRegion 异步重绘，且 changeactiveEvent 分支可能再次触发绘制造成竞态——车道线不更新的直接现场。
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — 只重建 tab/checkbox 等 UI 数组并读旧 XML 的 ViolationDetectLineList（:7221 按索引取已有节点），不增删 m_xmlObject 的 LaneParam——车道数变化后车道线数据源与车道数脱节。
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — 异步 clear→set 链。当其它入口（如行人线相关 watcher :954-:999、changeactiveEvent 间接路径）并发触发绘制时，后到的 clearFigure 会清掉先完成的 setFigure；且 snapLines 为空时 setFigure 直接 return（jsWebControl.js:3592-3595），造成『清了不画』的偶现。
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — 行人线（不礼让行人 failYieldPedLine，id 4000+rid）来自 m_xmlObject 顶层独立列表，遍历绘制时不做 rid <= relatedLaneCount 过滤、不依赖车道 tab——这就是切车道数后行人线仍正常显示而车道线消失的差异根源。
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — locator watch 'oTopParams.relatedLaneCount' in src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — locator changeLaneNum in src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — locator displayVideoEpoliceLines (tail) in src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js
- [code_observation] src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js — locator displayVideoEpoliceLines (failYieldPedLine) in src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js

## 开放问题

- m_xmlObject 的 LaneParam/ViolationDetectLineList 节点增删发生在哪个环节（疑似仅在保存下发或 commonAddLane 用户手动加线时），未在本次只读分析中完全确认切车道数时是否有其它隐藏的 XML 同步路径
- '只更新行人线'中『更新』的确切含义：是行人线被重绘为新布局、还是车道线被清空后未重绘——需真机/插件环境确认（涉及 jsWebControl 插件桥异步行为）
- 缺陷标题『偶现』与两条候选机理（XML 数据滞后 vs clearFigure/setFigure 竞态）的权重未验证

## 编辑决策

- allowed: False（reason: open questions unresolved; missing evidenceRefs）