# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026102600211",
  "clusterId": "PJ01PM20260711040::基本功能检查表-卡警模式::基本功能检查表-卡警模式::config",
  "title": "[基本功能检查表-卡警模式] 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Config/view/autoDrawDlg/autoDrawDlg.vue",
      "symbol": "AutoDrawDlg",
      "why": "车道线自动绘制弹窗组件，绘制确认与结果回传入口",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/Config/view/snap/triggerMode/videoEpolice/triggerModeVideoEpolice.vue",
      "symbol": "triggerModeVideoEpolice",
      "why": "视频电警触发模式页面，承载导流带/自动绘制按钮交互",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
