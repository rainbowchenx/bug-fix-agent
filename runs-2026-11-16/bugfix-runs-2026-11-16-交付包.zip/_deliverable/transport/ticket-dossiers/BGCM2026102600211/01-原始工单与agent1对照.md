# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026102600211",
  "标题": "[基本功能检查表-卡警模式] 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】",
  "状态": "Open",
  "流程状态": "解决缺陷",
  "当前处理人": "USER-9267A7",
  "当前处理人姓名": "USER-FABDBD",
  "解决人": "USER-9267A7",
  "发现人": "USER-B9E889",
  "严重级别": "中",
  "缺陷/建议": "缺陷",
  "检出活动": "系统测试",
  "测试模块": "基本功能检查表-卡警模式",
  "软件名": "V5.6.0",
  "版本号": "V5.6.0",
  "创建时间": "2026-10-26 09:35:25",
  "缺陷描述": "用例名称：辅助画线前置条件：操作步骤：1.HVT模式下启用车道线自动绘制（海外不支持）测试数据：预期结果：1.车道线和触发线、车道线类型与实际相符，且配置生效实际结果：绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026102600211",
  "title": "[基本功能检查表-卡警模式] 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】",
  "pool": "strict",
  "clusterId": "PJ01PM20260711040::基本功能检查表-卡警模式::基本功能检查表-卡警模式::config",
  "testModule": "基本功能检查表-卡警模式",
  "titleTag": "基本功能检查表-卡警模式",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】",
  "expected": "1.车道线和触发线、车道线类型与实际相符，且配置生效",
  "steps": "1.HVT模式下启用车道线自动绘制（海外不支持）",
  "status": "Open",
  "severity": "中",
  "createdAt": "2026-10-26 09:35:25",
  "duplicate": false,
  "semanticFree": false,
  "priority": 4.0,
  "revisionId": "BGCM2026102600211:v0",
  "sourceObserved": "绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】",
  "sourceExpected": "1.车道线和触发线、车道线类型与实际相符，且配置生效",
  "sourceSteps": "1.HVT模式下启用车道线自动绘制（海外不支持）",
  "attachmentRefs": null
}
```
