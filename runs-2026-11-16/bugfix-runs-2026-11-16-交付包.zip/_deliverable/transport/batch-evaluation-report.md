# transport（transport 交通（device_web））Agent-3 批次评测报告

> 依据 docs/field-eval/agent3/templates/batch-evaluation-report.md 填写；本批只到报告路径（applyFix=false），所有「应用/验收」栏按 N/A 记。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 | runs-2026-11-16/transport / 2026-11-16 |
| Agent-3 commit / 模型 | 90e4744 / EB-GLM-Pro（Claude Agent SDK） |
| 运行模式 | analyze_mode=sdk，applyFix=false（只出报告），max_turns=24 |
| Agent-1 样本 | 37 条（strict 34 / needs_info 3） |
| Agent-2 | enrich=sdk 19 turns $1.49，26/37 有候选（11 空含 3 needs_info） |
| 产物目录 | runs-2026-11-16/transport/{01-agent1,02-agent2,03-agent3,ticket-dossiers} |

## 2. 样本与验收覆盖

Agent-3 深度分析：6 票（选样见 03-agent3/cases.json）。原批 37 条。

| 样本类别 | 数量 |
|---|---|
| 清晰且当前仓可修（进入 Agent-3） | 6 |
| plan_only 报告产出 | 见 03-agent3/analysis-report.json summary |
| 实际应用补丁 | 0（本批禁止改码） |
| 业务验收 | 0（N/A） |

## 3. 质量指标

| 指标 | n/N | 说明 |
|---|---|---|
| 报告覆盖 | 6/6 | 全部落盘（含诚实阻断票） |
| G0（过程真实） | PASS | G0=PASS loc@1=2/6 loc@3=2/6（bands: loc=unusable）outcome=6/6 verdict=loc_unusable |
| loc@1 / loc@3 | 见 score.json | 2/6 前缀命中：OSD 票命中替代前缀（snap/），预览幽灵票指向插件桥（合理替位）；posthvt-white→alarmWorker、pedestrian-line→videoEpolice 两票真跑偏 |
| outcome 一致 | total 6：plan_only 6 | applyFix=false 下可修票只允许 plan_only |
| 补丁应用/验收 | N/A | 本批禁止实际修复 |

## 4. 成本

Agent-2 $1.49；Agent-3 单票 SDK 会话

## 5. 逐票结果

见 [ticket-review-summary.csv](03-agent3/ticket-review-summary.csv)；逐票档案见 ticket-dossiers/（01 原始对照 / 02 Agent-2 线索 / 03 Claude 过程 / 04 修改与复核）。

## 6. 代表案例

### 成功案例
BGCM2026102600211 OSD：替代前缀命中；BGCM2026102809398 单通道码率：singleChannelConfig.vue bitrateType 367/724/1169 命中

### 失败或截断案例
posthvt 白线（BGCM2026102400935 → alarmWorker 而非 postHvtMixin）与行人线（BGCM2026102202247 → videoEpolice）两票定位跑偏；机制真实性仍高但文件错

### 二次修复案例
本仓未跑二轮（二轮案例在 peitao 仓：ticket-dossiers/BGCM2026102809314/05-二轮修复.md）。

## 7. 环节归因与改进

| 环节 | 问题及票ID | 建议 |
|---|---|---|
| Agent-2 候选 | posthvt/行人线两票候选误导 Agent-3 | 候选排序需引入业务域权重 |

## 8. 结论

- G0=PASS loc@1=2/6 loc@3=2/6（bands: loc=unusable）outcome=6/6 verdict=loc_unusable
- 详细机器评分见 03-agent3/score.json；人工根因评分（G3）已填入 ticket-review-summary.csv manualRootCauseScore 列。