# Agent-2 cartography 运行说明（transport）

## 运行配置

- 架构 commit：90e4744（2026-11-16）
- cartography-profile：device_web（调用方传入）
- cartography-mode：sdk（Claude Agent SDK）
- CodeGraph：workDir 已建 `.codegraph` 索引，SDK 会话挂 codegraph MCP
- 姿态：beta；match 池：strict + locatable_only + needs_info

## 注入的 skill（discover_injected_skills 实测）

包内置（platform/skills/，无 overlay）：

| profile | skill |
|---|---|
| cartography | code-cartography（SOP 主文档）、electron-process-boundary、hierarchical-localization、monorepo-workspace |
| analyze | electron-process-boundary、hierarchical-localization、monorepo-workspace、systematic-debugging、test-triage、typescript-null-safety、vue-debug |

仓内 `.claude/skills` 里的业务 skill（transport 的 use-hc-ui-for-device、trellis-* 等）**未声明 `profiles:` frontmatter**，且非 `allow_unprofiled` 目录（.claude 不允许无 profile），因此**未被注入**——这是本次运行的一个观察点：业务 skill 覆盖率取决于仓方是否补 profiles 标注。

## 运行结果摘要

见 run.log 与 code-knowledge.json。成本/轮次从 run.log 的 `[agent2] enrich=...` 行读取。

## 仓 HEAD

- transport HEAD: 92ed6fc0c
