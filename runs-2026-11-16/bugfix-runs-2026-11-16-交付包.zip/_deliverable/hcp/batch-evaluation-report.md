# hcp（hcp 3.2 微前端（micro_frontend））Agent-3 批次评测报告

> 依据 docs/field-eval/agent3/templates/batch-evaluation-report.md 填写；本批只到报告路径（applyFix=false），所有「应用/验收」栏按 N/A 记。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 | runs-2026-11-16/hcp / 2026-11-16 |
| Agent-3 commit / 模型 | 90e4744 / EB-GLM-Pro（Claude Agent SDK） |
| 运行模式 | analyze_mode=sdk，applyFix=false（只出报告），max_turns=24 |
| Agent-1 样本 | 26+11 两条 CSV 合并 37 条（strict 25 / needs_info 8 / locatable 4） |
| Agent-2 | enrich=sdk 120 turns（max_turns 触顶）$13.19，27/37 有候选（10 空含 8 needs_info） |
| 产物目录 | runs-2026-11-16/hcp/{01-agent1,02-agent2,03-agent3,ticket-dossiers} |

## 2. 样本与验收覆盖

Agent-3 深度分析：6 票（选样见 03-agent3/cases.json）。原批 37 条。

| 样本类别 | 数量 |
|---|---|
| 清晰且当前仓可修（进入 Agent-3） | 6 |
| plan_only 报告产出 | 见 03-agent3/analysis-report.json summary |
| 实际应用补丁 | 0（本批禁止改码） |
| 业务验收 | 0（N/A） |

## 3. 质量指标

| 指标 | n/N | 说明 |
|---|---|---|
| 报告覆盖 | 6/6 | 全部落盘（含诚实阻断票） |
| G0（过程真实） | PASS | G0=PASS loc@1=4/6 loc@3=4/6 outcome=6/6 verdict=usable_pending_g3 |
| loc@1 / loc@3 | 见 score.json | 4/6 前缀命中；2 票（门禁联动/门禁列表）真值前缀 AccessControl 实际代码在 Resource/view/access 与 components/remoteConfig——Agent-3 按实际代码定位是正确的，真值前缀过窄 |
| outcome 一致 | total 6：plan_only 6 | applyFix=false 下可修票只允许 plan_only |
| 补丁应用/验收 | N/A | 本批禁止实际修复 |

## 4. 成本

Agent-2 $13.19（120 轮触顶后 salvage 续跑）；Agent-3 单票 SDK 会话

## 5. 逐票结果

见 [ticket-review-summary.csv](03-agent3/ticket-review-summary.csv)；逐票档案见 ticket-dossiers/（01 原始对照 / 02 Agent-2 线索 / 03 Claude 过程 / 04 修改与复核）。

## 6. 代表案例

### 成功案例
BGCM2026110304762 门禁列表刷新：theme 层 :not(.is-icon) 排除导致禁用图标仍高亮——CSS 规则链全复核通过；BGCM2026110304123 热备：HotSpare.vue showMessageLoading 机制复核通过

### 失败或截断案例
无阻断票；BGCM2026110303610 ONVIF 跳转机制存在但目标确认需人工

### 二次修复案例
本仓未跑二轮（二轮案例在 peitao 仓：ticket-dossiers/BGCM2026102809314/05-二轮修复.md）。

## 7. 环节归因与改进

| 环节 | 问题及票ID | 建议 |
|---|---|---|
| Agent-2 预算 | 120 turns 触顶 $13.19 | 微前端仓需分子仓多段 cartography 或调高预算 |
| skill 注入 | 仓内 use-hui-intl 业务 skill 缺 profiles frontmatter 未注入 | 给业务 skill 补 profiles 字段即可生效 |

## 8. 结论

- G0=PASS loc@1=4/6 loc@3=4/6 outcome=6/6 verdict=usable_pending_g3
- 详细机器评分见 03-agent3/score.json；人工根因评分（G3）已填入 ticket-review-summary.csv manualRootCauseScore 列。