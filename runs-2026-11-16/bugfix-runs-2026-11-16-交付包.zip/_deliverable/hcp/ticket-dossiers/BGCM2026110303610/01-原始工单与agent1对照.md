# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026110303610",
  "标题": "[WEB基础组(正式批)] 点击开启onvif按钮，应该跳转到onvif页面",
  "状态": "Open",
  "当前处理人": "USER_U",
  "处理人姓名": "魏亚5",
  "严重级别": "低",
  "缺陷/建议": "缺陷",
  "检出活动": "整机集成测试（BBIT）",
  "流程状态": "解决缺陷",
  "所属模块": "WEB基础组(正式批)",
  "版本": "V300R300C001",
  "测试环境": "https://10.33.43.25/#/portal",
  "发现人": "USER_X",
  "解决人": "USER_X",
  "创建时间": "2026-11-03 15:00:18",
  "flowInstId": "1344841266",
  "项目编号": "PJ14PD20260509167",
  "缺陷描述": "用例名称：通过ISUP协议添加编码设备前置条件：存在ISUP接入编码设备操作步骤：1.进入编码设备-添加2.选择ISUP协议3.输入设备ID(或设备ID段)4.保存测试数据：ISUP设备ID正确预期结果：设备添加成功，ISUP接入显示正常实际结果：点击开启onvif按钮，应该跳转到onvif页面问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026110303610",
  "title": "[WEB基础组(正式批)] 点击开启onvif按钮，应该跳转到onvif页面",
  "pool": "strict",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::unclear",
  "testModule": "WEB基础组(正式批)",
  "titleTag": "WEB基础组(正式批)",
  "intent": "unclear",
  "intentSource": "unclear",
  "intentConfidence": "low",
  "intentRationale": "no strong intent signal",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "点击开启onvif按钮，应该跳转到onvif页面",
  "expected": "设备添加成功，ISUP接入显示正常",
  "steps": "1.进入编码设备-添加2.选择ISUP协议3.输入设备ID(或设备ID段)4.保存",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-11-03 15:00:18",
  "duplicate": false,
  "semanticFree": false,
  "priority": 4.0,
  "revisionId": "BGCM2026110303610:v0",
  "sourceObserved": "点击开启onvif按钮，应该跳转到onvif页面",
  "sourceExpected": "设备添加成功，ISUP接入显示正常",
  "sourceSteps": "1.进入编码设备-添加2.选择ISUP协议3.输入设备ID(或设备ID段)4.保存",
  "attachmentRefs": null
}
```
