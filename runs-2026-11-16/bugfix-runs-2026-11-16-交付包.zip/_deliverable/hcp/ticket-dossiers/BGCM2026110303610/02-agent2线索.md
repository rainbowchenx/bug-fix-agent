# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026110303610",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::unclear",
  "title": "[WEB基础组(正式批)] 点击开启onvif按钮，应该跳转到onvif页面",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Resource/view/resource/camera/onvifStreamOptions.vue",
      "symbol": null,
      "why": "basename contains \"onvif\" from title/titleTag/testModule/intent",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Integration/view/gateWay/onvif/constants.js",
      "symbol": null,
      "why": "package/dir \"onvif\" from title/titleTag/testModule/intent",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Integration/view/gateWay/onvif/components/OnvifUserForm.vue",
      "symbol": null,
      "why": "basename contains \"onvif\" from title/titleTag/testModule/intent",
      "source": "grep"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "not_investigated",
  "searchedScopes": [],
  "openQuestions": []
}
```
