# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026110302952",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::i18n::在线设备发现未设置邮箱二",
  "title": "[WEB基础组(正式批)] 在线设备发现未设置邮箱二维码中文案按钮刷新溢出",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Resource/components/sadp_detection/action-bar.vue",
      "symbol": "refreshOnlineDevices",
      "why": "在线设备发现(SADP)顶部操作条：含 refresh/refresh_all 按钮与批量激活、设置密保弹框，与‘按钮刷新溢出’描述同域",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/Resource/components/sadp_detection/sadp-operation.vue",
      "symbol": "onPasswordReset",
      "why": "行内操作组件含密保重置(邮箱/问答/文件重置)与设备操作按钮，与‘未设置邮箱’密保提示相关",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
