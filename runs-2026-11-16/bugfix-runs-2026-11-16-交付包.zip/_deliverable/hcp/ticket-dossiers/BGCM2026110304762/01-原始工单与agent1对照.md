# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026110304762",
  "标题": "[WEB基础组(正式批)] 门禁设备列表刷新按钮置灰后图标还是高亮的",
  "状态": "Open",
  "当前处理人": "USER-28B112",
  "处理人姓名": "魏亚5",
  "严重级别": "低",
  "缺陷/建议": "缺陷",
  "检出活动": "整机集成测试（BBIT）",
  "流程状态": "解决缺陷",
  "所属模块": "WEB基础组(正式批)",
  "版本": "V300R300C001",
  "测试环境": "https://10.33.43.25/#/portal",
  "发现人": "USER-30706B",
  "解决人": "USER-30706B",
  "创建时间": "2026-11-03 16:12:37",
  "flowInstId": "1345142463",
  "项目编号": "PJ14PD20260509167",
  "缺陷描述": "用例名称：门禁设备列表加载前置条件：具备门禁设备管理权限操作步骤：1.进入门禁设备管理2.查看设备列表3.查看在线状态/类型测试数据：门禁设备已接入预期结果：门禁设备列表正确展示(明眸/一体机/道闸/门禁主机)实际结果：门禁设备列表刷新按钮置灰后图标还是高亮的问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026110304762",
  "title": "[WEB基础组(正式批)] 门禁设备列表刷新按钮置灰后图标还是高亮的",
  "pool": "strict",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::config::门禁设备列表刷新按钮置灰",
  "testModule": "WEB基础组(正式批)",
  "titleTag": "WEB基础组(正式批)",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "门禁设备列表刷新按钮置灰后图标还是高亮的",
  "expected": "门禁设备列表正确展示(明眸/一体机/道闸/门禁主机)",
  "steps": "1.进入门禁设备管理2.查看设备列表3.查看在线状态/类型",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-11-03 16:12:37",
  "duplicate": false,
  "semanticFree": false,
  "priority": 10.0,
  "revisionId": "BGCM2026110304762:v0",
  "sourceObserved": "门禁设备列表刷新按钮置灰后图标还是高亮的",
  "sourceExpected": "门禁设备列表正确展示(明眸/一体机/道闸/门禁主机)",
  "sourceSteps": "1.进入门禁设备管理2.查看设备列表3.查看在线状态/类型",
  "attachmentRefs": null
}
```
