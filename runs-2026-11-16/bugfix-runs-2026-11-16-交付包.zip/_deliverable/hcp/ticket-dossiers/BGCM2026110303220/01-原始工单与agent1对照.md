# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026110303220",
  "标题": "[WEB基础组(正式批)] 本地发现问答重置问题未翻译，本地发现和服务器网络都有问题",
  "状态": "Open",
  "当前处理人": "USER_U,USER_A,USER_BA",
  "处理人姓名": "魏亚5,李文青12,李冬冬28",
  "严重级别": "低",
  "缺陷/建议": "缺陷",
  "检出活动": "整机集成测试（BBIT）",
  "流程状态": "解决缺陷",
  "所属模块": "WEB基础组(正式批)",
  "版本": "V300R300C001",
  "测试环境": "https://10.33.43.25/#/",
  "发现人": "USER_X",
  "解决人": "USER_X,USER_DC,USER_AZ",
  "创建时间": "2026-11-03 14:42:43",
  "flowInstId": "1344767481",
  "项目编号": "PJ14PD20260509167",
  "缺陷描述": "  用例名称：本地网络正常发现设备列表数据前置条件：1.用户已登录平台2.平台已安装并连上SADP本地控件3.局域网内有1台待发现的在线编码设备操作步骤：1. 进入本地网络发现页面2. 点击开始发现按钮启动SADP服务3. 待控件上报设备列表测试数据：1台在线编码设备，设备序列号SN-0001 预期结果：1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示实际结果：本地发现问答重置问题未翻译问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026110303220",
  "title": "[WEB基础组(正式批)] 本地发现问答重置问题未翻译，本地发现和服务器网络都有问题",
  "pool": "strict",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::i18n::本地发现问答重置问题未翻",
  "testModule": "WEB基础组(正式批)",
  "titleTag": "WEB基础组(正式批)",
  "intent": "i18n",
  "intentSource": "heuristic",
  "intentConfidence": "high",
  "intentRationale": "i18n keywords",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "本地发现问答重置问题未翻译",
  "expected": "1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示",
  "steps": "1. 进入本地网络发现页面2. 点击开始发现按钮启动SADP服务3. 待控件上报设备列表",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-11-03 14:42:43",
  "duplicate": false,
  "semanticFree": false,
  "priority": 1.0,
  "revisionId": "BGCM2026110303220:v0",
  "sourceObserved": "本地发现问答重置问题未翻译",
  "sourceExpected": "1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示",
  "sourceSteps": "1. 进入本地网络发现页面2. 点击开始发现按钮启动SADP服务3. 待控件上报设备列表",
  "attachmentRefs": null
}
```
