# Agent-2 code-knowledge 候选

```json
{
  "defectId": "BGCM2026110303220",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::i18n::本地发现问答重置问题未翻",
  "title": "[WEB基础组(正式批)] 本地发现问答重置问题未翻译，本地发现和服务器网络都有问题",
  "candidates": [
    {
      "repoPath": ".",
      "path": "src/Resource/components/sadp_detection/sadp-operation.vue",
      "symbol": "onPasswordReset",
      "why": "onPasswordReset 中按 bySecurityQuestionEnabled 判定问答重置并组装 PasswordResetMode；密保能力查询同时影响本地/服务器网络两列表",
      "source": "codegraph"
    },
    {
      "repoPath": ".",
      "path": "src/Resource/i18n/en/hcpLang_name.json",
      "symbol": "hcp_devrsc_question_and_answer_reset",
      "why": "问答重置/邮箱重置 key(hcp_devrsc_mailbox_reset / hcp_devrsc_question_and_answer_reset) 各语言文件覆盖情况即‘未翻译’落点",
      "source": "grep"
    },
    {
      "repoPath": ".",
      "path": "src/Resource/components/sadp_detection/local-devices.vue",
      "symbol": "localDeviceList",
      "why": "本地发现列表组件，与‘本地发现和服务器网络都有问题’中的本地发现侧对应",
      "source": "codegraph"
    }
  ],
  "confidence": "medium",
  "gap": null,
  "investigationStatus": "complete",
  "searchedScopes": [],
  "openQuestions": []
}
```
