# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026110304635",
  "标题": "[WEB基础组(正式批)] 门禁设备联动配置页面按钮建议增加loading",
  "状态": "Open",
  "当前处理人": "USER_U",
  "处理人姓名": "魏亚5",
  "严重级别": "低",
  "缺陷/建议": "缺陷",
  "检出活动": "整机集成测试（BBIT）",
  "流程状态": "解决缺陷",
  "所属模块": "WEB基础组(正式批)",
  "版本": "V300R300C001",
  "测试环境": "https://10.33.43.25/#/portal",
  "发现人": "USER_X",
  "解决人": "USER_X",
  "创建时间": "2026-11-03 16:08:13",
  "flowInstId": "1345119428",
  "项目编号": "PJ14PD20260509167",
  "缺陷描述": "用例名称：门禁设备远程配置跳转前置条件：门禁设备在线操作步骤：1.进入门禁设备列表2.选择设备点击远程配置3.跳转设备配置界面测试数据：平台可连接设备预期结果：远程配置跳转成功，可进入设备设置实际结果：门禁设备联动配置页面按钮建议增加loading问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026110304635",
  "title": "[WEB基础组(正式批)] 门禁设备联动配置页面按钮建议增加loading",
  "pool": "strict",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::config::loading",
  "testModule": "WEB基础组(正式批)",
  "titleTag": "WEB基础组(正式批)",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "门禁设备联动配置页面按钮建议增加loading",
  "expected": "远程配置跳转成功，可进入设备设置",
  "steps": "1.进入门禁设备列表2.选择设备点击远程配置3.跳转设备配置界面",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-11-03 16:08:13",
  "duplicate": false,
  "semanticFree": false,
  "priority": 8.0,
  "revisionId": "BGCM2026110304635:v0",
  "sourceObserved": "门禁设备联动配置页面按钮建议增加loading",
  "sourceExpected": "远程配置跳转成功，可进入设备设置",
  "sourceSteps": "1.进入门禁设备列表2.选择设备点击远程配置3.跳转设备配置界面",
  "attachmentRefs": null
}
```
