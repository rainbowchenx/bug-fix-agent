# 原始工单 vs Agent-1 defect-batch 条目

## 原始 CSV 行

```json
{
  "缺陷单号": "BGCM2026110304123",
  "标题": "[WEB基础组(正式批)] 添加热备提示图标改成loading",
  "状态": "Open",
  "当前处理人": "USER-28B112",
  "处理人姓名": "魏亚5",
  "严重级别": "低",
  "缺陷/建议": "缺陷",
  "检出活动": "整机集成测试（BBIT）",
  "流程状态": "解决缺陷",
  "所属模块": "WEB基础组(正式批)",
  "版本": "V300R300C001",
  "测试环境": "https://10.33.43.25/#/portal",
  "发现人": "USER-30706B",
  "解决人": "USER-30706B",
  "创建时间": "2026-11-03 15:22:29",
  "flowInstId": "1344938065",
  "项目编号": "PJ14PD20260509167",
  "缺陷描述": "用例名称：热备设备配置与切换前置条件：存在主备两台编码设备操作步骤：1.进入编码设备-热备2.创建热备组3.配置主/备设备4.保存并验证测试数据：两台设备互联在线预期结果：热备组创建成功，主设备故障时切换备用实际结果：添加热备提示图标改成loading问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明"
}
```

## defect-batch 条目

```json
{
  "defectId": "BGCM2026110304123",
  "title": "[WEB基础组(正式批)] 添加热备提示图标改成loading",
  "pool": "strict",
  "clusterId": "PJ14PD20260509167::WEB基础组(正式批)::WEB基础组(正式批)::config::loading",
  "testModule": "WEB基础组(正式批)",
  "titleTag": "WEB基础组(正式批)",
  "intent": "config",
  "intentSource": "heuristic",
  "intentConfidence": "low",
  "intentRationale": "config keywords",
  "fieldType": null,
  "expectQuality": "explicit",
  "reasonCode": null,
  "reasonDetail": null,
  "observed": "添加热备提示图标改成loading",
  "expected": "热备组创建成功，主设备故障时切换备用",
  "steps": "1.进入编码设备-热备2.创建热备组3.配置主/备设备4.保存并验证",
  "status": "Open",
  "severity": "低",
  "createdAt": "2026-11-03 15:22:29",
  "duplicate": false,
  "semanticFree": false,
  "priority": 6.0,
  "revisionId": "BGCM2026110304123:v0",
  "sourceObserved": "添加热备提示图标改成loading",
  "sourceExpected": "热备组创建成功，主设备故障时切换备用",
  "sourceSteps": "1.进入编码设备-热备2.创建热备组3.配置主/备设备4.保存并验证",
  "attachmentRefs": null
}
```
