# Agent-2 cartography 运行说明（hcp）

## 运行配置

- 架构 commit：90e4744（2026-11-16）
- cartography-profile：micro_frontend（调用方传入）
- cartography-mode：sdk（Claude Agent SDK）
- CodeGraph：workDir 新建 `.codegraph` 索引（37 个微前端子仓，约 640 MB 索引）
- 输入：合并 26+11 条 CSV → 37 张票（strict 25 / needs_info 8 / locatable_only 4）

## 注入的 skill（discover_injected_skills 实测）

包内置同其他仓（code-cartography SOP 等 4 个 cartography skill）。子仓 `.claude/skills`（AccessControl 的 use-hui-intl / use-hc-ui / trellis-*、openspec-*）未声明 `profiles:` frontmatter，**未被注入**——本仓有真实业务 skill 却未生效，是重要观察点（i18n 相关票 use-hui-intl 本可提供线索）。

## 运行结果

- enrich=sdk；**120 turns；reason=max_turns；cost=$13.19**；dropped=duplicate:2/symbol:5
- 27/37 票有候选；10 票空候选（含 8 张 needs_info——符合「needs_info 不烧匹配」预期）
- SDK 会话因 max_turns 触顶退出，走了 salvage resume 补齐产出

## 仓 HEAD

- hcp HEAD: 8c0e17bcc（41 个 submodule，其中 39 个 dirty 为 submodule 指针状态）
