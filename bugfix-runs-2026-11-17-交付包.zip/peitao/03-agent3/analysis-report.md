# Repair report PJ14PD20260423284

tickets: 6

- BGCM2026102808455: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确
  cause: [Conditional / unverified] 日志导出链路（PC「导出 CSV」）在拼装导出行数据时把「接入」列写死为英文 'Local'/'Remote'，绕过 i18n；而同一份数据在客户端表格里是用 $t('local')/$t('remote_name') 渲染的，因此导出文件内容必然与客户端显示不一致、且在任何语言下都是英语。其次，导出表头/内容依赖的若干 key 在部分语言资源里仍是英文占位值（zh_CN 的 terminal_name/remote_name/access_name 等），进一步放大『导出内容显示英语』；另外 I18n.t 对目标语言缺失的 minorType key 会原样返回英文 key。
  claim [conditional]: PC 日志导出 exportCSVFile 用硬编码英文 'Local'/'Remote' 生成 access 列，完全绕过 i18n，是导出内容显示英语的直接代码级来源。
  claim [supported]: 同一 access 语义在页面/移动端渲染时使用 $t('local') / $t('remote_name')，因此导出与客户端显示不一致，正好违背『导出的日志文件内容和客户端日志内容一致，翻译正确』。
  claim [unverified]: zh_CN 语言资源自身存在英文占位值：Operations.json 的 terminal_name="terminal"、remote_name="remote"，Common.json 的 access_name="Access"；导出表头/终端列在中文下仍是英语。另外 th/in/lv 等语言的 remote_name 也为 "Remote"。
  claim [unverified]: mixin.js 对主/子类型用 I18n.t(szMajorType.toLowerCase())/I18n.t(szDescribe) 翻译；当目标语言 JSON 缺少该 minorType key 时 vue-i18n 原样返回英文 key，日志内容即显示英语。
  claim [supported]: excelExport 的表头 titles 全部经 I18n.t() 处理，表头不是英语残留的来源。
  question [choice]: 修复靶点不同：若缺陷语言是 zh_CN，则核心是语言资源补翻译；若是任意语言，则核心是导出列硬编码英文。; need 测试使用的具体语言项与导出文件截图/样例行
  question [blocking]: 决定修复落在前端 CSV 导出代码，还是设备端日志包（本仓库无此代码，将变为 not_code）。; need 导出文件是 .csv 还是设备打包的 txt
  remaining: 在 zh_CN 与 de 两种语言下执行：运维/维护日志页 → 导出 CSV，检查『接入』列与表头文案是否分别为本地化值。
  remaining: 对比导出 CSV 与页面表格同一行（时间、主类型、子类型、接入）是否一致且翻译正确。
  remaining: 若样例行仍有英语，抓取该行设备上报的 minorType 值，检查目标语言 Operations.json/Common.json 是否含该 key。
  remaining: 回归移动端日志列表/详情（复用同一 mixin）显示未受影响。
- BGCM2026102808006: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器
  cause: [Conditional / unverified] 遥控器按键类型下拉的选项直接取设备能力集枚举（row.options / customCaps.aSingleKeysOptN），而按键类型列的权限过滤代码在 2.1.3 需求中被注释掉（pc/remoteCtrlSet.vue:448-462、mobile/remoteCtrlSet.vue:1661-1670）；同时组装「关联用户」选项时只计算了 tapToRun 权限 isSupportTabToRun（deviceControl），从未计算关联用户的 relayControlMgr（Automation Control）权限。因此关联普通用户（无 Automation Control 权限）时，automationControl 仍出现在按键类型下拉并可保存。src/view/device 下 grep relayControl 无任何命中，说明遥控器/键盘配置页整体未接入该权限。
  claim [supported]: PC 遥控器表格的按键类型列直接使用 row.options，权限过滤代码已被注释，注释明确写着「2.1.3无需按照权限过滤，设备返回什么就展示什么」。
  claim [supported]: mixin.getSupportObj 只依据设备能力位（bSingleKeyRelay/bCombKeyRelay）判断是否支持「对象」列，不含关联用户权限，因此无法凭它禁用 automationControl。
  claim [conditional]: 组装 aUser 选项时只塞了 isSupportTabToRun（来自 deviceControl），未计算 relayControlMgr，因此 UI 层根本拿不到「关联用户是否有 Automation Control 权限」的信息。
  claim [supported]: 移动端 getCustomKeyOptions 的权限过滤被注释并直接 return options，按键类型选项全量透出。
  claim [unverified]: getRelayOpt 只按子系统交集过滤可选中继器，不做权限过滤，所以即便按键类型被限制，继电器对象列表也不会因权限变化。
  claim [supported]: 保存路径 setRemoteCtrlInfo 直接依赖 item.enable/item.value 组装下发表，无任何权限校验，前端不会返回失败。
  claim [unverified]: 仓库内已存在 Automation Control 权限的统一归一化字段 automationCtrlOperate = securityCP.relayControlMgr，可作为前端门禁数据源。
  question [verification]: 需要确认 UserLocalPermissionList/UserRemotePermissionList 记录里 Automation Control 权限的准确字段名，否则过滤条件会取空值（getValByKey 找不到即 falsy，可能误禁所有人）。; need 设备返回的 SearchUserLocalPermissionList 响应片段（含 securityCP 下的 relayControlMgr 或等价字段）
  question [choice]: 验收写的是「设置失败」，前端可选实现：隐藏/置灰选项（用户根本不能选） vs 允许选择但保存时报错。两者的改动点与文案不同。; need 产品/测试对「设置失败」的具体判定：是选项不可见，还是保存提示失败
  question [follow_up]: 历史遥控器按键已配置 automationControl 后关联用户被撤销权限，需要确定回退策略，避免显示非法值。; need 同族用例或产品说明中的回退预期
  remaining: 1. 静态校验改动文件：eslint/pinia 无关，跑项目现有 lint（如 npm run lint -- src/view/device/remoteCtrl）与 vue 模板编译
  remaining: 2. PC：设备管理 -> 用户管理 -> 选择普通 operator（无 Automation Control 权限）-> 遥控器页签 -> 编辑遥控器，确认按键 I/II/组合键的『类型』下拉不再出现 Automation Control
  remaining: 3. PC：把关联用户从有权限用户切到无权限用户，确认已选的 automationControl 被回退且『对象』列同步失效
  remaining: 4. 移动端 H5：同一场景确认 automationControl 不出现/不可选
  remaining: 5. 负向：仍尝试构造 automationControl 保存，确认按选定策略被拦截（校验失败或后端失败提示）
  remaining: 6. 回归：关联用户具备 Automation Control 权限时，automationControl 仍可选、可保存、继电器对象列表正常
- BGCM2026102902007: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1、设置成功2、可以通过该按键对主机进行所配置的操作成功
  cause: [Conditional / unverified] [Conditional / unverified —— 代码路径已 Read 确认，2s 时长与点击重定向机制未观测] PC 遥控器设置页在「取消关联全部子系统」时，同一宏任务内同步做了两段重活：(1) 多选下拉内的「取消全选」走 Form.handleCheckAllChange，一次性把 form[key] 置空（该函数上方注释自证「取消全选且数量太多的时候会卡」），并触发整份表单 computed / customKey 表格所有单元格重渲染；(2) 关联全部子系统开关 / 关联子系统多选的 change 走 mixin.changeAreaOption，它遍历 customKey 每一行就地改写 children.*.options、curChildValue、selectObj，最后把整份 form 交给 Form.setForm，而 setForm 对每个 key 执行 delete → $set('') → 赋值，使整表二次全量失效重渲染。代价是主线程被长时间占用（票据称约 2s，未采样）；阻塞结束后已排队的点击按当时的坐标派发，而此刻下拉里的 Group/Area option-group、multiple-limit 与 disabled 正因 val 为空/selectObj 被翻成 true 而位移（Area 组消失、组禁用状态翻转），于是点击落到另一个按键行或另一个 GROUP 选项上，写入了别的按键的 curChildValue —— 表现为「把其他按键关联误触」。注意：若该误写随保存下发，还会连带破坏用户验收目标第 2 条（按键执行的操作与配置一致），因此修复点同时是配置正确性问题，不只是性能问题。
  claim [unverified]: PC 遥控器页的「关联子系统」多选 change 与「关联全部子系统」开关 change 都调用 changeAreaOption。
  claim [unverified]: changeAreaOption 对 customKey 的每一行都重写 options / curChildValue / selectObj，并在末尾对整个 form 调 setForm；行内 getRelayOpt(val) 也在 forEach 内重复计算。
  claim [supported]: Form.setForm 对每个 key 执行 delete → $set('') → 赋值，使整份 form（含 customKey 表格与所有 scoped slot）全量失效重渲染；没有增量更新或分批/防抖控制。
  claim [conditional]: 多选下拉内的「全选/取消全选」由 Form 自己注册的 on.change 处理（handleCheckAllChange 直接赋值 form[key]），不经过字段 item.on.change，因此不会调用 changeAreaOption，各按键行派生 options 与 selectObj 会停留在旧值。
  claim [unverified]: 代码库已在该处留下「取消全选且数量太多的时候会卡」的注释与临时规避（>16 个选项时先隐藏 .el-select__tags 再复原），说明清空大量已选项是已知慢操作，属于同类症状的既有旁证。
  claim [conditional]: 约 2s 的主线程阻塞由「同步清空 + changeAreaOption 逐行重写 + setForm 全量重渲染」共同造成；各部分占比未采样，属条件性结论。
  claim [conditional]: 阻塞期间用户的点击被排队，派发时下拉内容与位置已改变（Area option-group 因 res 为空而消失、row.selectObj 被置 true 导致组禁用翻转），于是落到位移后的元素，改写了另一个按键的 curChildValue，形成「把其他按键关联误触」。
  claim [unverified]: 该链路无防抖、无「更新中」标志位、无下拉主动关闭保护；remoteCtrl 目录内除初始化时一个 100ms setTimeout 外没有其它 setTimeout。
  claim [conditional]: 若误触产生的错误关联被保存，则下发的 RemoteMgr/SingleRemoteBasicInfo 与 RemoteLinkageParam 会和用户配置不符，连带影响用户验收目标第 2 条（按键实际执行的操作）。
  claim [unverified]: 本单要求的是交互不冻结、按键归属不串改，未要求移除「取消关联全部子系统」能力；修复不得改变该能力的可用性。
  claim [conditional]: 附带健壮性问题（非本单因果）：对象列 render 对 SingleRemoteBasicInfo-linkageSubSystems 直接 .indexOf，未做空值保护，设备不返回该字段时会在渲染中抛错。
  question [choice]: 「取消关联全部子系统」可能经三条互不相同的代码入口（下拉内取消全选 → Form.handleCheckAllChange；逐个删除 tag → el-select input → 字段 on.change；关闭「关联全部子系统」开关 → 另一段 change 分支），决定首改点与是否必须改公共组件 Form.vue。; need 测试步骤截图或录屏，标明是点「全选」复选框取消、删 tag，还是关开关
  question [verification]: 2s 长任务的构成（el-select tag 销毁 vs setForm 全量重渲染 vs changeAreaOption 逐行重算）未采样，直接影响优化重点与是否需要动公共 Form.vue。; need Chrome Performance 火焰图/长任务分解（含 customKey 行数与子系统数量）
  question [choice]: 平台不同则组件结构不同：PC 是 Group/Area el-option-group + selectObj 分组禁用；移动端是 *-obj 单选/多选字段。选错平台会把修复放到错误的视图文件。; need 缺陷所在端（PC / 移动端 / 两者）与对应浏览器与版本
  question [verification]: 决定缺陷影响面是「仅界面卡顿+临时显示错」还是「已写入设备的错误关联」，后者直接触及用户验收目标第 2 条。; need 误触后是否点了保存；保存后重新进入页面/读设备参数，另一个按键的关联值是否被改写
  remaining: PC 遥控器管理 → 编辑遥控器 → 准备 ≥16（最好数十个）子系统，全部关联到按键 I。
  remaining: 开启 DevTools Performance，分别用三种方式执行「取消关联全部子系统」（下拉内取消全选 / 逐个删除 tag / 关闭关联全部子系统开关），记录长任务时长与构成，确认性能瓶颈归属。
  remaining: 在卡顿窗口内立即点击另一个按键（如按键 II）对象下拉中的 Group 选项，核对按键 II 的 curChildValue 与最终下发参数是否被意外改写（复现误触）；再确认保存后重新进入页面，另一按键的关联值是否已被写入设备。
  remaining: 改动后重复上述动作：单次主线程任务显著下降（目标 <100ms），连续快速点击不会改变相邻按键的关联值。
  remaining: 回归用户验收目标：设置按键 I 为「撤防/关联多个子系统」并保存成功（第 1 条），再确认该按键实际能对配置的子系统执行撤防（第 2 条），确认取消关联能力仍可用、未被移除。
  remaining: 回归复用同 mixin.changeAreaOption 的 src/view/device/keypad/pc/keypadSet.vue，以及其它使用公共 Form.setForm 的页面，避免公共组件改动引入连带回归。
- BGCM2026102809314: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”
  cause: [Conditional / unverified] “Auto Check for Upgrades”开关在 PC 升级页（upgrade/pc/upgrade.vue）与探测器/外设在线升级页（localOnlineUpdate.vue）中，仅以 oCaps.bSptOnlineUpgrade（= 设备支持 SystemUpgrade/TriggerManualDetection 且非 ezviz 模式）作为 isShow 条件渲染，没有任何 SystemUpgrade/AutoUpgradeCfg 能力门控；因此只要设备支持“在线升级”，即使交互稿里没有该控件、设备也不支持自动检查更新配置，页面依旧显示该开关。同时该开关的确认文案键 autoCheckEnableSync_msg 的 en_US 文案（“Auto check upgrades for control panel and detector/peripheral will be enabled. Continue?”）与本用例期望文案（“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”）不一致；并且同一 SystemUpgrade/AutoUpgradeCfg 标识在 upgradeConfig/mixin.js 中以 enabled 读写，而 upgrade.vue 中以 autoCheck 读写，字段契约自相矛盾。
  claim [supported]: 升级页的“自动检查更新”开关 isShow 只取 oCaps.bSptOnlineUpgrade，没有 AutoUpgradeCfg 能力门控。
  claim [supported]: bSptOnlineUpgrade 仅由 TriggerManualDetection 能力决定，与“自动检查更新”能力无关。
  claim [conditional]: 因此只要设备支持在线升级，交互稿中不存在的 Auto Check for Upgrades 控件仍会显示，即缺陷描述的“交互中无该控件、实际页面显示该按钮”。
  claim [conditional]: 同一 SystemUpgrade/AutoUpgradeCfg 标识在 upgrade.vue 中读写成 autoCheck，在 upgradeConfig/mixin.js 中读写成 enabled，字段契约不一致；若真实 schema 为 enabled，则 autoCfg?.autoCheck 恒为 undefined、set 报文 {autoCheck: val} 非法。
  claim [unverified]: en_US 的确认文案与用例期望文案字面不一致（缺 'Auto-check' 连字符、'upgrades' 语序不同）。
  claim [supported]: 同一自动检查更新开关在 detectorAndPeripheral 的在线升级 Tab 中重复实现，需同步修改才能做到“统一显示”。
  question [choice]: 交互稿（服务中提示自动更新）与用例预期（Web 弹出使能确认框）方向相反：一个要求不在该页显示该控件，一个要求该控件存在并弹提示。选择不同，修复目标完全不同。; need 产品/交互确认：Upgrade Control Panel 页是否保留 Auto Check for Upgrades 开关；若保留，显示条件是什么（能力集字段/许可证）。
  question [verification]: 字段 autoCheck vs enabled 的取舍决定 set 报文是否有效，影响开关能否落盘。; need 被测设备 GetFunctions/能力集中 operationsDomains → SystemUpgrade/AutoUpgradeCfg 的 schema（是否含 enabled / autoCheck）以及一次 Get/AutoUpgradeCfg 实际回包。
  remaining: 1. 在支持 SystemUpgrade/AutoUpgradeCfg 的设备上进入 Maintenance and Security → Maintenance → Upgrade Control Panel，确认“Auto Check for Upgrades”开关显隐符合交互稿。
  remaining: 2. 在不支持 AutoUpgradeCfg（仅支持 TriggerManualDetection）的设备上，确认该开关不显示（或按确认的结论移除）。
  remaining: 3. 使能开关，检查确认框文案与“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”逐字一致。
  remaining: 4. 抓包核对 Set SystemUpgrade/AutoUpgradeCfg 报文字段与 Get 回包字段一致，刷新页面后开关状态保持。
  remaining: 5. 切到 Maintenance → Detector/Peripheral 在线升级 Tab，确认同一开关表现与主机升级页一致。
- BGCM2026103000881: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.无法配置码率类型
  cause: [Conditional / unverified] [条件性结论 / 未验证] 移动端“视频参数”页（src/view/device/ipc/mobile/videoParameter.vue）的 submit 在 ONVIF 接入的 IPC 下仍无条件把 bitrateType 打进 VideoCodingParams 的 set 报文（并附带 maxBitrate/constantBitRate 等编码字段），设备整包拒绝后前端 Response.saveState 展示 operateFailed（'Operating failed.'）——这一步的因果链依赖设备日志确认，未验证。另有一条独立可验证的代码事实：“码率类型”控件 disabled 只依赖从路由 query 透传的 accessProtocolType，query 为空时控件不会置灰，使缺陷表现为“像可以配置→保存即失败”。两条都指向同一验收目标：ONVIF 下码率类型应不可配置且保存不报 Operating failed。
  claim [unverified]: 代码层面 'Operating failed.' 是 i18n key `operateFailed` 的英文文案，而 `operateFailed` 在 Response 的设备错误码表中对应 `0x00100002`。
  claim [conditional]: 缺陷中用户看到的 'Operating failed.' 来自设备对某次 set 请求返回的错误码（经 Response.saveState 翻译），而不是前端 JS 异常。
  claim [unverified]: 移动端 videoParameter.submit 构造的 VideoCodingParams set 报文固定包含 `bitrateType: form.bitrateType`，且该值在 ONVIF 通道 GET 未返回时被回填默认 `'constant'`，没有任何按协议裁剪的分支。
  claim [unverified]: 移动端“码率类型”的 disabled 判定依赖 `this.accessProtocolType`，而该字段仅在 setIPC(row) 中由 `row?.accessProtocolType` 赋值（row 即 `this.$route.query`），因此置灰能力完全取决于路由 query 透传。
  claim [unverified]: 在实际 App 场景中该路由 query 的 accessProtocolType 可能为空，导致 ONVIF 通道“码率类型”不被置灰——这是置灰门槛失效的触发条件。
  claim [conditional]: ONVIF 通道的 VideoCodingParams set 不接受 bitrateType 等编码字段，设备因此整包返回 0x00100002，最终呈现为 Operating failed。
  claim [supported]: PC 端存在同构下发路径：singleChannelConfig.getAjax 与 deviceView.submit 均无条件把 bitrateType 放进 VideoCodingParams set，仅靠 `szIpcProtoType === 'ONVIF'` 置灰不构成报文层保护。
  claim [conditional]: 本 ticket 的验收目标（用户确认的期望）是“无法配置码率类型”，即 ONVIF 通道下码率类型必须不可配置且保存不出现 Operating failed；修复不得用其它行为（如仅改录像时间、仅改防区字段）替代该目标。
  claim [conditional]: 若 c6 成立，则修复锚点为在三条 set 路径中对 ONVIF 通道剔除 bitrateType（或跳过 VideoCodingParams set），并用不依赖路由 query 的协议来源驱动置灰；该结论尚未被设备行为观测证实。
  question [blocking]: 若返回错误码的 set 请求不是 VideoCodingParams（例如 EventRecord、setVideoChannelTrigger 或 ModifyVideoChannel），则修复锚点会从 bitrateType 报文裁剪改为其它请求参数问题，属于会改变修复目标的阻塞项。; need pagespy 回放（fileId=local.832f4c0c3da1c7a5e23a37951108c1e7）中保存动作的网络请求/响应原文：请求 URL、请求体 JSON、返回码（是否 0x00100002）
  question [choice]: PC 端 singleChannelConfig.getAjax 与 deviceView.submit 存在同构缺陷；是否同批修复影响改动范围与回归面，但不改变移动端本次报错的机制。; need 缺陷单是否要求覆盖 PC 端；以及本次版本是否接受跨端同步改动
  question [choice]: ONVIF 语义存在两种合法实现：整体不下发 VideoCodingParams set，或剔除 bitrateType 等不支持字段但保留其它可配项。二者对“无法配置码率类型”都能满足，但改动形态与副作用不同，需要产品/协议口径。; need 设备协议文档/接口能力集中 ONVIF 通道 VideoCodingParams 的可写字段清单
  question [verification]: 置灰门槛是否在生产路径真空转，决定 c4 是否足以解释“控件未置灰”的表现；该结论不影响 c3 的报文层缺陷，但影响修复第 2 步的必要性与形态。; need 移动端设备列表→ipcSet 的跳转参数（是否带 accessProtocolType），或真机复现时脚手架的 $route.query 打印
  question [follow_up]: 错误码表在读到位置被截断，存在其它路径产出 operateFailed 文案的可能；仅影响证据强度，不改变本次修复锚点。; need src/common/vue/service/response.js 中完整错误码表，确认 operateFailed 的全部来源码
  remaining: 打开缺陷日志 pagespy 回放，核对保存动作中 VideoCodingParams(set) 的请求体是否含 bitrateType、响应码是否为 0x00100002；同时记录 EventRecord / setVideoChannelTrigger / ModifyVideoChannel 的响应
  remaining: 以 ONVIF 接入 IPC，进入视频参数页：记录“码率类型”控件是否置灰、$route.query 中 accessProtocolType 的实际取值、以及提交时的报文
  remaining: 改动后回归：ONVIF 通道保存视频参数不再出现 Operating failed，码率类型不可配置；HIKPrivate/ISAPI 通道码率类型可正常配置保存；协议字段缺失时 HIK 行为不变
  remaining: 静态校验：对改动文件执行 eslint（不运行 dev/build）
- BGCM2026110304188: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1、退出安装模式成功，键盘有操作成功的提示
  cause: 用户管理页 (src/view/config/userManage/userList/pc/userList.vue) 在 created() 里开了一个 fullscreen 的 Loading（文案即 waitTips = "Please wait."），而这个遮罩唯一的关闭时机是 this.getTable().finally(...)。getTable -> mixin.getList 内部串了多条无失败兜底的链路：① getSubSysName 走 Device.getBatchRequest 的 Promise 只有 resolve 分支，批量请求失败/永挂时该内部 Promise 永不 settle；② searchAllUserInfoCfg / searchAllUserLocalPermission / searchAllUserRemotePermission 的分页递归只在「累计条数 >= totalMatches」时 resolve，设备上报 totalMatches 与实际 matchResults 不一致（或 matchResults 缺失）时会无限分页、永不 settle；③ getList 中 `if (!aUserInfo.length) reject()` 后没有 return，后续仍继续执行。任一环节永不 settle，getTable() 的 Promise 就不会结束，finally 不会触发，全屏 Please wait. 就永久停留。这与本次「本地 operator 登录 + 安装模式下」相关是因为 operator 的用户管理能力/权限最小，最容易命中「能力集缺字段直接解引用」与「空/异常用户列表」分支。
  claim [supported]: 用户管理列表页的全屏 "Please wait." 遮罩只在 getTable() 的 finally 中关闭，没有超时/失败兜底，因此任何上游 Promise 永不 settle 都会导致遮罩永久残留。
  claim [conditional]: getSubSysName 的 ezviz 分支用 `new Promise(resolve1 => Device.getBatchRequest(...).then(resolve1))` 包装，缺少 reject/catch，批量请求失败时该 Promise 永不 settle，使 buildListData -> getList 永不结束。
  claim [conditional]: 三个 searchAll* 分页函数只在「累计 >= res.totalMatches」时 resolve，且对 getNodeCaps(...)[1] 在 Promise 外直接下标解引用，能力集缺字段或缺 totalMatches 一致性时会抛错或无限分页。
  claim [unverified]: getList 中 `if (!aUserInfo.length) { reject(); }` 后未 return，后续仍会继续做权限合并与 buildListData，可能产生二次异常而不是尽快收尾。
  claim [supported]: refresh() 的遮罩只在 .then 关闭（未用 finally），请求失败时同样会残留 "Please wait."，与该缺陷表现同族。
  claim [supported]: 缺陷文本的验收目标（退出安装模式成功且键盘有成功提示）与本处 web 遮罩问题不是同一机制；本分析只针对 observed 的 Please wait. 现象，不改变验收目标。
  question [verification]: 需要 pagespy 回放中的网络面板确认卡住时未返回的 CGI，才能区分「分页死循环」与「批量请求无失败分支」哪一个是本次触发点。; need local.d166abf3c98a0eb29707205ab85a98e1 回放中的 pending/failed 请求列表与耗时
  question [choice]: 修复范围选择：只做「遮罩兜底 + return」的稳健性修复，还是同时改造分页/批量请求的 settle 保证。; need 确认是否允许改动 mixin.js 的 getList 分页与 getSubSysName 包装逻辑
  remaining: 本地 operator 账号登录（安装模式开启）进入 配置->用户管理，观察是否仍停留在 Please wait.；Network 面板确认 SearchUserInfoCfg / SearchUserSubSystemBasicInfo 等请求是否有未返回或无限重复。
  remaining: 断网/阻塞某 CGI 模拟上游失败，验证遮罩在超时后自动关闭并给出失败提示（不再永久停留）。
  remaining: 构造 totalMatches 与 matchResults 不一致的 mock 响应，验证分页递归能终止且页面可渲染。
  remaining: lint / typecheck 改动文件（该仓库为 Vue2 + JS 项目，按项目现有脚本执行）。
