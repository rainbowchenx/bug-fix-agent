# BGCM2026102809314 [CRA安全认证（WEB需求）] 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [CRA安全认证（WEB需求）] 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中） | [CRA安全认证（WEB需求）] 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中） | 否 |
| 测试模块 | CRA安全认证（WEB需求） | CRA安全认证（WEB需求） | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1. web端进入Maintenance and Security—Maintenance—Upgrade Control Panel 2. 使能Auto Check for Upgrades按钮 | 1. web端进入Maintenance and Security—Maintenance—Upgrade Control Panel 2. 使能Auto Check for Upgrades按钮 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?” | 1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?” | 否 |
| 实际结果 | 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中） | 交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中） | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：验证使能Auto Check for Upgrades按钮弹出确认提示前置条件：操作步骤：1. web端进入Maintenance and Security—Maintenance—Upgrade Control Panel 2. 使能Auto Check for Upgrades按钮测试数据：预期结果：1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”实际结果：交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）问题：1.交互中无auto check for upgrade，实际web页面显示该按钮，请统一显示（交互提示自动更新在服务中）2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/view/operations/maintain/upgrade/pc/upgrade.vue` | exact basename "upgrade" from title/titleTag/testModule/intent | grep |
| `src/view/operations/maintain/upgrade/mixin.js` | package/dir "upgrade" from title/titleTag/testModule/intent | grep |
| `src/view/operations/maintain/upgrade/otap.js` | package/dir "upgrade" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：导航路径来自 Agent-2 soft-start（upgrade.vue / mixin.js / otap.js），经 CodeGraph 探索后在 worktree 中逐一 Read 确认。注意：route 表 src/router/operations/pc.js 只是路由装配，不是修复点；otap.js 的 GetAutoUpgradeCfg/SetAutoUpgradeCfg 对应 operations.js:165-171 的 SystemUpgrade/AutoUpgradeCfg 模型，是字段契约判断的依据。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`b3bbd295-4cde-46bb-9d99-3805c80a390d`
- attemptId：`f016fef427c2`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1. web弹出提示框 2. 提示框显示文本“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”
- **代码关联**：src/view/operations/maintain/upgrade/pc/upgrade.vue; src/view/operations/maintain/upgrade/mixin.js; src/view/operations/maintain/upgradeConfig/mixin.js; src/common/static/i18n/en_US/Operations.json; src/view/operations/maintain/detectorAndPeripheral/pc/components/localOnlineUpdate.vue
- **机制**：[Conditional / unverified] “Auto Check for Upgrades”开关在 PC 升级页（upgrade/pc/upgrade.vue）与探测器/外设在线升级页（localOnlineUpdate.vue）中，仅以 oCaps.bSptOnlineUpgrade（= 设备支持 SystemUpgrade/TriggerManualDetection 且非 ezviz 模式）作为 isShow 条件渲染，没有任何 SystemUpgrade/AutoUpgradeCfg 能力门控；因此只要设备支持“在线升级”，即使交互稿里没有该控件、设备也不支持自动检查更新配置，页面依旧显示该开关。同时该开关的确认文案键 autoCheckEnableSync_msg 的 en_US 文案（“Auto check upgrades for control panel and detector/peripheral will be enabled. Continue?”）与本用例期望文案（“Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?”）不一致；并且同一 SystemUpgrade/AutoUpgradeCfg 标识在 upgradeConfig/mixin.js 中以 enabled 读写，而 upgrade.vue 中以 autoCheck 读写，字段契约自相矛盾。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | 升级页的“自动检查更新”开关 isShow 只取 oCaps.bSptOnlineUpgrade，没有 AutoUpgradeCfg 能力门控。 | fact | `supported` |  |
| c2 | bSptOnlineUpgrade 仅由 TriggerManualDetection 能力决定，与“自动检查更新”能力无关。 | fact | `supported` |  |
| c3 | 因此只要设备支持在线升级，交互稿中不存在的 Auto Check for Upgrades 控件仍会显示，即缺陷描述的“交互中无该控件、实际页面显示该按钮”。 | conclusion | `conditional` | 被测设备能力集中存在 TriggerManualDetection 但缺失/不适用 AutoUpgradeCfg（需用设备能力集确认） |
| c4 | 同一 SystemUpgrade/AutoUpgradeCfg 标识在 upgrade.vue 中读写成 autoCheck，在 upgradeConfig/mixin.js 中读写成 enabled，字段契约不一致；若真实 schema 为 enabled，则 autoCfg?.autoCheck 恒为 undefined、set 报文 {autoCheck: val} 非法。 | hypothesis | `conditional` | 两侧访问的是同一 CGI/同一 schema 节点 SystemUpgrade/AutoUpgradeCfg |
| c5 | en_US 的确认文案与用例期望文案字面不一致（缺 'Auto-check' 连字符、'upgrades' 语序不同）。 | fact | `unverified` |  |
| c6 | 同一自动检查更新开关在 detectorAndPeripheral 的在线升级 Tab 中重复实现，需同步修改才能做到“统一显示”。 | fact | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：先按交互稿统一“是否显示”的判断口径：用设备能力 SystemUpgrade/AutoUpgradeCfg.enabled 作为开关的 isShow 门控（与 upgradeConfig 页保持一致），若交互确实要求不显示则直接移除该字段；随后把同一 CGI 的读写字段统一为真实 schema 字段，最后按用例期望文案统一 i18n。两处重复实现的开关（upgrade.vue 与 localOnlineUpdate.vue）必须同步。
- 步骤：
  1. 1. 明确目标（q1）：保留则做能力门控，删除则移除 upgrade.vue 的 autoDetectionEnabled 字段及 initAutoUpgradeCfg 调用。
  1. 2. 在 src/view/operations/maintain/upgrade/mixin.js getCap() 中新增能力位，例如 this.oCaps.bSptAutoUpgradeCfg = Utils.isDef(Utils.getNodeCaps('operationsDomains', 'AutoUpgradeCfg', 'enabled'));，与 upgradeConfig/mixin.js:33 的口径一致。
  1. 3. upgrade.vue 的该字段 isShow 由 this.oCaps?.bSptOnlineUpgrade 改为 this.oCaps?.bSptAutoUpgradeCfg（保留在线升级/检查更新两块仍按 bSptOnlineUpgrade）。
  1. 4. 统一 AutoUpgradeCfg 读写字段：确认 schema 后，把 upgrade.vue 中 autoCfg?.autoCheck 与 setAutoUpgradeCfg({autoCheck: val}) 改为一致字段（大概率是 enabled），失败回滚分支同步。
  1. 5. 同步修改 detectorAndPeripheral/pc/components/localOnlineUpdate.vue 的 autoUpgradeFields：同样加能力门控并统一字段，避免两页表现不一致。
  1. 6. 按用例期望文案更新 i18n：en_US（及其余语言同条）autoCheckEnableSync_msg → "Auto-check for control panel and detector/peripheral upgrades will be enabled. Continue?"，Disable 条对应改；若采用“移除开关”方案则本步不做。
  1. 7. 自测：分别在支持/不支持 AutoUpgradeCfg 的设备上进入该页，确认开关显隐、使能后弹框文案、Set 请求成功落盘且刷新后状态保持。
- 目标文件：`src/view/operations/maintain/upgrade/pc/upgrade.vue`, `src/view/operations/maintain/upgrade/mixin.js`, `src/view/operations/maintain/detectorAndPeripheral/pc/components/localOnlineUpdate.vue`, `src/common/static/i18n/en_US/Operations.json`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['1. 在支持 SystemUpgrade/AutoUpgradeCfg 的设备上进入 Maintenance and Security → Maintenance → Upgrade Control Panel，确认“Auto Check for Upgrades”开关显隐符合交互稿。', '2. 在不支持 AutoUpgradeCfg（仅支持 TriggerManualDetection）的设备上，确认该开关不显示（或按确认的结论移除）。', '3. 使能开关，检查确认框文案与“Auto-check for control panel and detector/peripheral up；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/view/operations/maintain/upgrade/`
- 首候选：`src/view/operations/maintain/upgrade/pc/upgrade.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
