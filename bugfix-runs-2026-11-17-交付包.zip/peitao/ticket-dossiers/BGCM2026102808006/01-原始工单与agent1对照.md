# BGCM2026102808006 [遥控器管理] 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [遥控器管理] 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项 | [遥控器管理] 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项 | 否 |
| 测试模块 | 遥控器管理 | 遥控器管理 | 否 |
| 前置条件 | 遥控器关联用户无AutomationControl | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1、设置遥控器的按键I为以下功能，按键操作，查看结果 | 1、设置遥控器的按键I为以下功能，按键操作，查看结果 | 否 |
| 测试数据 | 操作继电器（AutomationControl） | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器 | 1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器 | 否 |
| 实际结果 | 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项 | 遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：设置继电器操作失败_AutomationControl前置条件：遥控器关联用户无AutomationControl操作步骤：1、设置遥控器的按键I为以下功能，按键操作，查看结果测试数据：操作继电器（AutomationControl）预期结果：1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器实际结果：遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项问题：遥控器关联普通用户无Automation Control权限，遥控器仍能设置Automation Control选项https://zero.hikvision.com.cn/pagespy/#/replay?url=https://zero.hikvision.com.cn/pagespy/api/v1/log/download?fileId=local.74ddd59efa8ec8c0e7a197ec8d0b0787
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/view/advanceSetting/automation/pc/automation.vue` | exact basename "automation" from title/titleTag/testModule/intent | grep |
| `src/view/advanceSetting/automation/mobile/ArmDisarmConfig.vue` | package/dir "automation" from title/titleTag/testModule/intent | grep |
| `src/view/advanceSetting/automation/mobile/AutoActionConfig.vue` | package/dir "automation" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：架构路径：router/device/pc.js -> view/device/remoteCtrl/pc/remoteCtrlSet.vue（用户管理抽屉复用同一组件，isUserPage=true）。权限归一化入口在 common/vue/service/permission/index.js（automationCtrlOperate = securityCP.relayControlMgr），但遥控器目录（src/view/device/remoteCtrl/**）内 grep relayControl 零命中，说明该模块尚未接入此权限；keypad 为同构缺陷。软启动给出的 advanceSetting/automation 三条候选与「遥控器管理」不符，已排除。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`110a49f0-dd9d-43e0-8095-147f477f2bb0`
- attemptId：`50ba21bd5fbb`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1、设置失败，遥控器关联用户无AutomationControl，无法控制继电器
- **代码关联**：src/view/device/remoteCtrl/pc/remoteCtrlSet.vue; src/view/device/remoteCtrl/mixin.js; src/view/device/remoteCtrl/mobile/remoteCtrlSet.vue
- **机制**：[Conditional / unverified] 遥控器按键类型下拉的选项直接取设备能力集枚举（row.options / customCaps.aSingleKeysOptN），而按键类型列的权限过滤代码在 2.1.3 需求中被注释掉（pc/remoteCtrlSet.vue:448-462、mobile/remoteCtrlSet.vue:1661-1670）；同时组装「关联用户」选项时只计算了 tapToRun 权限 isSupportTabToRun（deviceControl），从未计算关联用户的 relayControlMgr（Automation Control）权限。因此关联普通用户（无 Automation Control 权限）时，automationControl 仍出现在按键类型下拉并可保存。src/view/device 下 grep relayControl 无任何命中，说明遥控器/键盘配置页整体未接入该权限。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | PC 遥控器表格的按键类型列直接使用 row.options，权限过滤代码已被注释，注释明确写着「2.1.3无需按照权限过滤，设备返回什么就展示什么」。 | fact | `supported` |  |
| C2 | mixin.getSupportObj 只依据设备能力位（bSingleKeyRelay/bCombKeyRelay）判断是否支持「对象」列，不含关联用户权限，因此无法凭它禁用 automationControl。 | fact | `supported` |  |
| C3 | 组装 aUser 选项时只塞了 isSupportTabToRun（来自 deviceControl），未计算 relayControlMgr，因此 UI 层根本拿不到「关联用户是否有 Automation Control 权限」的信息。 | conclusion | `conditional` | aMatchLocal/aMatchCloud 记录可通过 getValByKey 取到 relayControlMgr |
| C4 | 移动端 getCustomKeyOptions 的权限过滤被注释并直接 return options，按键类型选项全量透出。 | fact | `supported` |  |
| C5 | getRelayOpt 只按子系统交集过滤可选中继器，不做权限过滤，所以即便按键类型被限制，继电器对象列表也不会因权限变化。 | fact | `unverified` |  |
| C6 | 保存路径 setRemoteCtrlInfo 直接依赖 item.enable/item.value 组装下发表，无任何权限校验，前端不会返回失败。 | fact | `supported` |  |
| C7 | 仓库内已存在 Automation Control 权限的统一归一化字段 automationCtrlOperate = securityCP.relayControlMgr，可作为前端门禁数据源。 | fact | `unverified` |  |

## ④ 最终修改判断与验证

- **建议修改**：在遥控器配置链路中引入「关联用户 Automation Control 权限」判定：mixin 组装 aUser 时补 relayControlMgr 标记，PC 表格按键类型列与移动端 getCustomKeyOptions 依该标记从选项中剔除/置灰 automationControl，并在保存前按同一条件拦截（按验收要求给出失败提示或不进入下发）。键盘页同样模式但不在本单范围。
- 步骤：
  1. 1. src/view/device/remoteCtrl/mixin.js getRemoteCtrlInfo：在 aUserInfo.forEach 的 aMatchLocal/aMatchCloud 分支里补充 isSupportRelayControl = Utils.getValByKey(aMatchLocal[0]/aMatchCloud[0], 'relayControlMgr') \|\| false，并随 aUserOpt.push 输出（与现有 isSupportTabToRun 并列）。
  1. 2. src/view/device/remoteCtrl/pc/remoteCtrlSet.vue optionFields 的『类型』列：恢复/重写过滤逻辑——取 oBasicInfo.szLinkedUser 对应 aUser 的 isSupportRelayControl，为 false 时从 options 中剔除 value==='automationControl'，若 row.value 恰为 automationControl 则回退为 options[0]?.value（或 'off'）并清空 curChildValue。
  1. 3. src/view/device/remoteCtrl/mobile/remoteCtrlSet.vue getCustomKeyOptions：按同一标记过滤 options 中的 automationControl；并在 initFormData 中恢复等价于 resetTapToRunLinkage 的重置逻辑（当前调用被注释），把非法值回落。
  1. 4. 保存前校验：pc/remoteCtrlSet.vue save()/renderContent 的 validRes 与 mobile save 中，若 customKey 存在 enable && value==='automationControl' 且关联用户无权限，则置 validRes=false（或按产品要求提示保存失败），不调用 setRemoteCtrlInfo；如产品要求「设置失败」提示，则在 setRemoteCtrlInfo 前置拦截。
  1. 5. 同步修正 getRelayOpt/getRelayOptions：权限为 false 时直接把 automationControl 相关对象列表置空，避免残留可选项。
  1. 6. 键盘页 src/view/device/keypad/mixin.js、pc/keypadSet.vue、mobile/keypadSet.vue 为同模式缺陷，建议单独提单处理，本单不扩散改动。
- 目标文件：`src/view/device/remoteCtrl/mixin.js`, `src/view/device/remoteCtrl/pc/remoteCtrlSet.vue`, `src/view/device/remoteCtrl/mobile/remoteCtrlSet.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['1. 静态校验改动文件：eslint/pinia 无关，跑项目现有 lint（如 npm run lint -- src/view/device/remoteCtrl）与 vue 模板编译', '2. PC：设备管理 -> 用户管理 -> 选择普通 operator（无 Automation Control 权限）-> 遥控器页签 -> 编辑遥控器，确认按键 I/II/组合键的『类型』下拉不再出现 Automation Control', '3. PC：把关联用户从有权限用户切到无权限用户，确认已选的 automationControl 被回退且『对象』列同步失效', '4. 移动端 H5；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/view/device/remoteCtrl/`
- 首候选：`src/view/device/remoteCtrl/pc/remoteCtrlSet.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
