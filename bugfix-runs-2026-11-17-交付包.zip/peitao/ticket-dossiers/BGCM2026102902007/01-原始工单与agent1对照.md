# BGCM2026102902007 [遥控器管理] 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [遥控器管理] 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触 | [遥控器管理] 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触 | 否 |
| 测试模块 | 遥控器管理 | 遥控器管理 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1、设置遥控器的按键I为以下功能，按键操作，查看结果 | 1、设置遥控器的按键I为以下功能，按键操作，查看结果 | 否 |
| 测试数据 | 撤防（Disarm）、关联中间任意多个子系统 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 1、设置成功2、可以通过该按键对主机进行所配置的操作成功 | 1、设置成功2、可以通过该按键对主机进行所配置的操作成功 | 否 |
| 实际结果 | 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触 | 遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：设置按键功能成功_撤防及多个子系统关联前置条件：操作步骤：1、设置遥控器的按键I为以下功能，按键操作，查看结果测试数据：撤防（Disarm）、关联中间任意多个子系统预期结果：1、设置成功2、可以通过该按键对主机进行所配置的操作成功实际结果：遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触问题：1.遥控器取消关联全部子系统的时候，界面会卡主2s，此时点其他的GROUP。就会出现把其他的按键关联给误触
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/view/advanceSetting/group/pc/group.vue` | exact basename "group" from title/titleTag/testModule/intent | grep |
| `src/view/advanceSetting/group/mixin.js` | package/dir "group" from title/titleTag/testModule/intent | grep |
| `src/view/advanceSetting/group/pc/components/subsystemTree.vue` | package/dir "group" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：按 device_web 读取顺序确认：入口 src/router/device/pc.js:136 → src/view/device/remoteCtrl/pc/remoteCtrlSet.vue；路由表与 index.asp 均非修复点。Agent-2 的 advanceSetting/group 候选属 /scene/group 场景分组页，已排除。移动端 src/view/device/remoteCtrl/mobile/remoteCtrlSet.vue 复用同一 mixin.changeAreaOption（字段为 *-obj 结构），若缺陷含移动端需同步验证。; analyze=sdk; quality fields missing; bounded format repair
- sessionId：`2cd9f1c0-4f59-4454-b201-b5305946050c`
- attemptId：`2237d0c54c9b`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1、设置成功2、可以通过该按键对主机进行所配置的操作成功
- **代码关联**：src/view/device/remoteCtrl/mixin.js; src/common/vue/components/pc/base/Form/Form.vue; src/view/device/remoteCtrl/pc/remoteCtrlSet.vue
- **机制**：[Conditional / unverified] [Conditional / unverified —— 代码路径已 Read 确认，2s 时长与点击重定向机制未观测] PC 遥控器设置页在「取消关联全部子系统」时，同一宏任务内同步做了两段重活：(1) 多选下拉内的「取消全选」走 Form.handleCheckAllChange，一次性把 form[key] 置空（该函数上方注释自证「取消全选且数量太多的时候会卡」），并触发整份表单 computed / customKey 表格所有单元格重渲染；(2) 关联全部子系统开关 / 关联子系统多选的 change 走 mixin.changeAreaOption，它遍历 customKey 每一行就地改写 children.*.options、curChildValue、selectObj，最后把整份 form 交给 Form.setForm，而 setForm 对每个 key 执行 delete → $set('') → 赋值，使整表二次全量失效重渲染。代价是主线程被长时间占用（票据称约 2s，未采样）；阻塞结束后已排队的点击按当时的坐标派发，而此刻下拉里的 Group/Area option-group、multiple-limit 与 disabled 正因 val 为空/selectObj 被翻成 true 而位移（Area 组消失、组禁用状态翻转），于是点击落到另一个按键行或另一个 GROUP 选项上，写入了别的按键的 curChildValue —— 表现为「把其他按键关联误触」。注意：若该误写随保存下发，还会连带破坏用户验收目标第 2 条（按键执行的操作与配置一致），因此修复点同时是配置正确性问题，不只是性能问题。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | PC 遥控器页的「关联子系统」多选 change 与「关联全部子系统」开关 change 都调用 changeAreaOption。 | fact | `unverified` |  |
| c2 | changeAreaOption 对 customKey 的每一行都重写 options / curChildValue / selectObj，并在末尾对整个 form 调 setForm；行内 getRelayOpt(val) 也在 forEach 内重复计算。 | fact | `unverified` |  |
| c3 | Form.setForm 对每个 key 执行 delete → $set('') → 赋值，使整份 form（含 customKey 表格与所有 scoped slot）全量失效重渲染；没有增量更新或分批/防抖控制。 | fact | `supported` |  |
| c4 | 多选下拉内的「全选/取消全选」由 Form 自己注册的 on.change 处理（handleCheckAllChange 直接赋值 form[key]），不经过字段 item.on.change，因此不会调用 changeAreaOption，各按键行派生 options 与 selectObj 会停留在旧值。 | fact | `conditional` | 『handleCheckAllChange 不经 item.on.change』本身是代码事实（赋值不回调），但『el-select 在 value 被程序化清空时不向上派发 change』依赖 hui/element 2.x multiple 分支行为，未实测 |
| c5 | 代码库已在该处留下「取消全选且数量太多的时候会卡」的注释与临时规避（>16 个选项时先隐藏 .el-select__tags 再复原），说明清空大量已选项是已知慢操作，属于同类症状的既有旁证。 | fact | `unverified` |  |
| c6 | 约 2s 的主线程阻塞由「同步清空 + changeAreaOption 逐行重写 + setForm 全量重渲染」共同造成；各部分占比未采样，属条件性结论。 | hypothesis | `conditional` | 子系统数量足够多（≥16，实际可能数十个）且 customKey 行数较多时才会到秒级；无 Performance 采样 |
| c7 | 阻塞期间用户的点击被排队，派发时下拉内容与位置已改变（Area option-group 因 res 为空而消失、row.selectObj 被置 true 导致组禁用翻转），于是落到位移后的元素，改写了另一个按键的 curChildValue，形成「把其他按键关联误触」。 | hypothesis | `conditional` | 浏览器把已排队的 mouse 事件按派发时刻的坐标做命中测试，而非按按下时刻的元素; 测试动作发生在选项被重写/重排的时间窗内；也可能是用户以为卡住而重复点击后命中新布局，两种变体同源 |
| c8 | 该链路无防抖、无「更新中」标志位、无下拉主动关闭保护；remoteCtrl 目录内除初始化时一个 100ms setTimeout 外没有其它 setTimeout。 | fact | `unverified` |  |

## ④ 最终修改判断与验证

- **建议修改**：把「取消关联 / 切换关联全部子系统」引起的状态传播改为最小增量 + 同一 tick 合并，并让全选路径与字段 change 语义一致，从根上消除主线程长任务与下拉内容在点击瞬间的位移；不改变「可取消关联全部子系统」「设置成功后可按键操作」这两条既有验收要求。
- 步骤：
  1. 在 mixin.changeAreaOption 中不再整表 setForm：克隆 customKey，只对受影响的行（value 为 automationControl / subSystemLinkage，或 selectObj === 'area' 的行）重算 options 与 curChildValue，然后一次性 this.$set(form, 'customKey', 新数组)。
  1. 为 changeAreaOption 增加同一 tick 合并（this.$nextTick 合并 + 取消上一次调度 或 ~100ms 防抖），避免逐个删 tag 时每次删除都触发一次全量重算。
  1. 让 Form.handleCheckAllChange 在赋值后以字段 item.on.change（或新增 onSelectAll 回调）通知使用方，使「取消全选」与 changeAreaOption 行为一致，消除派生 options 陈旧这一半误触来源。
  1. 重写 options / 批量更新期间置 bUpdating 标志并先关闭已打开的下拉（可参考 selectPanelMixin.closePop 的实现方式），更新完成后再恢复交互，避免点击命中位移后的元素。
  1. 评估 Form.setForm 的增量能力（值引用未变的 key 不再 delete + $set('') 双写），或在遥控器页改用局部 setFormKeys；Form.vue 为公共组件，改动需回归其它使用方。
  1. 附带健壮性（独立提交、不计入本单因果）：对象列 res 计算改为 (oBasicInfo['SingleRemoteBasicInfo-linkageSubSystems'] \|\| []).indexOf(...)。
- 目标文件：`src/view/device/remoteCtrl/mixin.js`, `src/view/device/remoteCtrl/pc/remoteCtrlSet.vue`, `src/common/vue/components/pc/base/Form/Form.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['PC 遥控器管理 → 编辑遥控器 → 准备 ≥16（最好数十个）子系统，全部关联到按键 I。', '开启 DevTools Performance，分别用三种方式执行「取消关联全部子系统」（下拉内取消全选 / 逐个删除 tag / 关闭关联全部子系统开关），记录长任务时长与构成，确认性能瓶颈归属。', '在卡顿窗口内立即点击另一个按键（如按键 II）对象下拉中的 Group 选项，核对按键 II 的 curChildValue 与最终下发参数是否被意外改写（复现误触）；再确认保存后重新进入页面，另一按键的关联值是否已被写入设备。', '改动后重复上述动作：单次主线程任务显著下降（目标 <1；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/view/device/remoteCtrl/`
- 首候选：`src/view/device/remoteCtrl/mixin.js`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
