# BGCM2026103000881 [网络设备管理] 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [网络设备管理] 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed. | [网络设备管理] 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed. | 否 |
| 测试模块 | 网络设备管理 | 网络设备管理 | 否 |
| 前置条件 | 通过Onvif协议接入IPC | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1、配置IPC码率类型 | 1、配置IPC码率类型 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1.无法配置码率类型 | 1.无法配置码率类型 | 否 |
| 实际结果 | 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed. | 主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed. | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：配置IPC码率类型失败前置条件：通过Onvif协议接入IPC操作步骤：1、配置IPC码率类型测试数据：预期结果：1.无法配置码率类型实际结果：主机通过Onvif协议接入IPC，进入参数界面点击保存的时候显示Operating failed.问题：https://zero.hikvision.com.cn/pagespy/#/replay?url=https://zero.hikvision.com.cn/pagespy/api/v1/log/download?fileId=local.832f4c0c3da1c7a5e23a37951108c1e7
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/view/device/ipc/mixin.js` | package/dir "ipc" from title/titleTag/testModule/intent | grep |
| `src/view/device/ipc/mobile/videoParameter.vue` | package/dir "ipc" from title/titleTag/testModule/intent | grep |
| `src/view/device/ipc/otap.js` | package/dir "ipc" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：证据分级：已确认的代码事实仅限“报文无条件含 bitrateType”“置灰依赖 route query”“PC 同构”。未确认的是“被拒请求是 VideoCodingParams 且拒绝原因为 bitrateType”——需 pagespy 日志；错误码 0x00100002→operateFailed 的映射已读，但错误码表被截断，同一文案的其它来源码未排除。src/router/** 仅为导航证据（/device/videoParameter 注册、ipcSet.rightHandle 跳转），不是修复点。; analyze=sdk; partial=true; reason=max_turns; quality fields missing; bounded format repair
- sessionId：`ce837726-af83-4159-a33f-6931ee65f28d`
- attemptId：`ce9a6b08016b`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.无法配置码率类型
- **代码关联**：src/view/device/ipc/mobile/videoParameter.vue; src/view/device/ipc/pc/component/singleChannelConfig.vue; src/view/device/index/pc/deviceView.vue
- **机制**：[Conditional / unverified] [条件性结论 / 未验证] 移动端“视频参数”页（src/view/device/ipc/mobile/videoParameter.vue）的 submit 在 ONVIF 接入的 IPC 下仍无条件把 bitrateType 打进 VideoCodingParams 的 set 报文（并附带 maxBitrate/constantBitRate 等编码字段），设备整包拒绝后前端 Response.saveState 展示 operateFailed（'Operating failed.'）——这一步的因果链依赖设备日志确认，未验证。另有一条独立可验证的代码事实：“码率类型”控件 disabled 只依赖从路由 query 透传的 accessProtocolType，query 为空时控件不会置灰，使缺陷表现为“像可以配置→保存即失败”。两条都指向同一验收目标：ONVIF 下码率类型应不可配置且保存不报 Operating failed。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | 代码层面 'Operating failed.' 是 i18n key `operateFailed` 的英文文案，而 `operateFailed` 在 Response 的设备错误码表中对应 `0x00100002`。 | fact | `unverified` | 仅确认了已读到的映射片段；错误码表在我读到第 30 行处截断，不能排除其他入口也产出 operateFailed |
| c2 | 缺陷中用户看到的 'Operating failed.' 来自设备对某次 set 请求返回的错误码（经 Response.saveState 翻译），而不是前端 JS 异常。 | hypothesis | `conditional` | toast 文案仅由 Response.saveState 的设备码映射产生；未取得日志确认真实返回码 |
| c3 | 移动端 videoParameter.submit 构造的 VideoCodingParams set 报文固定包含 `bitrateType: form.bitrateType`，且该值在 ONVIF 通道 GET 未返回时被回填默认 `'constant'`，没有任何按协议裁剪的分支。 | fact | `unverified` |  |
| c4 | 移动端“码率类型”的 disabled 判定依赖 `this.accessProtocolType`，而该字段仅在 setIPC(row) 中由 `row?.accessProtocolType` 赋值（row 即 `this.$route.query`），因此置灰能力完全取决于路由 query 透传。 | fact | `unverified` |  |
| c5 | 在实际 App 场景中该路由 query 的 accessProtocolType 可能为空，导致 ONVIF 通道“码率类型”不被置灰——这是置灰门槛失效的触发条件。 | hypothesis | `unverified` | 未逐条核对移动端设备列表（HPP 内嵌页）跳转到 ipcSet 的参数，也未在真机复现控件状态 |
| c6 | ONVIF 通道的 VideoCodingParams set 不接受 bitrateType 等编码字段，设备因此整包返回 0x00100002，最终呈现为 Operating failed。 | hypothesis | `conditional` | 设备对 ONVIF 通道采用严格字段校验；未取得设备侧/日志原文验证被拒绝的字段与请求 |
| c7 | PC 端存在同构下发路径：singleChannelConfig.getAjax 与 deviceView.submit 均无条件把 bitrateType 放进 VideoCodingParams set，仅靠 `szIpcProtoType === 'ONVIF'` 置灰不构成报文层保护。 | fact | `supported` |  |
| c8 | 本 ticket 的验收目标（用户确认的期望）是“无法配置码率类型”，即 ONVIF 通道下码率类型必须不可配置且保存不出现 Operating failed；修复不得用其它行为（如仅改录像时间、仅改防区字段）替代该目标。 | fact | `conditional` | 依据缺陷单 expected 字段："1.无法配置码率类型" |

## ④ 最终修改判断与验证

- **建议修改**：以“ONVIF 下码率类型不可配置且保存不报 Operating failed”为准绳：在 set 报文层按协议裁剪（ONVIF 剔除 bitrateType，或按 q3 结论整包不下发），并把“码率类型”置灰判断从易丢失的路由 query 换到可信协议来源（通道 tags 的 accessProType/HIKProtocolType 或通道信息接口）。移动端与 PC 两端保持一致；不改动视频复核使能、录像时间、通道名称等无关字段。
- 步骤：
  1. 1. 先按 q1 的日志结论确认被拒请求；若确认为 VideoCodingParams set，则按 q3 选定的语义在移动端 videoParameter.submit 中处理：ONVIF 时删除 oData.Value[streamType].video.bitrateType，或直接不 push setVideoCodingParams。
  1. 2. 移动端置灰改用不依赖路由 query 的协议来源（优先沿用 ipcSet/通道 tags 已有字段），保留 accessProtocolType 作兜底；不改写其它字段的 disabled 规则。
  1. 3. 视 q2 决策，同步 PC 侧 singleChannelConfig.getAjax 与 deviceView.submit 的同类裁剪；若不在本期范围，则记录为后续跟踪项而非本次改动。
  1. 4. 回归：ONVIF 通道保存视频参数→无 Operating failed 且码率类型不可配置；HIKPrivate/ISAPI 通道码率类型可正常配置与保存；协议字段为空/缺失时不得误伤 HIK 行为。
  1. 5. 不扩大到视频复核使能、报警前后录像时间、通道名称等下发逻辑，保持最小修复面。
- 目标文件：`src/view/device/ipc/mobile/videoParameter.vue`, `src/view/device/ipc/pc/component/singleChannelConfig.vue`, `src/view/device/index/pc/deviceView.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['打开缺陷日志 pagespy 回放，核对保存动作中 VideoCodingParams(set) 的请求体是否含 bitrateType、响应码是否为 0x00100002；同时记录 EventRecord / setVideoChannelTrigger / ModifyVideoChannel 的响应', '以 ONVIF 接入 IPC，进入视频参数页：记录“码率类型”控件是否置灰、$route.query 中 accessProtocolType 的实际取值、以及提交时的报文', '改动后回归：ONVIF 通道保存视频参数不再出现 Operating failed，码率类型不可配置；；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/view/device/ipc/`
- 首候选：`src/view/device/ipc/mobile/videoParameter.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
