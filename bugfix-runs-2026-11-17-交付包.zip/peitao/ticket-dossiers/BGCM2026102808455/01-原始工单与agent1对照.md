# BGCM2026102808455 [多语言] 多语言中存在日志内容未翻译，显示的是英语

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [多语言] 多语言中存在日志内容未翻译，显示的是英语 | [多语言] 多语言中存在日志内容未翻译，显示的是英语 | 否 |
| 测试模块 | 多语言 | 多语言 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1、不同语言版本的日志导出，查看内容 | 1、不同语言版本的日志导出，查看内容 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确 | 1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确 | 否 |
| 实际结果 | 多语言中存在日志内容未翻译，显示的是英语 | 多语言中存在日志内容未翻译，显示的是英语 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：导出多语言日志成功_内容一致翻译正确前置条件：操作步骤：1、不同语言版本的日志导出，查看内容测试数据：预期结果：1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确实际结果：多语言中存在日志内容未翻译，显示的是英语问题：1.
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：多语言 key 在构建期被扁平化（build/helper/build.js flatJson），故 Operations.json 内 maintenance.maintainLog.* 的嵌套写法不影响 I18n.t('addiInfo') 等取值；titles 表头已本地化，非本缺陷源。zh_CN 的英文占位值来自 Grep 核对（Operations.json:20-21、Common.json:1351），未逐行 Read，作为待确认事实使用。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`6df1036e-81eb-4b95-943e-f6521dc7c323`
- attemptId：`e3d98cfc3c44`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.日志导出成功2.导出的日志文件内容和客户端日志内容一致，翻译正确
- **代码关联**：src/view/operations/maintain/maintainLog/pc/maintainLog.vue; src/view/operations/maintain/maintainLog/mixin.js; src/common/static/i18n/zh_CN/Operations.json; src/common/static/i18n/zh_CN/Common.json; src/common/static/i18n/th/Operations.json; src/common/static/i18n/in/Operations.json; src/common/static/i18n/lv/Operations.json
- **机制**：[Conditional / unverified] 日志导出链路（PC「导出 CSV」）在拼装导出行数据时把「接入」列写死为英文 'Local'/'Remote'，绕过 i18n；而同一份数据在客户端表格里是用 $t('local')/$t('remote_name') 渲染的，因此导出文件内容必然与客户端显示不一致、且在任何语言下都是英语。其次，导出表头/内容依赖的若干 key 在部分语言资源里仍是英文占位值（zh_CN 的 terminal_name/remote_name/access_name 等），进一步放大『导出内容显示英语』；另外 I18n.t 对目标语言缺失的 minorType key 会原样返回英文 key。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | PC 日志导出 exportCSVFile 用硬编码英文 'Local'/'Remote' 生成 access 列，完全绕过 i18n，是导出内容显示英语的直接代码级来源。 | conclusion | `conditional` | 缺陷『日志内容未翻译』指的是导出 CSV 的行数据列 |
| c2 | 同一 access 语义在页面/移动端渲染时使用 $t('local') / $t('remote_name')，因此导出与客户端显示不一致，正好违背『导出的日志文件内容和客户端日志内容一致，翻译正确』。 | fact | `supported` |  |
| c3 | zh_CN 语言资源自身存在英文占位值：Operations.json 的 terminal_name="terminal"、remote_name="remote"，Common.json 的 access_name="Access"；导出表头/终端列在中文下仍是英语。另外 th/in/lv 等语言的 remote_name 也为 "Remote"。 | fact | `unverified` | 缺陷语言包含 zh_CN 或对应占位语言 |
| c4 | mixin.js 对主/子类型用 I18n.t(szMajorType.toLowerCase())/I18n.t(szDescribe) 翻译；当目标语言 JSON 缺少该 minorType key 时 vue-i18n 原样返回英文 key，日志内容即显示英语。 | hypothesis | `unverified` | 设备上报的 minorType 在部分语言资源中缺 key |
| c5 | excelExport 的表头 titles 全部经 I18n.t() 处理，表头不是英语残留的来源。 | fact | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：把导出 CSV 的 access 列改为与页面渲染同一套 i18n key（$t('local')/$t('remote_name')），消除导出与客户端显示不一致；再补齐目标语言中的英文占位翻译（terminal_name/remote_name/access_name 等）；设备 minorType key 缺失问题按需补 key 或加 key→译文的兜底。
- 步骤：
  1. 在 pc/maintainLog.vue 的 exportCSVFile 中，将 `const access = remoteHostAddr === '--' ? 'Local' : 'Remote';` 改为 `const access = remoteHostAddr === '--' ? this.$t('local') : this.$t('remote_name');`，保持与 mixin.js:381/548 页面渲染一致。
  1. 遍历多语言目录，修复仍为英文占位值的日志相关 key（至少 zh_CN：Operations.json terminal_name/remote_name，Common.json access_name；并排查 th/in/lv/sl 等 remote_name/access_name 的英文残留）。
  1. 抽样核对导出 CSV：中文/德语等下表头与「接入」列应分别为本地化文案，且与页面表格一致。
  1. 若样例行仍出现英文，再核对设备上报 minorType 在目标语言 Operations.json/Common.json 中是否存在对应 key（未确认，属后续验证项）。
- 目标文件：`src/view/operations/maintain/maintainLog/pc/maintainLog.vue`, `src/common/static/i18n/zh_CN/Operations.json`, `src/common/static/i18n/zh_CN/Common.json`, `src/common/static/i18n/th/Operations.json`, `src/common/static/i18n/in/Operations.json`, `src/common/static/i18n/lv/Operations.json`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['在 zh_CN 与 de 两种语言下执行：运维/维护日志页 → 导出 CSV，检查『接入』列与表头文案是否分别为本地化值。', '对比导出 CSV 与页面表格同一行（时间、主类型、子类型、接入）是否一致且翻译正确。', '若样例行仍有英语，抓取该行设备上报的 minorType 值，检查目标语言 Operations.json/Common.json 是否含该 key。', '回归移动端日志列表/详情（复用同一 mixin）显示未受影响。']；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/view/operations/maintain/maintainLog/`
- 首候选：`src/view/operations/maintain/maintainLog/pc/maintainLog.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
