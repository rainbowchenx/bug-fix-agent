# BGCM2026110304188 [键盘管理] 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [键盘管理] 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait. | [键盘管理] 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait. | 否 |
| 测试模块 | 键盘管理 | 键盘管理 | 否 |
| 前置条件 | 主机已进入安装模式 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1、键盘点击退出安装模式按钮，使用以下方式校验权限，查看结果 | 1、键盘点击退出安装模式按钮，使用以下方式校验权限，查看结果 | 否 |
| 测试数据 | Operator键盘密码输入 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 1、退出安装模式成功，键盘有操作成功的提示 | 1、退出安装模式成功，键盘有操作成功的提示 | 否 |
| 实际结果 | 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait. | 本地operator登录主机web，进入用户管理界面，界面一直显示Please wait. | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：退出安装模式成功_键盘密码输入前置条件：主机已进入安装模式操作步骤：1、键盘点击退出安装模式按钮，使用以下方式校验权限，查看结果测试数据：Operator键盘密码输入预期结果：1、退出安装模式成功，键盘有操作成功的提示实际结果：本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.问题：1.本地operator登录主机web，进入用户管理界面，界面一直显示Please wait.web调试路径：https://zero.hikvision.com.cn/pagespy/#/replay?url=https://zero.hikvision.com.cn/pagespy/api/v1/log/download?fileId=local.d166abf3c98a0eb29707205ab85a98e1
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：softStartLocalization 为空（no_path_token_overlap），上述候选由 CodeGraph 导航（Header.vue/setInstallMode、userManage.vue、APP-pc.vue）后经 grep waitTips 收敛到 config/userManage 目录，再逐个 Read 确认。路由表 src/router/config/pc.js 与 i18n 键均非修复点。尚未确认运行时到底是哪一条 Promise 悬挂，需 pagespy 网络证据。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`0a227fe8-9b9f-4d31-a82c-9d16ac94f5e0`
- attemptId：`a105a2936051`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1、退出安装模式成功，键盘有操作成功的提示
- **代码关联**：src/view/config/userManage/userList/pc/userList.vue; src/view/config/userManage/userList/mixin.js
- **机制**：用户管理页 (src/view/config/userManage/userList/pc/userList.vue) 在 created() 里开了一个 fullscreen 的 Loading（文案即 waitTips = "Please wait."），而这个遮罩唯一的关闭时机是 this.getTable().finally(...)。getTable -> mixin.getList 内部串了多条无失败兜底的链路：① getSubSysName 走 Device.getBatchRequest 的 Promise 只有 resolve 分支，批量请求失败/永挂时该内部 Promise 永不 settle；② searchAllUserInfoCfg / searchAllUserLocalPermission / searchAllUserRemotePermission 的分页递归只在「累计条数 >= totalMatches」时 resolve，设备上报 totalMatches 与实际 matchResults 不一致（或 matchResults 缺失）时会无限分页、永不 settle；③ getList 中 `if (!aUserInfo.length) reject()` 后没有 return，后续仍继续执行。任一环节永不 settle，getTable() 的 Promise 就不会结束，finally 不会触发，全屏 Please wait. 就永久停留。这与本次「本地 operator 登录 + 安装模式下」相关是因为 operator 的用户管理能力/权限最小，最容易命中「能力集缺字段直接解引用」与「空/异常用户列表」分支。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 用户管理列表页的全屏 "Please wait." 遮罩只在 getTable() 的 finally 中关闭，没有超时/失败兜底，因此任何上游 Promise 永不 settle 都会导致遮罩永久残留。 | fact | `supported` |  |
| C2 | getSubSysName 的 ezviz 分支用 `new Promise(resolve1 => Device.getBatchRequest(...).then(resolve1))` 包装，缺少 reject/catch，批量请求失败时该 Promise 永不 settle，使 buildListData -> getList 永不结束。 | hypothesis | `conditional` | 设备处于 bEzvizMode 分支; Device.getBatchRequest 存在失败/超时分支 |
| C3 | 三个 searchAll* 分页函数只在「累计 >= res.totalMatches」时 resolve，且对 getNodeCaps(...)[1] 在 Promise 外直接下标解引用，能力集缺字段或缺 totalMatches 一致性时会抛错或无限分页。 | hypothesis | `conditional` | operator 会话下 configDomains 可能不含 SearchUserInfoCfg.maxResults 或设备 totalMatches 与 matchResults 不一致 |
| C4 | getList 中 `if (!aUserInfo.length) { reject(); }` 后未 return，后续仍会继续做权限合并与 buildListData，可能产生二次异常而不是尽快收尾。 | fact | `unverified` |  |
| C5 | refresh() 的遮罩只在 .then 关闭（未用 finally），请求失败时同样会残留 "Please wait."，与该缺陷表现同族。 | fact | `supported` |  |
| C6 | 缺陷文本的验收目标（退出安装模式成功且键盘有成功提示）与本处 web 遮罩问题不是同一机制；本分析只针对 observed 的 Please wait. 现象，不改变验收目标。 | conclusion | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：先保证遮罩不因上游挂起而永驻（兜底 + 失败态），再堵住两条永不 settle 的链路（分页递归、批量请求包装），并把 reject 后未 return 的分支补全。
- 步骤：
  1. src/view/config/userManage/userList/pc/userList.vue：created() 与 refresh() 统一改为在 finally 关闭遮罩，并加超时兜底（如 30s 后强制 close 并提示失败），失败时显示空态/错误态而不是永久 Please wait.。
  1. src/view/config/userManage/userList/mixin.js getSubSysName 的 bEzvizMode 分支：给 Device.getBatchRequest 增加 .catch(err => reject(err))，Promise 内 resolve1 之外补 reject1，避免内部 Promise 永不 settle。
  1. src/view/config/userManage/userList/mixin.js searchAllUserInfoCfg / searchAllUserLocalPermission / searchAllUserRemotePermission：把 `Utils.getNodeCaps(...)[1]` 改为安全取值并提供默认页长；分页终止条件补上 `if (!res.matchResults \|\| !res.matchResults.length) resolve(list)`，并加最大页数/条数保护，避免 totalMatches 不一致导致的无限递归。
  1. src/view/config/userManage/userList/mixin.js getList：`if (!aUserInfo.length) { reject(); return; }`（两处，ezviz 与非 ezviz 分支），避免 reject 后继续执行。
  1. 评估 getTable 侧 catch 里已 Response.saveState，保持最小改动，不做与本缺陷无关的重构。
- 目标文件：`src/view/config/userManage/userList/pc/userList.vue`, `src/view/config/userManage/userList/mixin.js`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['本地 operator 账号登录（安装模式开启）进入 配置->用户管理，观察是否仍停留在 Please wait.；Network 面板确认 SearchUserInfoCfg / SearchUserSubSystemBasicInfo 等请求是否有未返回或无限重复。', '断网/阻塞某 CGI 模拟上游失败，验证遮罩在超时后自动关闭并给出失败提示（不再永久停留）。', '构造 totalMatches 与 matchResults 不一致的 mock 响应，验证分页递归能终止且页面可渲染。', 'lint / typecheck 改动文件（该仓库为 Vue2 + JS 项目，按项目现有；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/view/config/userManage/`
- 首候选：`src/view/config/userManage/userList/pc/userList.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
