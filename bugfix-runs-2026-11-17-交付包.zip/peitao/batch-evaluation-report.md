# peitao（device_web）Agent-3 批次评测报告

> 依据 `docs/field-eval/agent3/templates/batch-evaluation-report.md` 填写。
> 本批只到报告路径（`applyFix=false`），「应用/验收」相关栏目按 N/A 记。
> 运行日期 2026-11-17，全部产物重新生成，未复用 2026-11-16 的任何结果。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 / 评测负责人 | runs-2026-11-17/peitao / 2026-11-17 / 运行者本人 |
| 项目类型及版本 / 每仓HEAD与dirty | device_web（peitao 报警）/ `bug-fix-demo-project/peitao` |
| Agent3 commit / 模型 / SDK/CLI | 5c5c2f9 / EB-DeepSeek-Flash / claude-agent-sdk 0.2.182 |
| 运行模式 / 生效预算 / 并发及超时 | analyze_mode=sdk，applyFix=false，max_turns=24，四仓并行 |
| 业务skill及版本 / 可用环境 | 包内置 SOP；CodeGraph 索引已就绪 |
| 原始资料 / Agent1/2产物 / 产出目录 | 19 条 CSV（PJ14PD20260423284）→ defect-batch → code-knowledge → analysis-report |
| 选样方法、纳入排除标准 | 沿用 2026-11-16 的同样 6 票号，便于跨批次对照；全部 strict |
| 重跑/中断/临时修改 | 无中断。Agent-2 分 3 组（8+8+3）全部 completed |

## 2. 样本与验收覆盖

原始输入项：19；唯一缺陷：19；重复关联：0；导入失败：0。

| 样本类别 | 数量 | 票ID |
|---|---|---|
| 清晰且当前仓可修 | 6 | 见下方逐票表 |
| 模糊/缺图/缺日志 | 0 | — |
| 疑似仓外/设备/算法/固件/App | 0 | — |
| 环境依赖 | 0 | — |
| 实际进行了二次执行 | 0 | 本批未做二轮反馈 |

| 阶段 | 唯一票数 | 未继续的原因 |
|---|---|---|
| 收到输入 | 19 | — |
| 有明确报告去向 | 19 | — |
| 曾生成候选 / 当前有效候选 | 14 / 14 | 5 票 Agent-2 空候选，由 Agent-3 从零定位 |
| 已人工审阅候选 | 6 | 只评审进入 Agent-3 的 6 票 |
| 已尝试应用 / 完整应用成功 | N/A | applyFix=false |
| 已业务验收 | N/A | 未做 |
| 已执行相关回归验收 | N/A | 未做 |

## 3. 质量指标

| 指标 | n/N | 结果或范围 | 限制 |
|---|---|---|---|
| 报告覆盖 | 6/6 | 全部产出 plan_only 报告 | — |
| 候选产出 / 当前有效候选 | 6/6 / 6/6 | 全部有至少 1 个候选 | — |
| 已核查票中的严重事实错误 | 0/6 | 无路径不存在、无入口噪声冒充高置信 | — |
| 补丁完整可应用 | N/A | 报告路径不产补丁 | — |
| 原样接受（含机械调整） | N/A | 未做人工验收 | — |
| 原样/仅机械调整后解决 | N/A | — | — |
| 严格零调整解决 | N/A | — | — |
| 人工逻辑修改后解决 | N/A | — | — |
| 验收覆盖 | 0/6 | 未验收 | — |
| 新增回归 | N/A | 未应用 | — |
| 阻断正确且补充请求有效 | N/A | 无阻断票 | — |
| 二次执行取得可核实进展 | N/A | 未做二轮 | — |

**拒绝候选数量、原因及待验收票：** 全部 6 票候选待验收。

**编译/单测通过但业务未解决的案例：** 无（未应用）。

## 4. 成本

| 成本项 | 有记录样本数 | 总量 | 中位数 | 范围/异常案例 |
|---|---|---|---|---|
| Agent运行分钟 | 6 | ~35 分钟 | ~5.5 分钟/票 | 空候选票耗时更长 |
| Token / 费用（币种） | 3 组 | Agent-2 $11.11 | — | Agent-3 费用未单独记录 |
| 人工审阅 | 6 | 待填 | — | — |
| 应用调整 | N/A | — | — | — |
| 人工逻辑修改 | N/A | — | — | — |
| 业务验证 | N/A | — | — | — |

是否估算：Agent-3 费用为估算（SDK 未单独计价）；预算触顶票：6/6 报 `partial=true; reason=max_turns`（但分析均 completed）。

## 5. 逐票结果

| 缺陷 | 首次→最终结果 | 人工介入 | 验收状态 | 主要问题来源 | 证据/详情 |
|---|---|---|---|---|---|
| BGCM2026102808455 | plan_only → plan_only | 无 | 待验收 | — | loc@1=✅ `maintainLog/pc/maintainLog.vue` |
| BGCM2026102808006 | plan_only → plan_only | 无 | 待验收 | — | loc@1=✅ `remoteCtrl/pc/remoteCtrlSet.vue`（Agent-2 曾跑偏到 `advanceSetting`） |
| BGCM2026102902007 | plan_only → plan_only | 无 | 待验收 | — | loc@1=✅ `remoteCtrl/mixin.js`（同上，Agent-2 跑偏） |
| BGCM2026102809314 | plan_only → plan_only | 无 | 待验收 | — | loc@1=✅ `upgrade/pc/upgrade.vue` |
| BGCM2026103000881 | plan_only → plan_only | 无 | 待验收 | — | loc@1=✅ `device/ipc/mobile/videoParameter.vue` |
| BGCM2026110304188 | plan_only → plan_only | 无 | 待验收 | — | loc@1=✅ `userManage/userList/pc/userList.vue`（Agent-2 空候选） |

## 6. 代表案例

### 成功案例：BGCM2026102808006 / BGCM2026102902007（Agent-3 纠正 Agent-2 跑偏）

原始票：遥控器 Automation Control 权限校验；取消关联全系统时画面卡 2s。

上游输入：Agent-2 在这两票上都给出 `src/view/advanceSetting/automation/` 与 `src/view/advanceSetting/group/` 候选（模式匹配到 automation/group 词根）。

Agent-3 机制证据：Agent-3 独立 grep 后改判到 `src/view/device/remoteCtrl/`，并在 editDecision.mechanism 中写明「遥控器…直接取设备能力枚举…pc/remoteCtrlSet.vue:448-462…mobile/remoteCtrlSet.vue:1661-1670…只做了 tapToRun 权限判断 isSupportTabToRun…未检查 relayControlMgr（Automation Control）权限」。

为何有效：Agent-2 靠路径 token 匹配（automation → advanceSetting/automation），Agent-3 靠读代码找实际权限判断位置，后者语义正确。可复用：Agent-2 的启发式候选应作为"起点"而非"结论"，Agent-3 必须独立验证。

### 失败或回归案例：无

### 二次修复案例：本批未做

## 7. 环节归因与改进

| 环节 | 有证据的问题及票ID | 影响 | 优先级 | 建议与验证办法 |
|---|---|---|---|---|
| 原始资料 | 无 | — | — | — |
| Agent1 | 无（19/19 字段完整，0 丢失） | — | — | — |
| Agent2 | 5 票空候选（含 8455/4188 两张样本）；2 票跑偏（8006/2902007） | 增加 Agent-3 负担，但未导致失败 | 中 | 提高 `_shared_signatures` 阈值、或对 `no_path_token_overlap` 票做二次扩展搜索 |
| Agent3分析 | 6/6 报 `reason=max_turns`（24 轮触顶） | 分析仍 completed，但 evidence 收集受限 | 中 | 评估提高 `BUGFIX_ANALYZE_MAX_TURNS` 到 32-40 |
| Agent3编辑 | N/A（applyFix=false） | — | — | — |
| 验证/交付 | 未做人工验收 | 无法计算修复率 | — | 后续按模板做候选审阅 |
| 环境/外部依赖 | 无 | — | — | — |

## 8. 结论

- **G0 = PASS**：无 `patch_ready_on_report_path`、无 `verify_executed`、无 `entry_noise_confident`。
- **loc@1 = 6/6，loc@3 = 6/6**：6 票首候选全部命中真值前缀（真值已按实际代码 grep 复核）。
- **outcome = 6/6**：全部 `plan_only`，符合报告路径预期。
- **verdict = usable_pending_g3**：定位与结局均可用，等待人工根因评分（G3）。

**本批最大价值**：验证了 Agent-3 能纠正 Agent-2 的错误候选（8006/2902007 两票从 `advanceSetting` 改判到 `remoteCtrl`，且给出了带行号的机制解释）。
