# transport（device_web）Agent-3 批次评测报告

> 依据 `docs/field-eval/agent3/templates/batch-evaluation-report.md` 填写。
> 本批只到报告路径（`applyFix=false`）。运行日期 2026-11-17，全部重新生成。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 / 评测负责人 | runs-2026-11-17/transport / 2026-11-17 / 运行者本人 |
| 项目类型及版本 / 每仓HEAD与dirty | device_web（transport 交通）/ `bug-fix-demo-project/transport` |
| Agent3 commit / 模型 / SDK/CLI | 5c5c2f9 / EB-DeepSeek-Flash / claude-agent-sdk 0.2.182 |
| 运行模式 / 生效预算 / 并发及超时 | analyze_mode=sdk，applyFix=false，max_turns=24，四仓并行 |
| 业务skill及版本 / 可用环境 | 包内置 SOP；CodeGraph 索引已就绪 |
| 原始资料 / Agent1/2产物 / 产出目录 | 37 条 CSV（PJ01PM20260711040）→ defect-batch → code-knowledge → analysis-report |
| 选样方法 | 沿用 2026-11-16 的同样 6 票号；全部 strict |
| 重跑/中断/临时修改 | Agent-2 分 5 组，其中 1 组（8 票）整组失败 `no parseable JSON` |

## 2. 样本与验收覆盖

原始输入项：37；唯一缺陷：37；重复关联：0；导入失败：0。

| 样本类别 | 数量 | 票ID |
|---|---|---|
| 清晰且当前仓可修 | 6 | 见逐票表 |
| 模糊/缺图/缺日志 | 0 | — |
| 环境依赖 | 0 | — |
| 实际进行了二次执行 | 0 | 未做二轮 |

| 阶段 | 唯一票数 | 未继续的原因 |
|---|---|---|
| 收到输入 | 37 | — |
| 有明确报告去向 | 37 | — |
| 曾生成候选 / 当前有效候选 | 11 / 11 | 26 票空候选（其中 8 票因整组解析失败） |
| 已人工审阅候选 | 6 | — |
| 已尝试应用 / 完整应用成功 | N/A | applyFix=false |
| 已业务验收 | N/A | 未做 |
| 已执行相关回归验收 | N/A | 未做 |

## 3. 质量指标

| 指标 | n/N | 结果或范围 | 限制 |
|---|---|---|---|
| 报告覆盖 | 6/6 | 全部产出报告 | — |
| 候选产出 / 当前有效候选 | 4/6 / 4/6 | 2 票无候选 | — |
| 已核查票中的严重事实错误 | 2/6 | 9398 定位到无 HVT 的文件；06318 定位到 postHVT 而非 personRunRedLight | **真实定位错误** |
| 补丁完整可应用 | N/A | 报告路径 | — |
| 原样接受 | N/A | 未验收 | — |
| 验收覆盖 | 0/6 | — | — |
| 阻断正确且补充请求有效 | 2/2 | 2 票 `other_blocked`（sdk_fallback），阻断理由真实（模型输出无法解析） | — |
| 二次执行取得可核实进展 | N/A | 未做 | — |

**拒绝候选数量、原因及待验收票：** 4 票有候选待验收；2 票无候选。

**编译/单测通过但业务未解决的案例：** 无（未应用）。

## 4. 成本

| 成本项 | 有记录样本数 | 总量 | 中位数 | 范围/异常案例 |
|---|---|---|---|---|
| Agent运行分钟 | 6 | ~40 分钟 | ~6.7 分钟/票 | 空候选票 + sdk_fallback 重试显著更慢 |
| Token / 费用 | 5 组 | Agent-2 $12.65 | — | — |
| 人工审阅 | 6 | 待填 | — | — |

是否估算：Agent-3 费用估算；预算触顶：1 票 max_turns，2 票 sdk_fallback。

## 5. 逐票结果

| 缺陷 | 首次→最终结果 | 验收状态 | 主要问题来源 | 证据/详情 |
|---|---|---|---|---|
| BGCM2026102600211 | plan_only | 待验收 | — | loc@1=✅ `postHVT/postHvtMixin.js` |
| BGCM2026102400935 | other_blocked | 不适用 | Agent3分析 / 模型输出 | sdk_fallback `no parseable JSON`，无候选 |
| BGCM2026102202247 | other_blocked | 不适用 | Agent3分析 / 模型输出 | sdk_fallback，但**候选正确** `rapidOSDConfig.vue` |
| BGCM2026102702440 | plan_only | 待验收 | — | loc@1=✅ `videoCode/regExposure/regExposure.vue` |
| BGCM2026102809398 | plan_only | 待验收 | **Agent3分析（定位错误）** | 给 `Preview/components/base/UploadPic/uploadPicMixin.js`，该文件无 HVT 相关代码 |
| BGCM2026102906318 | plan_only | 待验收 | **Agent3分析（定位错误）** | 给 `postHVT/postHvtMixin.js`，真值为 `personRunRedLight/triggerModePersonRunRedLight.vue` |

## 6. 代表案例

### 成功案例：BGCM2026102702440（regExposure）

原始票：规则曝光参数相关。Agent-2 给 `src/Config/view/video/videoCode/regExposure/` 候选；Agent-3 精确定位到 `regExposure.vue` 并产出 plan_only 报告。为何有效：Agent-2 候选与 Agent-3 读码结论一致，双向印证。

### 失败案例：BGCM2026102809398（HVT 定位错误）

原始票：HVT 触发。Agent-3 给 `src/Preview/components/base/UploadPic/uploadPicMixin.js`。人工 grep 确认该文件**完全不含 HVT 相关代码**，真值分别为 `src/Config/view/snap/triggerMode/postHVT/` 与 `src/Config/view/event/exceptionEvent/HVTTrigger/`。

如何改进：该票 Agent-2 处于失败组（`no parseable JSON`），无任何候选，Agent-3 从零搜索时被 "HVT" 缩写误导到 UploadPic。建议：① 修复 Agent-2 组解析失败；② Agent-3 对全大写缩写词做专门提示。

### 二次修复案例：本批未做

## 7. 环节归因与改进

| 环节 | 有证据的问题及票ID | 影响 | 优先级 | 建议与验证办法 |
|---|---|---|---|---|
| Agent1 | 无 | — | — | — |
| Agent2 | ① 1 组 8 票整组 `no parseable JSON`（含 9398/06318）；② 26/37 空候选（70%） | 直接导致 Agent-3 无起点，定位质量下降 | **高** | ① 增加解析失败的自动重试与降级；② 检查该组 prompt 是否超长/格式异常 |
| Agent3分析 | ① 2 票 sdk_fallback；② 2 票定位错误 | loc@1 从 6/6 降到 3/6 | **高** | ① 排查 `no parseable JSON` 是模型输出格式还是解析器问题；② 缩写词定位需专门处理 |
| Agent3编辑 | N/A | — | — | — |
| 验证/交付 | 未做人工验收 | 无法计算修复率 | — | 后续按模板做 |
| 环境/外部依赖 | 模型 `EB-DeepSeek-Flash` 对复杂 JSON 输出不稳定 | 4/6 票受影响（2 fallback + 2 定位错） | 高 | 换模型或加强输出约束 |

## 8. 结论

- **G0 = PASS**：无过程造假迹象（`other_blocked` 是真实阻断，不是伪装成功）。
- **loc@1 = 3/6，loc@3 = 3/6**：定位能力明显弱于 peitao/hcp。
- **outcome = 4/6**：2 票 `other_blocked`。
- **verdict = mixed**。

**本批核心问题**：Agent-2 有一个 8 票组整体解析失败 + 空候选率 70%，Agent-3 在此基础上出现 2 票 sdk_fallback 和 2 票定位错误。四仓中表现最差。
