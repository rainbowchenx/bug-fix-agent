# Repair report PJ01PM20260711040

tickets: 6

- BGCM2026102600211: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.车道线和触发线、车道线类型与实际相符，且配置生效
  cause: [Conditional / unverified] 『压导流带行驶』区域(id=10000, regionType=diversionZone)只绘制在主页面插件 this.plugin 上；车道线自动绘制弹窗用的是另一套独立插件实例 oPluginDlgOption.pluginObj。确认自动绘制时 confirmAutoDraw() 调用 save(this.oPluginDlg)，save 内部 restorePlateRegion(plugin) 只从该弹窗插件 getFigure() 读取图形来重建 DetectionRegionList，弹窗插件里没有 id=10000 的多边形，于是 dirAreaRegion 为 null、导流带记录被丢弃；紧接着第 6001-6019 行用重建后的 m_targetCheckXml 校验 onDirArea_enabled，查不到 diversionZone 就弹出『未绘制导流带区域』。即校验读的是被自动绘制路径覆盖掉的数据，而不是用户真实已绘制的导流带。
  claim [supported]: save(plugin) 在自动绘制确认时传入的是弹窗专用插件实例 this.oPluginDlg，而非主页面插件。
  claim [supported]: restorePlateRegion(plugin) 仅从入参插件 getFigure() 的 polygon 列表重建 DetectionRegionList，只有存在 id===10000 的图元时才构造 dirAreaRegion。
  claim [conditional]: 导流带区域是画在主页面插件上的（redrawDirAreaRegion 用 this.plugin.addFigure(4, 10000, …)），自动绘制弹窗的 modelOpened 只调用 displayPostHVTLinesAuto 画线，从不把 10000 多边形写入弹窗插件。
  claim [supported]: 保存校验在重建后的 m_targetCheckXml 上判定 regionType==='diversionZone' 且坐标非零，缺失即 Message.warning('drawDirArea_msg')。
  claim [conditional]: 因此『已绘制导流带 + 使用车道线自动绘制 → 报未绘制导流带区域』的因果链成立：弹窗插件无 10000 图元 → dirAreaRegion=null → 新 DetectionRegionList 无 diversionZone → 校验失败。
  claim [unverified]: 同类缺陷在 videoEpoliceMixin.js 可能存在相同模式（confirmAutoDraw 也 save(this.oPluginDlg)），但其坐标回写逻辑(syncAutoDrawCoordsFromFigure)不同，需单独确认，本次不作为修复目标。
  question [choice]: 修复位置取决于产品语义：是『自动绘制时保留既有导流带』还是『自动绘制时也把导流带画到弹窗插件并要求确认』。; need 确认 HVT 下『导流带绘制』与『车道线自动绘制』的业务先后关系（是否允许先画导流带再自动画线，且自动画线不得清空导流带）
  question [verification]: 主插件 hidePlugin()+stop(0) 后 JS_GetPolygonInfo 是否仍能返回图元，决定能否在保存时从主插件补读导流带。; need 在真实设备上验证 showAutoDraw 后对 this.plugin.getFigure(4) 是否仍返回 id=10000 多边形
  remaining: 在 HVT 模式 + 支持压导流带能力的设备上复现：开启『压导流带行驶』事件 → 点『导流带绘制』画多边形 → 点车道线自动绘制 → 弹窗内确认 → 观察是否仍报『未绘制导流带区域』。
  remaining: 修复前插桩：在 restorePlateRegion 的 plugin.getFigure().then 回调中打印 plugin === this.plugin 与 oFigures.polygon 的 id 列表，确认自动绘制路径下不存在 id=10000。
  remaining: 修复后对比：确认保存后 parkSpeedPloygonRuleChannel 下发的 XML 仍含 regionType=diversionZone 的 DetectionRegion，且车道线/触发线数量与绘制一致。
  remaining: 反向用例：未画导流带时开启该事件并保存，仍应被拦截并提示『未绘制导流带区域』。
  remaining: 静态检查：npm run lint（仅改动 postHvtMixin.js）。
- BGCM2026102400935: other_blocked
  analysis: incomplete; actionability: {'allowed': False, 'reason': 'open questions unresolved; missing evidenceRefs'}
  currentTarget: 1.翻转后抓拍正常。
  cause: Analyze session did not complete
  blocked: sdk returned no parseable JSON analysis
- BGCM2026102202247: other_blocked
  analysis: incomplete; actionability: {'allowed': False, 'reason': 'open questions unresolved; missing evidenceRefs'}
  currentTarget: 1.所有字符叠加正确，各叠加项显示完整可辨。
  cause: Analyze session did not complete
  blocked: sdk returned no parseable JSON analysis
  remaining: 按业务模块手测复现步骤
  remaining: 关注 candidate 文件相关单测（若有）
- BGCM2026102702440: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。
  cause: 区域曝光配置页 regExposure.vue 打开「启用区域曝光」后，watch('enabled') 走的是 displayArea() → videoMixin.setEditAreaInfo(..., false)，该方法生成 ROI XML 并把 editType 固定写成 0 且通过 Plugin.setFigure() 一次性塞入已绘制矩形；随后又立即调用 Plugin.setDrawStatus(true) 与 setSnapDrawMode(1)，两者对同一窗口的绘制状态互相覆盖，结果是图形被置为可编辑已有图元（可拖动）而非进入「重新绘制」态，因此用户只能拖动确认、无法重新框画区域。
  claim [supported]: regExposure.vue 的 enabled watch 在 to=true 时先 displayArea() 再 setDrawStatus(true)+setSnapDrawMode(1)，三者对同一窗口绘制模式重复设置。
  claim [supported]: videoMixin.setEditAreaInfo 生成 ROI XML 时固定写 editType=0（可编辑，可拖顶点/拖动），并 Plugin.setFigure(...) 注入已有矩形，导致图形进入可编辑态而不是重绘态。
  claim [conditional]: drawTools.setRegionInfo 解析 ROI XML 时把 MaxRegionNum 映射为 maxShapeSupport、RedrawMode 映射为 redrawMode，并把 DetectionRegion 转成 figure_type=3 的 rect 集合；因此 maxShapeSupport=1 时插件只允许存在 1 个矩形，用户不先清除就无法再画新的框，表现为只能拖动。
  claim [supported]: setAreaExposure() 在 enabled=true 时也再调一次 displayArea()，与 watch 重复，且不负责把绘制模式置为『新建框』。
  claim [unverified]: 预览页 Tool.startRegionExposure 关闭分支只调 disable3DZoom 并复位标志，未调用 Plugin.disableDrawRectCallback，回调残留。
  claim [supported]: 缺陷期望结果聚焦『画面亮度按区域亮度全局调节』，但 observed 是绘制交互问题；验收目标与观察现象方向不一致，需确认修复目标是交互（可重绘）而非曝光效果。
  question [blocking]: 配置页与预览页有两条完全不同的区域曝光绘制实现，修复目标只能二选一，选错会改错模块。; need 测试环境的操作路径截图或复现步骤：是【配置 > 视频 > 视频编码 > 区域曝光】页签，还是【预览】右上角工具栏的区域曝光按钮。
  question [verification]: 确认插件端 maxShapeSupport=1 与 redrawMode 语义，决定是改 XML 的 editType/RedrawMode 还是改调用顺序。; need jsWebControl/drawTools 的可读文档或对 jsVideoPlugin 非压缩版的核对，验证 maxShapeSupport=1 时再次绘制是拒绝还是自动清除；以及 editType=0/1/2 与『可重绘』的关系。
  remaining: 1) 打开 配置 > 视频 > 视频编码 > 区域曝光，开启『启用区域曝光』，尝试在画面上框选新区域，确认是否可新建框。
  remaining: 2) 记录 setEditAreaInfo 送入的 XML（editType 与 MaxRegionNum/RedrawMode 值）及 setFigure 之后的 getFigure() 返回，确认矩形 id 与 editType。
  remaining: 3) 修复后在开启使能、切换通道、保存后重新回显三种场景分别验证：回显态只可拖动、点击『绘制/重绘』后可清空并重新框选。
  remaining: 4) 预览页路径（若适用）：点击开启区域曝光→拖框→再次点击关闭→再次开启，确认每次都能重新框选，且完成后无残留回调。
  remaining: 5) 运行 npm run lint 确认改动文件无新增 lint 问题。
- BGCM2026102809398: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.网络连拍及牌识正常。
  cause: [Conditional / unverified] 未定位到确定根因。已核实 HVT 模式下的牌识/检测区域叠加绘制（postHvtMixin.displayPlateRegion、PostPRS recRegion）均为 translucent:0 + 彩色描边，客户端不存在把区域填充为纯白的绘制逻辑；纯白现象更可能来自（a）设备上报的抓拍图片像素本身，或（b）网络连拍收图解析时 pictureInfo 类型与二进制图片索引错位 / 主图直接取 binaryImageData[0] 导致显示了错误的图片对象。后者在 uploadPicMixin.startManualCap 中是可指认的代码缺陷。
  claim [conditional]: 客户端所有 HVT 牌识/检测区域叠加均为 translucent:0 的彩色描边，不含纯白填充；因此纯白不是区域叠加绘制造成。
  claim [conditional]: 网络手抓解析中，跳过 fileName 含下划线的 pictureInfo 时不推进 imgIndex，导致后续 pictureInfo 类型与被取用的二进制图片错位；且主图直接使用 binaryImageData[0]，未保证其为场景图。
  claim [unverified]: 收车图片列表会把车牌小图（byType0）排到最后，主图/选中图取 picInfoArr[0]；若设备只上报车牌小图或顺序异常，主图可能显示为车牌局部图。
  claim [unverified]: 放大弹窗图片源为 localLoad(selectedCar.PictureName)，无插件模式经 127.0.0.1 LocalImage 取图；文件缺失时会呈现空白（视觉上接近纯白）。
  question [blocking]: 纯白发生在主图、放大弹窗还是设备侧 JPEG，决定修复目标是客户端收图解析还是设备曝光/上报；回答前无法给出可执行补丁。; need 复现录像/截图，分别标注实时收图主图、放大弹窗、从设备下载的原始 JPEG 三者表现；浏览器 Network 中该次抓取的 XML pictureInfoList 与 multipart 分片顺序
  question [verification]: 若设备侧 JPEG 中车牌区域已过曝为纯白，则客户端改动无意义。; need 同一张抓拍图片的原图（非网页截图）像素检查，以及频闪补光参数配置
  remaining: 在 98G6-HELS 上设置卡口 HVT + 频闪 + 网络连拍，浏览器 DevTools Network 抓取 /ISAPI/Traffic/MNPR/channels/<id> 的响应，保存 XML 与分片顺序
  remaining: 核对 pictureInfoList 中每条 pictureInfo 的 type/fileName，与代码中 imgIndex 配对结果逐条比对，确认是否错位
  remaining: 从设备直接下载同一张抓拍原图，检查车牌区域像素是否为纯白（>250）以判定设备侧 vs 客户端
  remaining: 分别截图实时收图主图与图片放大弹窗，确认纯白出现位置
- BGCM2026102906318: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.能正确触发不礼让行人违章
  cause: [Conditional / unverified] 卡警模式（postHVT）在切换“总车道数”后，行人线与车道线走的是两条不对称的重绘路径：行人线只按 laneId <= relatedLaneCount*2 过滤就绘制，车道线除了 rid <= relatedLaneCount 还多一道“坐标全为 0 就 return”的跳过判断；而 restorePlateRegion 会把未在插件上画出的 LaneLine 索引坐标全部写成 0。车道数变化时 watcher 不 await 地触发 showRegionTwoChoice 重绘，与 restorePlateRegion 的异步 XML 回写竞争，于是出现“行人线更新了、车道线没更新”的偶现现象。
  claim [supported]: 车道线重绘被“坐标全为 0 则跳过”的守卫过滤，而行人线重绘没有该守卫，两者对相同的车道数变化表现不对称。
  claim [conditional]: restorePlateRegion 会把不在插件图元集合中的 LaneLine 索引坐标全部写成 0，因此一旦它与车道数切换并发执行，就会把还需显示的车道线抹成 0，随后重绘时被 C1 的守卫跳过。
  claim [conditional]: relatedLaneCount 变更的 watcher 不 await 地调用 showRegionTwoChoice（内部先 await clearFigure 再并行 setFigure），也不先 restore 再重绘，构成“偶现”的时序窗口。
  claim [supported]: changeLaneNum 只重建 tab 与车道线类型选项，不触碰插件图元，因此重绘完全依赖 showRegionTwoChoice → displayPostHVTLines。
  claim [conditional]: 本票的修复目标应落在 postHvtMixin.js 的重绘/回写链路，而不是 Router 表、index.asp 宿主页或 dataDocking 目录。
  question [choice]: 决定修复落点：postHVT 的 failYieldPed 行人线，还是 postRedLightPed 页面的行人闯红灯行人线。二者代码路径完全不同。; need 现场截图/页面路径（是否含 /config/snap/triggerMode/personRunRedLight），或设备触发模式取值
  question [verification]: 若设备在增大车道数后立即返回非 0 的车道线坐标，则 C1+C2 组合不成立，需退回到纯异步时序解释。; need 切换车道数后一次 WSDK_GetDeviceConfig('triggerModeChannel') 返回的 XML 中 LaneParam/LaneLine 坐标片段
  question [follow_up]: 验收目标（设备能触发不礼让行人违章）与实际结果（Web 绘制未更新）不在同一层面，需明确本票验收口径。; need 测试用例原始预期与复现步骤截图
  remaining: 在卡警模式页面进入“不礼让行人”事件并选择行人线绘制模式（failYieldDistanceMode='line'），绘制至少 2 条车道及对应行人线。
  remaining: 把总车道数从 N 改为 N+1（及 N+1 改回 N），观察车道线与行人线是否同时刷新；重复多次以覆盖偶现窗口。
  remaining: 在切换同时触发 addLane/拖动车道线结束（触发 restorePlateRegion），复现“只更新行人线”的时序竞争。
  remaining: 抓取切换后一次 WSDK_GetDeviceConfig('triggerModeChannel') 的 XML，检查 LaneParam/LaneLine 与 lanePedestrianLineList 的坐标是否为 0。
  remaining: 改动后执行 npm run lint（如项目脚本可用），并回归保存/重新进入页面确认车道线与行人线一致。
