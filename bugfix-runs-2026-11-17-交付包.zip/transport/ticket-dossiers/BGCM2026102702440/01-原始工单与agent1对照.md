# BGCM2026102702440 [【公共】基本功能检查表-视频] 区域曝光，区域不能重新绘制，只能拖动确认是否正常

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [【公共】基本功能检查表-视频] 区域曝光，区域不能重新绘制，只能拖动确认是否正常 | [【公共】基本功能检查表-视频] 区域曝光，区域不能重新绘制，只能拖动确认是否正常 | 否 |
| 测试模块 | misc/【公共】基本功能检查表-视频 | misc/【公共】基本功能检查表-视频 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1.在区域内画任意大小范围，查看区域曝光是否生效。 | 1.在区域内画任意大小范围，查看区域曝光是否生效。 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。 | 1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。 | 否 |
| 实际结果 | 区域曝光，区域不能重新绘制，只能拖动确认是否正常 | 区域曝光，区域不能重新绘制，只能拖动确认是否正常 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：使能区域曝光功能成功前置条件：操作步骤：1.在区域内画任意大小范围，查看区域曝光是否生效。测试数据：预期结果：1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。实际结果：区域曝光，区域不能重新绘制，只能拖动确认是否正常问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：CodeGraph 已确认唯一区域曝光配置组件为 src/Config/view/video/videoCode/regExposure/regExposure.vue（无 pc/mobile 分支）。两条可疑路径（配置页 watch 覆盖 / 预览页回调未注销）需 Q1 定夺。jsVideoPlugin-1.0.0.min.js 为压缩产物，未逐行验证 maxShapeSupport 与 redrawMode 的运行时语义，故 C3 标为 conditional。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`050b3e5e-fb68-49c8-bd6a-27faea09de0c`
- attemptId：`aa35b0d820c3`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.画面亮度会根据配置区域亮度，全局调节画面的亮暗，将亮的地方变暗，暗的地方变亮。
- **代码关联**：src/Config/view/video/videoCode/regExposure/regExposure.vue; src/Config/view/video/videoCode/videoMixin.js; src/Common/libs/jsWebControl/drawTools.js; src/Common/components/pc/integration/Tool/Tool.vue
- **机制**：区域曝光配置页 regExposure.vue 打开「启用区域曝光」后，watch('enabled') 走的是 displayArea() → videoMixin.setEditAreaInfo(..., false)，该方法生成 ROI XML 并把 editType 固定写成 0 且通过 Plugin.setFigure() 一次性塞入已绘制矩形；随后又立即调用 Plugin.setDrawStatus(true) 与 setSnapDrawMode(1)，两者对同一窗口的绘制状态互相覆盖，结果是图形被置为可编辑已有图元（可拖动）而非进入「重新绘制」态，因此用户只能拖动确认、无法重新框画区域。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | regExposure.vue 的 enabled watch 在 to=true 时先 displayArea() 再 setDrawStatus(true)+setSnapDrawMode(1)，三者对同一窗口绘制模式重复设置。 | fact | `supported` |  |
| C2 | videoMixin.setEditAreaInfo 生成 ROI XML 时固定写 editType=0（可编辑，可拖顶点/拖动），并 Plugin.setFigure(...) 注入已有矩形，导致图形进入可编辑态而不是重绘态。 | fact | `supported` |  |
| C3 | drawTools.setRegionInfo 解析 ROI XML 时把 MaxRegionNum 映射为 maxShapeSupport、RedrawMode 映射为 redrawMode，并把 DetectionRegion 转成 figure_type=3 的 rect 集合；因此 maxShapeSupport=1 时插件只允许存在 1 个矩形，用户不先清除就无法再画新的框，表现为只能拖动。 | hypothesis | `conditional` | 插件端 maxShapeSupport=1 时对已存在图形不触发新一轮绘制（对 jsVideoPlugin-1.0.0.min.js 的阅读为 minified 片段，未逐行确认） |
| C4 | setAreaExposure() 在 enabled=true 时也再调一次 displayArea()，与 watch 重复，且不负责把绘制模式置为『新建框』。 | fact | `supported` |  |
| C5 | 预览页 Tool.startRegionExposure 关闭分支只调 disable3DZoom 并复位标志，未调用 Plugin.disableDrawRectCallback，回调残留。 | hypothesis | `unverified` | 测试实际走预览页工具栏路径 |
| C6 | 缺陷期望结果聚焦『画面亮度按区域亮度全局调节』，但 observed 是绘制交互问题；验收目标与观察现象方向不一致，需确认修复目标是交互（可重绘）而非曝光效果。 | conclusion | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：在 regExposure.vue 中把「使能区域曝光」与「重新绘制」两个动作解耦：使能时只负责回显已有区域（editType 置 1 只读/仅可移动的显示态），进入重绘时先 clearFigure 再以新建模式（redrawMode/editType 允许重画）开启绘制；避免 watch → displayArea → setFigure → setDrawStatus 的重复覆盖。若确认是预览页路径，则补上 Tool.startRegionExposure 关闭分支的 disableDrawRectCallback 并在开启分支前 clearFigure。
- 步骤：
  1. 1) 在 regExposure.vue 的 enabled watch 中，to=true 分支不再同时调 setDrawStatus(true)+setSnapDrawMode(1)；改为 displayArea() 只做回显。
  1. 2) 回显路径使用 videoMixin 中 editType=1（不可变形、可移动）或单独新增只读回显方法，避免把回显态变成『可拖动=已完成绘制』的语义。
  1. 3) 增加显式『绘制/重绘』入口：先 Plugin.clearFigure()，再 Plugin.setDrawStatus(true) + setSnapDrawMode(1)，然后仅 setFigure 空集合或 addFigure 一次，让插件进入新建框流程。
  1. 4) 移除 setAreaExposure() 中与 watch 重复的 displayArea() 调用，只保留 channelList 状态同步。
  1. 5) 保存后 saveCallback → getAreaExposureStatus(true) 的回显同样走只读回显分支，不重新进入绘制态。
  1. 6) 若确认为预览页路径：在 Tool.startRegionExposure 的关闭分支追加 Plugin.disableDrawRectCallback(Service.m_iWndIndex, 'Rect')，并在进入前 clearFigure。
- 目标文件：`src/Config/view/video/videoCode/regExposure/regExposure.vue`, `src/Config/view/video/videoCode/videoMixin.js`, `src/Common/components/pc/integration/Tool/Tool.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['1) 打开 配置 > 视频 > 视频编码 > 区域曝光，开启『启用区域曝光』，尝试在画面上框选新区域，确认是否可新建框。', '2) 记录 setEditAreaInfo 送入的 XML（editType 与 MaxRegionNum/RedrawMode 值）及 setFigure 之后的 getFigure() 返回，确认矩形 id 与 editType。', '3) 修复后在开启使能、切换通道、保存后重新回显三种场景分别验证：回显态只可拖动、点击『绘制/重绘』后可清空并重新框选。', '4) 预览页路径（若适用）：点击开启区域曝光→拖框→再次点击关闭→再次开启，确认每次都能重新框选，；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Config/view/video/videoCode/regExposure/`
- 首候选：`src/Config/view/video/videoCode/regExposure/regExposure.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
