# BGCM2026102809398 [基本功能检查表-卡警模式]  98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白而实际车辆被牌识，具体操作详情可见录屏附件

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [基本功能检查表-卡警模式]  98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白而实际车辆被牌识，具体操作详情可见录屏附件 | [基本功能检查表-卡警模式]  98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白而实际车辆被牌识，具体操作详情可见录屏附件 | 否 |
| 测试模块 | 基本功能检查表-卡警模式 | 基本功能检查表-卡警模式 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1.HVT频闪模式下，查看网络连拍及牌识是否正常。 | 1.HVT频闪模式下，查看网络连拍及牌识是否正常。 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1.网络连拍及牌识正常。 | 1.网络连拍及牌识正常。 | 否 |
| 实际结果 | 98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白，而实际车辆被牌识 | 98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白，而实际车辆被牌识 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：频闪网络连拍前置条件：操作步骤：1.HVT频闪模式下，查看网络连拍及牌识是否正常。测试数据：预期结果：1.网络连拍及牌识正常。实际结果：98G6-HELS卡口HVT模式下网络连拍，显示牌识别区域为纯白，而实际车辆被牌识问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`search_draft`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/Config/view/event/exceptionEvent/HVTTrigger/HVTTrigger.vue` | basename contains "hvt" from title/titleTag/testModule/intent | grep |
| `src/Config/view/snap/triggerMode/postHVT/triggerModePostHVT.vue` | basename contains "hvt" from title/titleTag/testModule/intent | grep |
| `src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js` | weak basename substring "hvt" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`low`
- 分析说明：软启动命中 HVTTrigger.vue / postHvtMixin.js 中，HVTTrigger.vue 已排除（卡口联动 IO 配置，与收图显示无关）；postHvtMixin.js 仅作为区域叠加绘制证据使用，未发现填白逻辑。真正可疑链路在 Preview 收图解析，而非 Config/触发模式配置。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`81216427-8a6f-4d68-9238-0690e5a2804f`
- attemptId：`015368e908e0`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.网络连拍及牌识正常。
- **代码关联**：src/Preview/components/base/UploadPic/uploadPicMixin.js; src/Preview/components/base/UploadPic/UploadPic.vue; src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js; src/Config/view/snap/triggerMode/PostPRS/triggerModePostPRS.vue; src/Config/service/service.js
- **机制**：[Conditional / unverified] 未定位到确定根因。已核实 HVT 模式下的牌识/检测区域叠加绘制（postHvtMixin.displayPlateRegion、PostPRS recRegion）均为 translucent:0 + 彩色描边，客户端不存在把区域填充为纯白的绘制逻辑；纯白现象更可能来自（a）设备上报的抓拍图片像素本身，或（b）网络连拍收图解析时 pictureInfo 类型与二进制图片索引错位 / 主图直接取 binaryImageData[0] 导致显示了错误的图片对象。后者在 uploadPicMixin.startManualCap 中是可指认的代码缺陷。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 客户端所有 HVT 牌识/检测区域叠加均为 translucent:0 的彩色描边，不含纯白填充；因此纯白不是区域叠加绘制造成。 | fact | `conditional` | 缺陷描述中的"显示牌识别区域"指画面上的牌识区域叠加或该区域对应的图片内容 |
| C2 | 网络手抓解析中，跳过 fileName 含下划线的 pictureInfo 时不推进 imgIndex，导致后续 pictureInfo 类型与被取用的二进制图片错位；且主图直接使用 binaryImageData[0]，未保证其为场景图。 | hypothesis | `conditional` | 连拍上报中存在被跳过的条目或多图顺序与类型不一致; 用户看到的主图来自该解析路径而非文件路径加载路径 |
| C3 | 收车图片列表会把车牌小图（byType0）排到最后，主图/选中图取 picInfoArr[0]；若设备只上报车牌小图或顺序异常，主图可能显示为车牌局部图。 | hypothesis | `unverified` | 缺陷表现为图片内容异常而非区域叠加异常 |
| C4 | 放大弹窗图片源为 localLoad(selectedCar.PictureName)，无插件模式经 127.0.0.1 LocalImage 取图；文件缺失时会呈现空白（视觉上接近纯白）。 | hypothesis | `unverified` | 现象出现在放大弹窗而非实时主图 |

## ④ 最终修改判断与验证

- **建议修改**：先按 Q1 判定归属：若纯白出现在网页主图但设备 JPEG 正常，则修正 startManualCap 的 pictureInfo↔二进制索引映射（跳过条目时同步推进索引或改为按 pId/类型匹配），并在选取主图时优先 detectionPicture/场景图；若设备 JPEG 本身纯白，则转设备侧曝光/补光，客户端不改。
- 步骤：
  1. 1. 复现并采集一次 HVT 频闪 + 网络连拍的完整响应（XML + multipart），记录 pictureInfoList 的 type/fileName 顺序与二进制分片数量。
  1. 2. 对比网页显示的 img.src 指向的 blob 与 pictureInfo.type 的对应关系，确认是否错位。
  1. 3. 若错位：在 startManualCap 中把被跳过条目对应的二进制分片一并消费（或改用 pId 匹配），并让主图挑选显式偏好场景图。
  1. 4. 若主图正确但放大弹窗空白：核对 localLoad/LocalImage 路径与 selectedCar.PictureName 是否存在。
  1. 5. 若原始 JPEG 即纯白：不在本仓库改动，输出设备侧结论与证据。
- 目标文件：`src/Preview/components/base/UploadPic/uploadPicMixin.js`, `src/Config/service/service.js`, `src/Preview/components/base/UploadPic/UploadPic.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['在 98G6-HELS 上设置卡口 HVT + 频闪 + 网络连拍，浏览器 DevTools Network 抓取 /ISAPI/Traffic/MNPR/channels/<id> 的响应，保存 XML 与分片顺序', '核对 pictureInfoList 中每条 pictureInfo 的 type/fileName，与代码中 imgIndex 配对结果逐条比对，确认是否错位', '从设备直接下载同一张抓拍原图，检查车牌区域像素是否为纯白（>250）以判定设备侧 vs 客户端', '分别截图实时收图主图与图片放大弹窗，确认纯白出现位置']；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`False` / loc@3：`False`
- outcome 相符：`True`
- 期望路径：`src/Config/view/snap/triggerMode/postHVT/`
- 首候选：`src/Preview/components/base/UploadPic/uploadPicMixin.js`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
