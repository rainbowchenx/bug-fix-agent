# BGCM2026102600211 [基本功能检查表-卡警模式] 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [基本功能检查表-卡警模式] 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】 | [基本功能检查表-卡警模式] 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】 | 否 |
| 测试模块 | 基本功能检查表-卡警模式 | 基本功能检查表-卡警模式 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1.HVT模式下启用车道线自动绘制（海外不支持） | 1.HVT模式下启用车道线自动绘制（海外不支持） | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1.车道线和触发线、车道线类型与实际相符，且配置生效 | 1.车道线和触发线、车道线类型与实际相符，且配置生效 | 否 |
| 实际结果 | 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】 | 绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：辅助画线前置条件：操作步骤：1.HVT模式下启用车道线自动绘制（海外不支持）测试数据：预期结果：1.车道线和触发线、车道线类型与实际相符，且配置生效实际结果：绘制完压导流带行驶区域后，使用车道线自动绘制时候，会报错【未绘制导流带区域】问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`low`
- 分析说明：softStart/upstream 候选为空（gap=no_path_token_overlap），本条定位由代码语义检索得到：关键词『未绘制导流带区域』精确命中 postHvtMixin.js:6015 的 Message.warning(I18n.t('drawDirArea_msg'))，再由 confirmAutoDraw → save → restorePlateRegion 主链收敛到唯一数据丢失点。上游 GetAutoDetectLaneResult 数据体不含导流带区域的判断属接口语义推断，未在代码内直接证实。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`87ed70b5-4569-4f81-bd3d-2348515be3fb`
- attemptId：`b516e36e45a6`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.车道线和触发线、车道线类型与实际相符，且配置生效
- **代码关联**：src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js; src/Config/view/snap/triggerMode/videoEpolice/videoEpoliceMixin.js
- **机制**：[Conditional / unverified] 『压导流带行驶』区域(id=10000, regionType=diversionZone)只绘制在主页面插件 this.plugin 上；车道线自动绘制弹窗用的是另一套独立插件实例 oPluginDlgOption.pluginObj。确认自动绘制时 confirmAutoDraw() 调用 save(this.oPluginDlg)，save 内部 restorePlateRegion(plugin) 只从该弹窗插件 getFigure() 读取图形来重建 DetectionRegionList，弹窗插件里没有 id=10000 的多边形，于是 dirAreaRegion 为 null、导流带记录被丢弃；紧接着第 6001-6019 行用重建后的 m_targetCheckXml 校验 onDirArea_enabled，查不到 diversionZone 就弹出『未绘制导流带区域』。即校验读的是被自动绘制路径覆盖掉的数据，而不是用户真实已绘制的导流带。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | save(plugin) 在自动绘制确认时传入的是弹窗专用插件实例 this.oPluginDlg，而非主页面插件。 | fact | `supported` |  |
| C2 | restorePlateRegion(plugin) 仅从入参插件 getFigure() 的 polygon 列表重建 DetectionRegionList，只有存在 id===10000 的图元时才构造 dirAreaRegion。 | fact | `supported` |  |
| C3 | 导流带区域是画在主页面插件上的（redrawDirAreaRegion 用 this.plugin.addFigure(4, 10000, …)），自动绘制弹窗的 modelOpened 只调用 displayPostHVTLinesAuto 画线，从不把 10000 多边形写入弹窗插件。 | fact | `conditional` | 假设 MultiVideoPlugin 实例之间图形数据不共享（各自维护插件窗口图形） |
| C4 | 保存校验在重建后的 m_targetCheckXml 上判定 regionType==='diversionZone' 且坐标非零，缺失即 Message.warning('drawDirArea_msg')。 | fact | `supported` |  |
| C5 | 因此『已绘制导流带 + 使用车道线自动绘制 → 报未绘制导流带区域』的因果链成立：弹窗插件无 10000 图元 → dirAreaRegion=null → 新 DetectionRegionList 无 diversionZone → 校验失败。 | conclusion | `conditional` | 设备返回的 GetAutoDetectLaneResult 数据不含导流带区域（该接口按语义只返回车道线/触发线） |
| C6 | 同类缺陷在 videoEpoliceMixin.js 可能存在相同模式（confirmAutoDraw 也 save(this.oPluginDlg)），但其坐标回写逻辑(syncAutoDrawCoordsFromFigure)不同，需单独确认，本次不作为修复目标。 | hypothesis | `unverified` | videoEpolice 是否也有 onDirArea 校验尚未逐行核对 |

## ④ 最终修改判断与验证

- **建议修改**：在自动绘制保存路径中不要因为弹窗插件缺少 id=10000 图元就丢弃已有导流带区域：restorePlateRegion 构造新 DetectionRegionList 时，若 dirAreaRegion 为空而原有 m_targetCheckXml 中存在 regionType=diversionZone 的 DetectionRegion（坐标非零），则沿用该节点；或等价地在 showAutoDraw 打开弹窗前把主插件的 10000 多边形 setFigure 进弹窗插件。
- 步骤：
  1. 1) 在 postHvtMixin.js restorePlateRegion 中，polygon.forEach 之后（dirAreaRegion 为 null 分支）从旧的 strXml2Json(this.m_targetCheckXml) 里筛出 regionType==='diversionZone' 且坐标非零的 DetectionRegion，赋给 dirAreaRegion。
  1. 2) 在 list.push(dirAreaRegion) 处保持现有逻辑不变，使 detectionLength 克隆/合并逻辑依旧正确（注意 detectionLength 循环对最后一个节点做 append/remove，需验证沿用节点不会重复写入）。
  1. 3) 或者（若 Q2 验证主插件仍可取图元）在 showAutoDraw() 内 hidePlugin 前调用 this.plugin.getFigure(4) 取出 id=10000 的 polygon，dialog opened 后 setFigure 到 oPluginDlg，使弹窗与保存链路数据一致。
  1. 4) 回归验证：HVT + 开启压导流带 + 先画导流带 + 自动绘制车道线 + 确认保存，不再报『未绘制导流带区域』；同时验证未画导流带时仍能正确拦截。
  1. 5) 顺带核对 videoEpoliceMixin.js confirmAutoDraw 同构路径是否存在相同数据丢失（不在本条修复范围内，仅记录）。
- 目标文件：`src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['在 HVT 模式 + 支持压导流带能力的设备上复现：开启『压导流带行驶』事件 → 点『导流带绘制』画多边形 → 点车道线自动绘制 → 弹窗内确认 → 观察是否仍报『未绘制导流带区域』。', '修复前插桩：在 restorePlateRegion 的 plugin.getFigure().then 回调中打印 plugin === this.plugin 与 oFigures.polygon 的 id 列表，确认自动绘制路径下不存在 id=10000。', '修复后对比：确认保存后 parkSpeedPloygonRuleChannel 下发的 XML 仍含 regionType=diver；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Config/view/snap/triggerMode/postHVT/`
- 首候选：`src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
