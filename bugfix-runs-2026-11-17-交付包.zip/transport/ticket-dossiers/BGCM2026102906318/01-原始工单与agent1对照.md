# BGCM2026102906318 [基本功能检查表-卡警模式] 偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [基本功能检查表-卡警模式] 偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线 | [基本功能检查表-卡警模式] 偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线 | 否 |
| 测试模块 | 基本功能检查表-卡警模式 | 基本功能检查表-卡警模式 | 否 |
| 前置条件 | 配置多个车道包含不同方向的车道配置 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1.配置至少两个由上至下方向车道2. 配置至少两个由下至上方向车道3. 为每个车道绘制对应的行人行线和停止线4. 在所有车道上同时模拟行人和车辆通过场景 | 1.配置至少两个由上至下方向车道2. 配置至少两个由下至上方向车道3. 为每个车道绘制对应的行人行线和停止线4. 在所有车道上同时模拟行人和车辆通过场景 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1.能正确触发不礼让行人违章 | 1.能正确触发不礼让行人违章 | 否 |
| 实际结果 | 偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线 | 偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：验证人车判定距离模式为行人检测模式时违章检出前置条件：配置多个车道包含不同方向的车道配置操作步骤：1.配置至少两个由上至下方向车道2. 配置至少两个由下至上方向车道3. 为每个车道绘制对应的行人行线和停止线4. 在所有车道上同时模拟行人和车辆通过场景测试数据：预期结果：1.能正确触发不礼让行人违章实际结果：偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线问题：1.偶现，已设置行人闯红灯的行人线绘制，切总车道数，web只更新了行人线，未更新车道线
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`search_draft`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/Config/view/network/dataDocking/Integrate/Integrate.vue` | package/dir contains "data" from title/titleTag/testModule/intent | grep |
| `src/Config/view/network/dataDocking/advancedEmail/advancedEmail.vue` | package/dir contains "data" from title/titleTag/testModule/intent | grep |
| `src/Config/view/network/dataDocking/alarmUpload/pc/alarmUpload.vue` | package/dir contains "data" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：定位链路：Router 表与 index.asp 不参与；device.js 能力集与本缺陷无灰显关系；jsWebControl 只是 setFigure/clearFigure 执行方。修复点在 postHvtMixin.js 的重绘与 XML 回写一致性。注意 showRegionTwoChoice 在 4939-4940 先 await this.plugin.clearFigure()，若 displayPostHVTLines 未产出车道线，旧车道线已被清空，视觉上即“车道线消失/未更新”。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`024f96c6-b765-4946-a9f9-010e732a5675`
- attemptId：`7d028a275745`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.能正确触发不礼让行人违章
- **代码关联**：src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js
- **机制**：[Conditional / unverified] 卡警模式（postHVT）在切换“总车道数”后，行人线与车道线走的是两条不对称的重绘路径：行人线只按 laneId <= relatedLaneCount*2 过滤就绘制，车道线除了 rid <= relatedLaneCount 还多一道“坐标全为 0 就 return”的跳过判断；而 restorePlateRegion 会把未在插件上画出的 LaneLine 索引坐标全部写成 0。车道数变化时 watcher 不 await 地触发 showRegionTwoChoice 重绘，与 restorePlateRegion 的异步 XML 回写竞争，于是出现“行人线更新了、车道线没更新”的偶现现象。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 车道线重绘被“坐标全为 0 则跳过”的守卫过滤，而行人线重绘没有该守卫，两者对相同的车道数变化表现不对称。 | fact | `supported` |  |
| C2 | restorePlateRegion 会把不在插件图元集合中的 LaneLine 索引坐标全部写成 0，因此一旦它与车道数切换并发执行，就会把还需显示的车道线抹成 0，随后重绘时被 C1 的守卫跳过。 | fact | `conditional` | lineNumLaneArr 仅记录当前插件上存在的车道线索引 |
| C3 | relatedLaneCount 变更的 watcher 不 await 地调用 showRegionTwoChoice（内部先 await clearFigure 再并行 setFigure），也不先 restore 再重绘，构成“偶现”的时序窗口。 | hypothesis | `conditional` | bDrawEnd / bIsDragEnd 或 addLane/delLane 触发的 restorePlateRegion 与车道数切换在时间上重叠 |
| C4 | changeLaneNum 只重建 tab 与车道线类型选项，不触碰插件图元，因此重绘完全依赖 showRegionTwoChoice → displayPostHVTLines。 | fact | `supported` |  |
| C5 | 本票的修复目标应落在 postHvtMixin.js 的重绘/回写链路，而不是 Router 表、index.asp 宿主页或 dataDocking 目录。 | conclusion | `conditional` | 缺陷现场确实是卡警 postHVT 页面（与 titleTag 一致） |

## ④ 最终修改判断与验证

- **建议修改**：让车道线重绘与行人线重绘在同一份 XML 快照上保持一致：车道数变化时先完成 restorePlateRegion 再重绘（串行化），并把“零坐标跳过”的判定从“按坐标全 0”改为“按该车道是否在当前总车道数内且确有有效车道线”，避免 restore 的零值回写误伤仍应显示的车道线；同时补一次与行人线对齐的显式重绘入口。
- 步骤：
  1. 1. 在 postHvtMixin.js 的 'oTopParams.relatedLaneCount' watcher 中，把 changeLaneNum / changeactiveEvent / showRegionTwoChoice 串成一条 await 链，并在此之前或之后显式串行一次 restorePlateRegion，确保 m_xmlObject 的车道线坐标在重绘前已稳定（消除 C3 的竞争窗口）。
  1. 2. 在 displayPostHVTLines 的车道线分支中，把“坐标全 0 直接 return”改为带车道数语义的判断：仅当该 laneId 超出当前 relatedLaneCount、或该车道确实未被绘制过时才跳过；对 rid <= relatedLaneCount 但坐标为 0 的情况，记录并触发一次 restore（或按默认位置补绘），使 1..N 号车道线可见性与行人线一致。
  1. 3. 复核 restorePlateRegion 中“处理未使用的车道线”的置零范围，把置零上限收敛到当前 relatedLaneCount（而不是遍历全部 LaneLine 索引），避免把新增车道对应的车道线一起抹成 0。
  1. 4. displayPostHVTLinesAuto 中 5334-5363 的同构逻辑做相同对齐，避免自动绘制路径复现同一现象。
  1. 5. 回归对照：切换总车道数增减、再切回，确认车道线与行人线同时刷新；并覆盖“不礼让行人 + failYieldDistanceMode==='line'”场景保存/重进页面。
- 目标文件：`src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js`
- applyFix：`False`（报告路径，未改码）
- 建议验证：["在卡警模式页面进入“不礼让行人”事件并选择行人线绘制模式（failYieldDistanceMode='line'），绘制至少 2 条车道及对应行人线。", '把总车道数从 N 改为 N+1（及 N+1 改回 N），观察车道线与行人线是否同时刷新；重复多次以覆盖偶现窗口。', '在切换同时触发 addLane/拖动车道线结束（触发 restorePlateRegion），复现“只更新行人线”的时序竞争。', "抓取切换后一次 WSDK_GetDeviceConfig('triggerModeChannel') 的 XML，检查 LaneParam/LaneLine 与 lanePedest；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`False` / loc@3：`False`
- outcome 相符：`True`
- 期望路径：`src/Config/view/snap/triggerMode/personRunRedLight/`
- 首候选：`src/Config/view/snap/triggerMode/postHVT/postHvtMixin.js`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
