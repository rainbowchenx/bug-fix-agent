# BGCM2026051104084 [LED Tool-校正工具] 每次重新打开校正工具，环境准备-画面显示页面没有回读屏幕自检颜色，默认选择红色

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [LED Tool-校正工具] 每次重新打开校正工具，环境准备-画面显示页面没有回读屏幕自检颜色，默认选择红色 | [LED Tool-校正工具] 每次重新打开校正工具，环境准备-画面显示页面没有回读屏幕自检颜色，默认选择红色 | 否 |
| 测试模块 | 结构,校正工具,接收卡 | 结构,校正工具,接收卡 | 否 |
| 前置条件 | 在LEDTool中完成屏幕配置并选择该屏幕 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1. 进入环境配置界面2. 在请选择一个屏幕下拉框中选择屏幕3. 打开画面显示，选择颜色为蓝色4. 关闭校正工具，重新打开后依然选择当前屏幕，新建工程后在环境准备页面点击画面显示，查看从设备回读的颜色是否准确 | 1. 进入环境配置界面2. 在请选择一个屏幕下拉框中选择屏幕3. 打开画面显示，选择颜色为蓝色4. 关闭校正工具，重新打开后依然选择当前屏幕，新建工程后在环境准备页面点击画面显示，查看从设备回读的颜色是否准确 | 否 |
| 测试数据 | 画面显示回读颜色 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 画面显示回读颜色与实际一致 | 画面显示回读颜色与实际一致 | 否 |
| 实际结果 | 每次打开环境准备-画面显示页面，回读到的屏幕自检颜色都是红色 | 每次打开环境准备-画面显示页面，回读到的屏幕自检颜色都是红色 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Closed | Closed | 否 |

原始缺陷描述全文：

```text
用例名称：画面显示回读颜色前置条件：在LEDTool中完成屏幕配置并选择该屏幕操作步骤：1. 进入环境配置界面2. 在请选择一个屏幕下拉框中选择屏幕3. 打开画面显示，选择颜色为蓝色4. 关闭校正工具，重新打开后依然选择当前屏幕，新建工程后在环境准备页面点击画面显示，查看从设备回读的颜色是否准确测试数据：画面显示回读颜色预期结果：画面显示回读颜色与实际一致实际结果：每次打开环境准备-画面显示页面，回读到的屏幕自检颜色都是红色问题：
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `electron/electron/controller/camera/index.ts` | path substring "tool"+ipc "camera"+ipc "ipc:Camera"+ipc "ipc:CameraPolling" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/luxMeter/index.ts` | path substring "tool"+ipc "luxMeter"+ipc "ipc:LuxMeterPolling"+ipc "ipc:LuxMeter" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/project/index.ts` | path substring "tool"+ipc "project"+ipc "ipc:Project"+ipc "ipc:ProjectDetail" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：软启动给出的 camera/luxMeter/project controller 命中只是 title/module token 的路径子串匹配，经调用链核对与画面显示颜色链路无关，已弃用。真正链路：EnvironmentPrep.onMounted → environmentInfoStore.getAllSendCardInfoByScreen → ipc ProjectDetail_getTestSingleCfg → ledToolPassThrough /getTestSingleCfg → 渲染层 colorMap 映射 → cameraInfoStore.screenColor → useScreenControl.screenColor → ColorRadioGroup。LEDTool 侧 /getTestSingleCfg 的服务端行为不在本仓库索引内，无法据现有证据断言重启后自检色复位；因此对「为何恰好是红色」保留 verification 类问题。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`2a050da5-8fa5-41c0-9bab-c6177b5b6683`
- attemptId：`5213ff015f28`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：画面显示回读颜色与实际一致
- **代码关联**：calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts; calibrationtool/web/src/views/config/EnvironmentPrep.vue; calibrationtool/web/src/views/config/components/ColorRadioGroup.vue; calibrationtool/electron/electron/controller/projectDetail/index.ts; calibrationtool/web/src/views/config/composable.ts
- **机制**：画面显示的颜色回读只在 environmentInfoStore.getAllSendCardInfoByScreen() 里做，而该函数①在 screens.screen 为空时直接 return（新建工程/重开工具后该字段为空，EnvironmentPrep.onMounted 触发时被整段跳过）；②在 getAllSendCardInfoByScreen 接口返回非数组/空数组时 return null（同样跳过后续回读）；③真正回读时把设备返回的 LEDTestSignalType 用只含小写 red/green/blue/white 的 colorMap 映射，映射不到就把 cameraInfoStore.screenColor 写成 'NONE' 并落库。结果：回读要么不发生、要么落空，ColorRadioGroup 拿到的既不是设备自检真实颜色也不是合法的 R/G/B/W 选项值，页面表现为固定落在某个默认通道（实测为红色），而不是与实际一致。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 画面显示颜色回读的唯一触发点是 EnvironmentPrep.onMounted 中 fire-and-forget 调用 getAllSendCardInfoByScreen()，没有 await/catch。 | fact | `supported` |  |
| C2 | getAllSendCardInfoByScreen() 在 screens.screen 为空时直接 return，且在 getAllSendCardInfoByScreen 接口返回非数组/空数组时 return null，两条早退都发生在第 288 行颜色回读之前，因此重开工具/新建工程时回读根本不会执行。 | conclusion | `conditional` | 新建工程场景下 environmentInfo 中 screens.screen 初始为空，用户在选择下拉后才被写入 |
| C3 | 用户在下拉中选择屏幕只触发 useScreenList 的 watch → updateScreens/saveScreens，不会重新触发颜色回读，因此「选择屏幕之后」页面仍不会得到设备自检颜色。 | conclusion | `supported` |  |
| C4 | 回读映射 colorMap 只认小写 red/green/blue/white；设备/子系统写侧存在大写 'R'\|'G'\|'B' 以及 dotGrid/black/checkerboard/white 等取值，映射落空时第 303 行把 screenColor 置为 undefined、第 309-312 行以 'NONE' 落库，'NONE' 不是 ColorRadioGroup 的任一选项值。 | conclusion | `conditional` | LEDTool /getTestSingleCfg 返回的 LEDTestSignalType 与写侧使用的取值空间同源 |
| C5 | ColorRadioGroup 直接把 props.modelValue 塞进 el-radio-group，没有任何合法值归一化；当 modelValue 为 'NONE'/undefined 时组内无有效选项，UI 落到默认外观而非设备真实颜色。 | conclusion | `conditional` | Element Plus el-radio-group 对不匹配 label 的值不选中任何项，视觉上呈现默认通道外观 |
| C6 | electron 侧 getTestSingleCfg 的 catch 分支缺 return（仅调用 commonResponse.getError），错误时 IPC 返回 undefined，渲染层拿到 undefined 后 res2.LEDTestSignalType 抛 TypeError，回读同样失效且无提示。 | hypothesis | `conditional` | IPC 注册层把 undefined 原样回传（registerHandle 原样返回） |

## ④ 最终修改判断与验证

- **建议修改**：把「颜色回读」从 getAllSendCardInfoByScreen 的早退分支里解耦出来，在屏幕选择变化与页面进入时都可重入地执行一次；对回读值做完整枚举归一（含大写与特殊模式）并在无法判定时保留原值而不是写 'NONE'；ColorRadioGroup 对非法 modelValue 做归一化兜底。
- 步骤：
  1. 1) environmentInfo.ts：把 288-312 行的 getTestSingleCfg 回读抽出为独立 action（如 readBackScreenColor），内部判空 sendCardList[0]、用 try/catch 包裹、对 res2 判空，避免异常中断整页初始化。
  1. 2) environmentInfo.ts 255-265：不要因为 getAllSendCardInfoByScreen 返回空数组就 return 掉颜色回读；至少让颜色回读独立于发送卡信息接口的结果。
  1. 3) environmentInfo.ts 293-312：扩充 colorMap 支持大写 'R'/'G'/'B'/'W'（必要时含 dotGrid/black/checkerboard 归为 white/非纯色语义），映射落空时不写 'NONE'，保留现有值并记录告警。
  1. 4) useScreenList（web/src/views/config/composable.ts 的 selectScreenID watch）或 EnvironmentPrep：在屏幕由空变为有值时触发一次颜色回读，覆盖「新建工程→后选屏幕」的时序。
  1. 5) EnvironmentPrep.vue onMounted：把 environmentInfoStore.getAllSendCardInfoByScreen() 改为 await + catch，避免未捕获拒绝。
  1. 6) ColorRadioGroup.vue：对 props.modelValue 做白名单归一（非 R/G/B/W 时回落到确定性值或空态），保证 UI 不会伪装成某个真实通道。
  1. 7) （附带、非本单因果）electron/electron/controller/projectDetail/index.ts 的 getTestSingleCfg catch 分支补 return，避免返回 undefined。
- 目标文件：`calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts`, `calibrationtool/web/src/views/config/EnvironmentPrep.vue`, `calibrationtool/web/src/views/config/composable.ts`, `calibrationtool/web/src/views/config/components/ColorRadioGroup.vue`, `calibrationtool/electron/electron/controller/projectDetail/index.ts`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['1) 在 environmentInfo.ts 第 292/302 行日志下，复现「重开工具→新建工程→选屏幕→环境准备→画面显示」，确认 getTestSingleCfg 是否被调用、返回的 LEDTestSignalType 原值、mappedColor 是否为 undefined。', "2) 在 ColorRadioGroup 里临时打印 props.modelValue，确认页面显示红色时 store 中 screenColor 是 'R'、'NONE' 还是 undefined。", "3) 修复后验证：新建工程→选屏幕→把颜色设为蓝→关闭并重开工具→再次进入环境准备-画面显示；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts`
- 首候选：`calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
