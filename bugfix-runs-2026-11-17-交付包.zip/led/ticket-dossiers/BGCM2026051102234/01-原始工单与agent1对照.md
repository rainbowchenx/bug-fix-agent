# BGCM2026051102234 [LED Tool-校正工具] 分区配置界面“切换至手动配置分区模式”按钮名称与UI不一致

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [LED Tool-校正工具] 分区配置界面“切换至手动配置分区模式”按钮名称与UI不一致 | [LED Tool-校正工具] 分区配置界面“切换至手动配置分区模式”按钮名称与UI不一致 | 否 |
| 测试模块 | 结构,校正工具,接收卡 | 结构,校正工具,接收卡 | 否 |
| 前置条件 | 开启全屏校正-亮色度校正 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、在分区配置界面按测试数据操作 | 1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、在分区配置界面按测试数据操作 | 否 |
| 测试数据 | 切换手动配置分区模式 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 切换手动配置后出现手动配置分区数入口 | 切换手动配置后出现手动配置分区数入口 | 否 |
| 实际结果 | “切换至手动配置分区模式”按钮名称与UI不一致 | “切换至手动配置分区模式”按钮名称与UI不一致 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Closed | Closed | 否 |

原始缺陷描述全文：

```text
用例名称：切换手动配置分区模式前置条件：开启全屏校正-亮色度校正操作步骤：1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、在分区配置界面按测试数据操作测试数据：切换手动配置分区模式预期结果：切换手动配置后出现手动配置分区数入口实际结果：“切换至手动配置分区模式”按钮名称与UI不一致问题：1.UI是：切换至手动配置分区模式，实际客户端是：切换至手动分区配置模式
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `electron/electron/controller/camera/index.ts` | path substring "tool"+ipc "camera"+ipc "ipc:Camera"+ipc "ipc:CameraPolling" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/luxMeter/index.ts` | path substring "tool"+ipc "luxMeter"+ipc "ipc:LuxMeterPolling"+ipc "ipc:LuxMeter" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/project/index.ts` | path substring "tool"+ipc "project"+ipc "ipc:Project"+ipc "ipc:ProjectDetail" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：定位路径（CodeGraph 导航 + 逐文件 Read 复核）：web/src/main.ts 注册全局 $lan → i18n/index.ts 的 lan() 拼接 CalibrationTool. 前缀 → PartitionConfig.vue:488 模板输出 → 137 行取 key switchToManual.name → zh_CN/projectDetail.json:50 字面值。全仓 grep 未发现第二处「手动分区配置」「手动配置分区」生效点，亦无该文案的单元测试。calibration-subsystem 侧 locale 无该文案，说明无需跨进程/跨仓改动。; analyze=sdk
- sessionId：`45f0d39a-f716-49e2-a517-6fff331a06d3`
- attemptId：`3577c4864ab4`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：切换手动配置后出现手动配置分区数入口
- **代码关联**：calibrationtool/web/src/i18n/zh_CN/projectDetail.json; calibrationtool/web/src/views/config/PartitionConfig.vue; calibrationtool/web/src/i18n/en_US/projectDetail.json
- **机制**：[Conditional / unverified] 分区配置页顶部手动/自动切换文案由 computed autoOrManual 从 i18n key `projectDetail.partitionConfig.switchToManual.name` 取词，该 key 的 zh_CN 值为「切换至手动配置分区模式」（配置在分区之前），与 UI 规范/英文资源表达的「手动分区配置模式」次序相反，导致按钮名称与 UI 不一致。功能侧（切换后出现“分区数”入口）本身已由 v-show="isManualConfig" 实现，非本次失败点。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 页面渲染的手动/自动切换文案来自 autoOrManual computed，按 isManualConfig 选择 switchToAuto / switchToManual 两个 i18n key。 | fact | `supported` |  |
| C2 | 模板中该文案唯一输出点为 manual-config-row 内的 span{{ autoOrManual }}，并同时绑定点击事件 toggleManualConfig。 | fact | `supported` |  |
| C3 | zh_CN 该 key 的实际值为「切换至手动配置分区模式」，“分区/配置”的语序与 UI 规范要求的「手动分区配置模式」相反，是票面所报不一致的直接来源。 | conclusion | `conditional` | UI 规范措辞为「切换至手动分区配置模式」（依标题把当前值列为错值、以及英文资源 'manual partition configuration mode' 的语序推断） |
| C4 | 切换后出现“手动配置分区数入口”的行为已实现：分区数表单项由 v-show="isManualConfig" 控制显示。 | fact | `supported` |  |
| C5 | en_US 同一 key 为 'Switch to manual partition configuration mode.'，语序对应“手动分区配置模式”，佐证中文应改为“手动分区配置”。 | hypothesis | `conditional` | 英文文案本身是已评审通过的规范译法，而非同样待纠偏的旧文案 |
| C6 | 票面「问题」栏对 UI 值与客户端值的描述与标题/代码事实相反（代码中客户端值为“手动配置分区”），属票面笔误而非第二个缺陷。 | conclusion | `conditional` | 以标题引用的按钮名称与仓库代码为准判断客户端实际显示值 |

## ④ 最终修改判断与验证

- **建议修改**：只改文案，不动逻辑：把 zh_CN 中 `CalibrationTool.projectDetail.partitionConfig.switchToManual.name` 的值由「切换至手动配置分区模式」改为「切换至手动分区配置模式」（语序对齐 UI 规范与英文译法），并按需同步 en_US 文案的大小写/句点风格。不修改 autoOrManual、toggleManualConfig、isManualConfig 等行为代码。
- 步骤：
  1. 确认 Q1：以 UI 设计稿为准确定权威文案（默认按标题与英文资源推断为「切换至手动分区配置模式」）。
  1. 编辑 calibrationtool/web/src/i18n/zh_CN/projectDetail.json 第 50 行，仅替换该 key 的字符串值，保持 JSON 缩进与逗号风格一致。
  1. （可选，取决于 Q2）同步 calibrationtool/web/src/i18n/en_US/projectDetail.json 第 50 行措辞/句点，与第 51 行 switchToAuto 的大小写风格对齐。
  1. 验证：在分区配置页确认顶部切换行显示新文案；点击后确认“分区数”入口照常出现（v-show=isManualConfig 未被破坏）。
  1. 静态校验：对改动文件执行 JSON 解析/项目 lint，确保 i18n 文件合法。
- 目标文件：`calibrationtool/web/src/i18n/zh_CN/projectDetail.json`, `calibrationtool/web/src/i18n/en_US/projectDetail.json`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['启动校正工具 → 全屏亮色度校正 → 进入分区配置页，确认顶部切换行文案与 UI 规范逐字一致。', '点击切换行，确认切换为手动模式后“分区数”行列输入项出现（预期结果的行为回归）。', '再次点击切回自动模式，确认文案切换为 switchToAuto 对应值且无残留。', '对改动的 i18n JSON 执行 JSON 解析校验，并运行项目 lint（或 vue-tsc）确认无语法/类型问题。']；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`False` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`calibrationtool/web/src/views/config/PartitionConfig.vue`
- 首候选：`calibrationtool/web/src/i18n/zh_CN/projectDetail.json`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
