# BGCM2026051104842 [LED Tool-校正工具] 环境准备-画面显示：未获取当前设备实际的画面显示颜色

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [LED Tool-校正工具] 环境准备-画面显示：未获取当前设备实际的画面显示颜色 | [LED Tool-校正工具] 环境准备-画面显示：未获取当前设备实际的画面显示颜色 | 否 |
| 测试模块 | 结构,校正工具,接收卡 | 结构,校正工具,接收卡 | 否 |
| 前置条件 | 选择亮度校正任务并启动 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1. 执行区域定位步骤2. 执行采集红色步骤3. 执行采集绿色步骤4. 执行采集蓝色步骤5. 执行系数生成步骤6. 执行系数上传步骤7. 执行系数固化步骤 | 1. 执行区域定位步骤2. 执行采集红色步骤3. 执行采集绿色步骤4. 执行采集蓝色步骤5. 执行系数生成步骤6. 执行系数上传步骤7. 执行系数固化步骤 | 否 |
| 测试数据 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 预期结果 | 1. 区域定位步骤完成2. 红色采集步骤完成3. 绿色采集步骤完成4. 蓝色采集步骤完成5. 系数生成步骤完成6. 系数上传步骤完成7. 系数固化步骤完成 | 1. 区域定位步骤完成2. 红色采集步骤完成3. 绿色采集步骤完成4. 蓝色采集步骤完成5. 系数生成步骤完成6. 系数上传步骤完成7. 系数固化步骤完成 | 否 |
| 实际结果 | 环境准备-画面显示：未获取当前设备实际的画面显示颜色 | 环境准备-画面显示：未获取当前设备实际的画面显示颜色 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Closed | Closed | 否 |

原始缺陷描述全文：

```text
用例名称：验证亮度校正工序各步骤图像采集功能前置条件：选择亮度校正任务并启动操作步骤：1. 执行区域定位步骤2. 执行采集红色步骤3. 执行采集绿色步骤4. 执行采集蓝色步骤5. 执行系数生成步骤6. 执行系数上传步骤7. 执行系数固化步骤测试数据：预期结果：1. 区域定位步骤完成2. 红色采集步骤完成3. 绿色采集步骤完成4. 蓝色采集步骤完成5. 系数生成步骤完成6. 系数上传步骤完成7. 系数固化步骤完成实际结果：环境准备-画面显示：未获取当前设备实际的画面显示颜色问题：
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `electron/electron/controller/camera/index.ts` | path substring "tool"+ipc "camera"+ipc "ipc:Camera"+ipc "ipc:CameraPolling" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/luxMeter/index.ts` | path substring "tool"+ipc "luxMeter"+ipc "ipc:LuxMeterPolling"+ipc "ipc:LuxMeter" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/project/index.ts` | path substring "tool"+ipc "project"+ipc "ipc:Project"+ipc "ipc:ProjectDetail" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：层级定位：renderer 呈现层(ConfigView/ColorRadioGroup) ← 状态层(environmentInfo.getAllSendCardInfoByScreen → cameraInfoStore) ← IPC 域(controller/projectDetail.getTestSingleCfg) ← 外部 LEDTool /getTestSingleCfg。真正的修复落点是中间两级（IPC 错误吞掉 + store 回读无保护/时序），呈现层无需改动。软启动给出的 controller/camera、controller/luxMeter、controller/project 已排除。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`6bd88560-8f33-44d9-ad26-667c120438fc`
- attemptId：`61718a788ef0`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1. 区域定位步骤完成2. 红色采集步骤完成3. 绿色采集步骤完成4. 蓝色采集步骤完成5. 系数生成步骤完成6. 系数上传步骤完成7. 系数固化步骤完成
- **代码关联**：calibrationtool/electron/electron/controller/projectDetail/index.ts; calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts; calibrationtool/web/src/views/config/EnvironmentPrep.vue; calibrationtool/web/src/views/config/composable.ts; calibrationtool/web/src/stores/modules/projectDetail/cameraInfo.ts; calibrationtool/web/src/views/ConfigView.vue
- **机制**：[Conditional / unverified] 「画面显示」当前颜色的唯一来源是设备回读链路 EnvironmentPrep.onMounted → environmentInfoStore.getAllSendCardInfoByScreen() → ProjectDetail_getTestSingleCfg → /getTestSingleCfg → colorMap[res2.LEDTestSignalType] → cameraInfoStore.screenColor。该链路有三处缺陷叠加，任一处失败都会让回读值不落库、界面仍显示 DB/默认颜色（当前代码默认 screenColor='G'，失败时还会被写成非法值 'NONE'）：(1) main 侧 getTestSingleCfg 不复核 ledToolPassThrough 的 success，失败时把 data:null 用 getResponse 包成 code 200 的“成功空数据”，且 catch 分支漏 return；(2) renderer 侧回读处无空值/异常保护，直接访问 this.data.sendCardList[0].ip 与 res2.LEDTestSignalType，抛错即中断整个 getAllSendCardInfoByScreen，回读值永不写入 cameraInfoStore；(3) EnvironmentPrep 在 onMounted 里 fire-and-forget 调用该 action，与 useScreenList 的屏幕拓扑加载（填充 sendCardList）并发且未 await/未 catch，拓扑未就绪时 sendCardList[0] 为 undefined。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | main 侧 getTestSingleCfg 不判断 ledToolPassThrough 返回的 success，失败时返回 commonResponse.getResponse(null)，被包装成 code=200 + data=null，回读失败对渲染层完全静默。 | fact | `conditional` | ledToolPassThrough 失败时返回 { success:false, msg, data:null }（已在 service/calibration/index.ts:204-231 读到） |
| C2 | main 侧 getTestSingleCfg 的 catch 分支写成 commonResponse.getError(...) 而没有 return，异常路径返回 undefined，渲染层随后对 undefined 取 .code 会再次抛错。 | fact | `supported` |  |
| C3 | renderer 侧回读处无任何存在性保护：先取 this.data.sendCardList[0].ip/port，再直接读 res2.LEDTestSignalType；sendCardList 为空或 res2 为 null 都会抛 TypeError，整个 getAllSendCardInfoByScreen 中断，cameraInfoStore.screenColor 不会被回读值覆盖。 | fact | `supported` |  |
| C4 | 映射失败时该 action 会把 screenColor 持久化为字符串 'NONE'（不是 R/G/B/W 任一合法单选项），ColorRadioGroup 因此无任何选中项，正是“未获取当前设备实际的画面显示颜色”的可见表现。 | fact | `conditional` | ColorRadioGroup 仅渲染 label R/G/B/W（已读 ColorRadioGroup.vue 1-15 行） |
| C5 | EnvironmentPrep.onMounted 以 fire-and-forget 方式调用 getAllSendCardInfoByScreen()，同时 useScreenList 的 immediate watcher 异步调用 getScrrenLayout() 填充 sendCardList；两者无先后依赖保证，回读可能在 sendCardList 尚未就绪时执行。 | hypothesis | `conditional` | 首次打开或切屏后 sendCardList 由 getScrrenLayout 异步写入；非首开时来自 DB 因而可能已有值 |
| C6 | 回读失败后界面回落值来自 cameraInfoStore 的 DB 值或 DEFAULT_CAMERA_INFO.screenColor='G'，因此用户看到的是“与设备实际不符/无选中”的颜色，而非设备真实状态。 | conclusion | `conditional` | 该验收对象未在别处（如 useScreenControl._setScreenParams 落库）被手工改成正确值 |
| C7 | 回读只采信 sendCardList[0] 一张发送卡，多发送卡屏幕的颜色聚合语义缺失。 | hypothesis | `unverified` | 被测屏幕为多发送卡 |

## ④ 最终修改判断与验证

- **建议修改**：按调用链自下而上修三处：main 侧让回读失败显式失败；renderer 回读加空值/异常保护并禁止写入非法颜色；调用时序改为在 sendCardList 就绪后再回读并统一 catch。
- 步骤：
  1. 1) electron/electron/controller/projectDetail/index.ts · getTestSingleCfg：补 `if (!res.success) return commonResponse.getError(res.msg \|\| commonResponse.lan('getTestSingleCfgFailed'))`，catch 分支补 `return`，杜绝 code 200 + data null。
  1. 2) web/src/stores/modules/projectDetail/environmentInfo.ts · getAllSendCardInfoByScreen：回读前校验 `this.data.sendCardList?.length` 且首卡 ip/port 存在，否则直接返回；回读调用包 try/catch；改 `res2?.LEDTestSignalType` 取值；仅当 mappedColor 属于 R/G/B/W 时才写 cameraInfoStore 并落库，不再写 'NONE'（保留既有 DB 值）。
  1. 3) web/src/views/config/EnvironmentPrep.vue · onMounted：把 getAllSendCardInfoByScreen 改为 await + catch，或改为在 sendCardList 从空变为非空时触发（watch），避免与 getScrrenLayout 竞态。
  1. 4) （可选，取决于 Q2）在 store 内对多发送卡回读做聚合：全部一致取该值，不一致写入“未知/不选中”，与 UI 展示口径对齐。
  1. 5) 回归：首次打开、切屏、重开工具三种入口下确认「画面显示-屏幕颜色」与设备实际一致；并确认回读失败时给出提示而非静默回落。
- 目标文件：`calibrationtool/electron/electron/controller/projectDetail/index.ts`, `calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts`, `calibrationtool/web/src/views/config/EnvironmentPrep.vue`, `calibrationtool/web/src/views/config/composable.ts`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['1) 静态检查：在 calibrationtool 下执行 `npx vue-tsc --noEmit`（或项目既有 typecheck 脚本），确认新增的空值保护无类型错误。', "2) 单测/逻辑验证（若该仓库有测试）：对 getAllSendCardInfoByScreen 造三类输入（sendCardList 为空、getTestSingleCfg 返回 null、返回 {LEDTestSignalType:'green'}），断言不抛错且仅在合法颜色时写入 screenColor。", "3) 实机复现：首次打开校正工具进入环境准备，观察 console 是否打印 'getTes；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`False` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`calibrationtool/web/src/stores/modules/projectDetail/environmentInfo.ts`
- 首候选：`calibrationtool/electron/electron/controller/projectDetail/index.ts`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
