# BGCM2026051103043 [LED Tool-校正工具] 手动配置分区模式分区行*列较大时拓扑预览中的分区显示不全

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [LED Tool-校正工具] 手动配置分区模式分区行*列较大时拓扑预览中的分区显示不全 | [LED Tool-校正工具] 手动配置分区模式分区行*列较大时拓扑预览中的分区显示不全 | 否 |
| 测试模块 | 结构,校正工具,接收卡 | 结构,校正工具,接收卡 | 否 |
| 前置条件 | 开启全屏校正-亮色度校正 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、点击手动配置分区 4、按测试数据操作 | 1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、点击手动配置分区 4、按测试数据操作 | 否 |
| 测试数据 | 分区数行数输入1-99之间的数 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 能输入成功，客户端显示正常 | 能输入成功，客户端显示正常 | 否 |
| 实际结果 | 手动配置分区模式分区行*列较大时拓扑预览分区显示不全 | 手动配置分区模式分区行*列较大时拓扑预览分区显示不全 | 否 |
| 严重级别 | 中 | 中 | 否 |
| 缺陷状态 | Closed | Closed | 否 |

原始缺陷描述全文：

```text
用例名称：分区数-行数适中前置条件：开启全屏校正-亮色度校正操作步骤：1、进入LEDTool校正工具 2、进入全屏亮色度校正 3、点击手动配置分区 4、按测试数据操作测试数据：分区数行数输入1-99之间的数预期结果：能输入成功，客户端显示正常实际结果：手动配置分区模式分区行*列较大时拓扑预览分区显示不全问题：1.拖动横向和纵向的滑动条，分区显示不全
```

- 池判定：`needs_info`
- 期望质量：`explicit`
- 排除/归类原因：`C1c` — vague adjective without quantification

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`not_investigated`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `electron/electron/controller/camera/index.ts` | path substring "tool"+ipc "camera"+ipc "ipc:Camera"+ipc "ipc:CameraPolling" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/luxMeter/index.ts` | path substring "tool"+ipc "luxMeter"+ipc "ipc:LuxMeterPolling"+ipc "ipc:LuxMeter" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/project/index.ts` | path substring "tool"+ipc "project"+ipc "ipc:Project"+ipc "ipc:ProjectDetail" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：定位路径：package.json/main + preload 只用于确认渲染层归属，本缺陷不跨进程——PartitionConfig → partitionPreview 是纯 renderer 组件；分区数来自 renderer Pinia（partitionInfo store），不经过 ProjectDetail IPC 与 calibration-subsystem。注入的 electron-process-boundary / monorepo-workspace 在此不改变 locus；vue-debug 与 hierarchical-localization 用于把范围从页面收敛到 components/partitionPreview.vue 的 scoped 样式。运行期 CSS 行为（grid 轨道解析、滚动区计算）未实机观察，属条件性证据。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`192169b3-c093-4dd2-a785-d26ccfd2276d`
- attemptId：`9e502028ba25`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：能输入成功，客户端显示正常
- **代码关联**：calibrationtool/web/src/views/config/components/partitionPreview.vue; calibrationtool/web/src/views/config/PartitionConfig.vue
- **机制**：分区拓扑预览的定位点不是 IPC/后端，而是 renderer 组件 partitionPreview.vue 的网格 CSS：预览容器 .partTopology 同时用了「固定高度语义」的 min-height:100% + width:max-content/min-width:100%，行轨与列轨又都用 minmax(80px,1fr)，再叠加外层 .partition-topology-preview 的 overflow:hidden。行/列数变大（手动模式允许 1–99）时，1fr 轨道在受父级确定性高度约束的网格里被压回父容器尺寸、网格盒子本身不随全部轨道增长，溢出部分被外层 overflow:hidden 裁掉，导致内层 .table-content 的 overflow:auto 滚动区算不到完整轨道范围——表现就是拖动横向/纵向滚动条仍显示不全。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 手动配置分区的行列输入上限是 99，因此常态会出现 99×99=9801 个分区格子。 | fact | `supported` |  |
| C2 | 分区预览把 localPartitionInfo.partitionCount 作为 previewPartitionCount 直接驱动网格 CSS 变量 --rows/--columns。 | fact | `unverified` |  |
| C3 | .partTopology 的行轨与列轨均使用 minmax(80px, 1fr)，且网格盒子带 min-height:100% / width:max-content / min-width:100%，使网格盒子的高度由上层的确定性尺寸兜底而不是由全部轨道内容撑开。 | fact | `unverified` |  |
| C4 | 内层滚动区 .table-content（overflow:auto，宽高 calc(100% - 16px)）是唯一可滚动容器，外层 .partition-topology-preview 设为 overflow:hidden，一旦网格盒子不增长，溢出轨道会落在滚动区之外被裁掉，滚动条无法到达最后一行/列。 | hypothesis | `conditional` | 浏览器对 grid 容器 min-height:100% + 全 1fr 轨道在行数超限时的尺寸解析为「网格盒高=父级确定性高度」，而非「网格盒高=轨道总和」; 外层 flex 布局（justify-content:center / align-items:flex-start）不额外提供可滚动的溢 |
| C5 | 退出条件不是后端数据错误：分区数只影响渲染，手动模式不经过 autoGeneratePartition 即可显示预览，因此 IPC 透传与 calibration-subsystem 与本缺陷无因果。 | conclusion | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：让分区拓扑网格盒子随全部轨道内容增长，使 .table-content 的滚动范围覆盖完整行列；保留外层裁切语义，只修轨道尺寸与网格盒子高度来源。
- 步骤：
  1. 在 partitionPreview.vue 的 .partTopology 中删除 min-height: 100%（这是让网格盒高被父容器锁死的关键），高度回到内容驱动。
  1. 把 grid-template-rows: repeat(var(--rows), minmax(80px, 1fr)) 改为 grid-auto-rows: minmax(80px, auto)（或 repeat(var(--rows), minmax(80px, auto))），避免行轨在确定性高度下被 1fr 分配后挤压/溢出网格盒。
  1. 列轨保留 repeat(var(--columns), minmax(80px, 1fr))，并保留 width: max-content 以保证横向滚动范围；确认横向滚动条能到达最后一列。
  1. 校验 .part-div 的 min-width: 0 / min-height: 80px 与新轨道定义不冲突（格子最小 80px，内容不撑破轨道即可）。
  1. 不改 PartitionConfig.vue 中 .partition-topology-preview 的 overflow: hidden（保持不侵占相机摆放距离区域），仅确认内层 .table-content 滚动条可达。
  1. 不修改 1–99 的输入上限、不改动 IPC/子系统链路——那是本缺陷的输入前提，不是缺陷点。
- 目标文件：`calibrationtool/web/src/views/config/components/partitionPreview.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['静态检查：cd calibrationtool/web && npx vue-tsc --noEmit（仅确认改动未引入类型错误）', '手工回归（必做）：LEDTool 校正工具 → 全屏亮色度校正 → 手动配置分区，分别输入 10×10、40×40、99×99，检查拓扑预览最后一行与最后一列可通过横纵滚动条完整到达，且分区名不互相压盖', '回归非本单行为：自动配置分区模式下「自动生成分区」后的预览不受影响（同组件另一入口 previewPartitionCount 缺省走 store）', '回归开始校正页 partitionPreview（isStartCalibration=tr；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`calibrationtool/web/src/views/config/components/partitionPreview.vue`
- 首候选：`calibrationtool/web/src/views/config/components/partitionPreview.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
