# BGCM2026051201340 [LED Tool-校正工具] 相机调节-粗调相机：英文版本未翻译操作提示

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [LED Tool-校正工具] 相机调节-粗调相机：英文版本未翻译操作提示 | [LED Tool-校正工具] 相机调节-粗调相机：英文版本未翻译操作提示 | 否 |
| 测试模块 | 结构,校正工具,接收卡 | 结构,校正工具,接收卡 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面 | 1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面 | 否 |
| 测试数据 | 亮色度校正-相机调节界面查看 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 显示英文正常，界面无中文、乱码显示 | 显示英文正常，界面无中文、乱码显示 | 否 |
| 实际结果 | 相机调节-粗调相机：英文版本未翻译操作提示 | 相机调节-粗调相机：英文版本未翻译操作提示 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Closed | Closed | 否 |

原始缺陷描述全文：

```text
用例名称：亮色度校正-相机调节界面查看成功前置条件：操作步骤：1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面测试数据：亮色度校正-相机调节界面查看预期结果：显示英文正常，界面无中文、乱码显示实际结果：相机调节-粗调相机：英文版本未翻译操作提示问题：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `electron/electron/controller/camera/index.ts` | path substring "tool"+ipc "camera"+ipc "ipc:Camera"+ipc "ipc:CameraPolling" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/luxMeter/index.ts` | path substring "tool"+ipc "luxMeter"+ipc "ipc:LuxMeterPolling"+ipc "ipc:LuxMeter" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/project/index.ts` | path substring "tool"+ipc "project"+ipc "ipc:Project"+ipc "ipc:ProjectDetail" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：查询路径：codegraph_explore 定位到 CameraAdjust.vue（唯一命中粗调逻辑的页面，路由 web/src/router/index.ts 引用），随后 Grep『粗调』确认 zh_CN 键，Read zh_CN/en_US projectDetail.json 对比确认 116-120、172-179 键值齐备；Grep 全 en_US 目录无 CJK 字符，排除语言包缺项；Grep electron/ 与 calibration-subsystem 无粗调中文下发，排除后端透传。assets 目录仅存在 apertureAdjust.svg（无 _en 变体），而 cameraPosition_cn_dark/light、cameraPosition_en_dark/light 四件套齐全，指向资源本地化缺失。apertureAdjust.svg 文件过大（22 万 token，内嵌 base64 <image>，无 <text>/<tspan>）无法逐行读取，其图内文字是否中文需人工查看图像；此点为本单唯一未闭环证据。; analyze=sdk; par
- sessionId：`1b247fa7-638a-4d14-81fc-d744d9dc170c`
- attemptId：`a277f2be5066`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：显示英文正常，界面无中文、乱码显示
- **代码关联**：calibrationtool/web/src/views/config/components/ComTip.vue; calibrationtool/web/src/views/config/CameraAdjust.vue; calibrationtool/web/src/assets/projectDetail/apertureAdjust_en.svg（新增资源）; calibrationtool/web/src/views/config/CameraAdjust.vue（仅当附带项获批）
- **机制**：[Conditional / unverified] 粗调相机阶段的提示文案本身已全部走 i18n（roughAdjustSegments 全部是 $lan 键，en_US 中 9 个 roughAdjustTip.* 键均存在且为英文），中文残留来自粗略调整 ComTip 内「操作说明」弹层引用的示意图资源：ComTip.vue 对 apertureAdjust.svg 无条件使用同一张（内嵌 base64 位图，无语义文本节点，即图内文字被“烧”进图片）的图片，而同页的 cameraPosition 却提供了 _cn/_en 两套资源，说明该资源缺少英文版本，英文界面下仍显示中文截图，即缺陷所述的“操作提示未翻译”。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | 粗调提示条文案由 roughAdjustSegments 组成，9 个片段全部通过 $lan 关键字获取，不存在硬编码中文。 | fact | `supported` |  |
| c2 | en_US/projectDetail.json 已完整提供 cameraAdjust.roughAdjustTip.* 的英文译文，因此提示条在英文环境下应显示英文。 | fact | `unverified` |  |
| c3 | 粗调进行中 addTipVisible 为 true，ComTip 渲染「操作说明」弹层，其中 apertureAdjust.svg 被无条件引用，而 cameraPosition 图按 _cn/_en 分语言切换，说明孔径示意图缺少英文版本。 | hypothesis | `conditional` | apertureAdjust.svg 内嵌位图（base64 <image>）中的标注文字为中文，需人工查看图像确认 |
| c4 | apertureAdjust.svg 不含 <text>/<tspan> 语义文本，文字被栅格化为 base64 图片，无法通过 CSS/运行时切换语言。 | fact | `supported` |  |
| c5 | 相机精调提示在 updateCameraAdjustTip 中使用硬编码的中文全角标点「，」「；」「（」「）」，英文界面会出现中文标点；属同页面相邻步骤的附带问题，非本单「粗调相机」目标的直接成因。 | hypothesis | `conditional` | 验收标准要求“界面无中文”，全角中文标点可能同样被判定为中文残留 |

## ④ 最终修改判断与验证

- **建议修改**：为粗调「操作说明」弹层补齐英文版光圈调节示意图，并按现有 cameraPosition 的 _cn/_en 命名与语义在 ComTip.vue 中按当前语言切换，避免英文界面显示中文截图。
- 步骤：
  1. 1. 制作/导出 apertureAdjust_en.svg（英文标注版），与 apertureAdjust.svg 同目录并存；若短期无英文图源，可先按 curLanguage 隐藏该图或替换为纯图形版（无文字）。
  1. 2. 在 ComTip.vue 中沿用 cameraPosition 的写法，把 line 117 的单张 img 拆为 curLanguage === 'zh_CN' / !== 'zh_CN' 两张，引用 apertureAdjust.svg / apertureAdjust_en.svg。
  1. 3. 顺带确认另两张参考图不会泄露中文：effectReference_point.png、effectReference_balance&highspeed.png 为纯图像无文字（已核对图像内容），可保留。
  1. 4. （附带，需产品确认是否纳入本单）把 CameraAdjust.vue updateCameraAdjustTip 中硬编码的『，』『；』『（』『）』改为语言包键或按语言选择标点，避免英文界面出现中文标点。
  1. 5. 验证：切换 en_US 后进入 相机调节页 → 点击「Camera Coarse Adjustment」进入粗调 → 观察顶部 ComTip 提示条与「Operation Description」悬浮弹层，确认无中文字符。
- 目标文件：`calibrationtool/web/src/views/config/components/ComTip.vue`, `calibrationtool/web/src/assets/projectDetail/apertureAdjust_en.svg（新增资源）`, `calibrationtool/web/src/views/config/CameraAdjust.vue（仅当附带项获批）`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['cd calibrationtool/web && npx vue-tsc --noEmit（或项目 lint）确认改动类型/语法无误', '构建后切换语言为 en_US，进入 项目 → 相机调节 页面，点击 Camera Coarse Adjustment 进入粗调', '观察顶部 ComTip 提示条：应为英文 1./2./3./4. 四步提示（对应 roughAdjustTip.*）', '悬停『Operation Description』，确认弹层内光圈调节示意图为英文标注，无中文残留', '回归 zh_CN：确认中文界面示意图仍为原 apertureAdjust.svg']；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`False` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`calibrationtool/web/src/views/config/CameraAdjust.vue`
- 首候选：`calibrationtool/web/src/views/config/components/ComTip.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
