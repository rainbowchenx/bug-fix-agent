# BGCM2026051201741 [LED Tool-校正工具] 相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [LED Tool-校正工具] 相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确 | [LED Tool-校正工具] 相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确 | 否 |
| 测试模块 | 结构,校正工具,接收卡 | 结构,校正工具,接收卡 | 否 |
| 前置条件 |  | —（Agent-1 无对应字段） | 原始侧为空 |
| 操作步骤 | 1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面 | 1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面 | 否 |
| 测试数据 | 亮色度校正-相机调节界面查看 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 显示英文正常，界面无中文、乱码显示 | 显示英文正常，界面无中文、乱码显示 | 否 |
| 实际结果 | 相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确 | 相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Closed | Closed | 否 |

原始缺陷描述全文：

```text
用例名称：亮色度校正-相机调节界面查看成功前置条件：操作步骤：1、切换至英文界面 2、查看数据栏所示界面是否英文显示正常，未存在中文界面测试数据：亮色度校正-相机调节界面查看预期结果：显示英文正常，界面无中文、乱码显示实际结果：相机调节-粗调相机：英文版本下针对亮度计未连接的报错翻译不准确问题：提示翻译对应的是设备未连接而非亮度计
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `electron/electron/controller/camera/index.ts` | path substring "tool"+ipc "camera"+ipc "ipc:Camera"+ipc "ipc:CameraPolling" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/luxMeter/index.ts` | path substring "tool"+ipc "luxMeter"+ipc "ipc:LuxMeterPolling"+ipc "ipc:LuxMeter" from title/titleTag/testModule/intent | grep |
| `electron/electron/controller/project/index.ts` | path substring "tool"+ipc "project"+ipc "ipc:Project"+ipc "ipc:ProjectDetail" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：层级定位结论：renderer(CameraAdjust.vue 粗调) → 无亮度计校验 → 提示文本来自共享/后端亮度计域。repo → calibration-subsystem(locale/en_US\|luxMeter.json 文案) → 可能的透传层 calibrationtool/electron/electron/controller/luxMeter/index.ts（CodeGraph 命中，未用 Read 复核，仅作路径线索）。前端 i18n 的两个候选（projectDetail.notConnected、boxConfig.deviceNotConnected）中，前者是“Not Connected”状态标签、后者仅箱体校正使用，均弱于子系统亮度计实际句式的匹配度；因此首选修复点在子系统 en_US/luxMeter.json，待 q1 证据确认后再动前端文件。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`c011c262-c563-45ee-a1cb-34e02ef84222`
- attemptId：`3b335cf3e559`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：显示英文正常，界面无中文、乱码显示
- **代码关联**：calibration-subsystem/src/locale/en_US/luxMeter.json; calibration-subsystem/src/locale/zh_CN/luxMeter.json; calibrationtool/web/src/views/config/CameraAdjust.vue; calibrationtool/web/src/i18n/en_US/projectDetail.json; calibrationtool/web/src/i18n/zh_CN/projectDetail.json; calibrationtool/web/src/i18n/en_US/boxConfig.json; calibrationtool/web/src/i18n/zh_CN/boxConfig.json
- **机制**：[Conditional / unverified] 英文版出现的“Device not connected”并非页面自身拼装，而是亮度计（luxMeter）域的错误文案英文翻译丢掉了设备名：calibration-subsystem 的 en_US/luxMeter.json 中 luxMeter_200009 / luxMeter_200008 把主语写成了泛化 device（"Device not connected." / "the device is not connected"），而对应 zh_CN 原文本身就是“设备未连接”，翻译是照中文直译，所以英文读起来是“设备”而不是“亮度计”。Electron 侧亮度计控制器对子系统返回的 msg 基本原样透传，最终在界面上呈现为英文措辞不准确。相机调节-粗调页面本身没有任何亮度计连接校验（只有一个相机连接校验），因此问题不在 CameraAdjust.vue 的页面逻辑，而在被复用的底层/共享错误文案。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | calibration-subsystem 的英文亮度计文案中确实存在“Device not connected”这类泛化主语表述，与工单“翻译对应的是设备未连接而非亮度计”完全对应。 | fact | `supported` |  |
| c2 | 中文源文案本身使用“设备未连接”（luxMeter_200009 / luxMeter_200008），说明英文是照中文直译而来，泛化来自源文案而非翻译时新增。 | fact | `supported` |  |
| c3 | Electron 侧亮度计控制器把子系统返回的 msg 原样返回渲染层（commonResponse.getError(res.msg \|\| ...)），因此子系统英文文案会未经改写地显示到界面。 | hypothesis | `conditional` | 该片段来自 CodeGraph 的当前源码返回，尚未用 Read 复核；需按定位结果复核后再改 |
| c4 | 相机调节-粗调页面自身没有亮度计连接校验，说明报错来源不在该页面，而在共享状态组件或后端透传文案。 | conclusion | `conditional` | 假设粗调期间未通过其他 hook（如自动曝光/参数分析）间接触发亮度计请求；粗调流程本身不发请求已核对 |
| c5 | 前端存在 CalibrationTool.boxConfig.deviceNotConnected.name = "Device not connected."，但其唯一使用点是箱体校正的 checkDeviceStatus（仅判屏幕与相机），与亮色度校正的相机调节页面无关。 | fact | `conditional` | 调用点来自 grep 结果；common.ts 中函数体已 Read 核对，调用方文件未逐个 Read |

## ④ 最终修改判断与验证

- **建议修改**：把“亮度计未连接”这类错误的英文主语由泛化的 device 明确为 luminance meter（必要时同步中文口径），不修改粗调业务逻辑，不改动已确认的界面行为。
- 步骤：
  1. 1. 先在英文界面复现并抓取粗调相机时该提示的完整英文原文，与仓库内候选字符串逐字比对，确定命中 luxMeter_200009、luxMeter_200008，还是前端通用 key。
  1. 2. 若命中子系统亮度计域：修改 calibration-subsystem/src/locale/en_US/luxMeter.json，将 200009 改为 “Failed to disconnect the luminance meter. The luminance meter is not connected.”，将 200008 改为 “Failed to get the capture channel because the luminance meter is not connected.”（保持 key、JSON 结构、逗号与格式不变）。
  1. 3. 按产品口径决定是否同步修改 zh_CN/luxMeter.json 的“设备未连接”为“亮度计未连接”，避免中英口径不一致；若产品只要求英文，则保持中文不动并在 MR 说明中记录该决策。
  1. 4. 若第 1 步证明是前端通用 key：不要复用 boxConfig.deviceNotConnected，新增/改用亮度计专属 key（在 en_US 与 zh_CN 成对新增），并在触发处替换。
  1. 5. 修改后校验两个 JSON 文件可被解析、key 集合不变（仅改 value），并确认没有其他语言目录复制了同一句 “Device not connected”。
- 目标文件：`calibration-subsystem/src/locale/en_US/luxMeter.json`, `calibration-subsystem/src/locale/zh_CN/luxMeter.json`, `calibrationtool/web/src/i18n/en_US/projectDetail.json`, `calibrationtool/web/src/i18n/zh_CN/projectDetail.json`, `calibrationtool/web/src/i18n/en_US/boxConfig.json`, `calibrationtool/web/src/i18n/zh_CN/boxConfig.json`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['在英文界面复现：进入亮色度校正 → 相机调节 → 点击“Camera Coarse Adjustment”，截取亮度计未连接提示的完整英文原文。', '用完整原文在两个仓库中逐字搜索，确认唯一命中文件与 key。', '若改动 calibration-subsystem/src/locale/en_US/luxMeter.json：校验 JSON 可解析、key 数量与中文文件一致、无残留 “Device not connected” 于亮度计域。', '若改到前端 i18n：分别校验 en_US 与 zh_CN（以及其它语言目录）key 成对存在，页面无中文/乱码，粗调流程与按钮状态不变；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`False` / loc@3：`False`
- outcome 相符：`True`
- 期望路径：`calibrationtool/web/src/i18n/en_US/`
- 首候选：`calibration-subsystem/src/locale/en_US/luxMeter.json`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
