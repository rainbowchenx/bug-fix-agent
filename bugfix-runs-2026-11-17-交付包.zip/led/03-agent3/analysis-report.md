# Repair report PJ01PD20251231223

tickets: 6

- BGCM2026051102234: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 切换手动配置后出现手动配置分区数入口
  cause: [Conditional / unverified] 分区配置页顶部手动/自动切换文案由 computed autoOrManual 从 i18n key `projectDetail.partitionConfig.switchToManual.name` 取词，该 key 的 zh_CN 值为「切换至手动配置分区模式」（配置在分区之前），与 UI 规范/英文资源表达的「手动分区配置模式」次序相反，导致按钮名称与 UI 不一致。功能侧（切换后出现“分区数”入口）本身已由 v-show="isManualConfig" 实现，非本次失败点。
  claim [supported]: 页面渲染的手动/自动切换文案来自 autoOrManual computed，按 isManualConfig 选择 switchToAuto / switchToManual 两个 i18n key。
  claim [supported]: 模板中该文案唯一输出点为 manual-config-row 内的 span{{ autoOrManual }}，并同时绑定点击事件 toggleManualConfig。
  claim [conditional]: zh_CN 该 key 的实际值为「切换至手动配置分区模式」，“分区/配置”的语序与 UI 规范要求的「手动分区配置模式」相反，是票面所报不一致的直接来源。
  claim [supported]: 切换后出现“手动配置分区数入口”的行为已实现：分区数表单项由 v-show="isManualConfig" 控制显示。
  claim [conditional]: en_US 同一 key 为 'Switch to manual partition configuration mode.'，语序对应“手动分区配置模式”，佐证中文应改为“手动分区配置”。
  claim [conditional]: 票面「问题」栏对 UI 值与客户端值的描述与标题/代码事实相反（代码中客户端值为“手动配置分区”），属票面笔误而非第二个缺陷。
  question [blocking]: 修复仅改一处字符串，但目标文案在票面内部冲突（标题/代码指向“手动分区配置模式”，问题栏却称客户端显示的是该值）。改错方向会让缺陷依旧被判不过，属直接影响修复目标的分歧。; need UI 设计稿截图或 UI 规范条目，明确权威文案为「切换至手动分区配置模式」还是「切换至手动配置分区模式」。
  question [choice]: en_US 文案是否同批调整（大小写/句尾句点统一）会影响 targetFiles 范围，但不影响中文修复机制。; need 是否将 en_US 同步纳入本次改动；若不纳入则中文单独修。
  remaining: 启动校正工具 → 全屏亮色度校正 → 进入分区配置页，确认顶部切换行文案与 UI 规范逐字一致。
  remaining: 点击切换行，确认切换为手动模式后“分区数”行列输入项出现（预期结果的行为回归）。
  remaining: 再次点击切回自动模式，确认文案切换为 switchToAuto 对应值且无残留。
  remaining: 对改动的 i18n JSON 执行 JSON 解析校验，并运行项目 lint（或 vue-tsc）确认无语法/类型问题。
- BGCM2026051103043: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 能输入成功，客户端显示正常
  cause: 分区拓扑预览的定位点不是 IPC/后端，而是 renderer 组件 partitionPreview.vue 的网格 CSS：预览容器 .partTopology 同时用了「固定高度语义」的 min-height:100% + width:max-content/min-width:100%，行轨与列轨又都用 minmax(80px,1fr)，再叠加外层 .partition-topology-preview 的 overflow:hidden。行/列数变大（手动模式允许 1–99）时，1fr 轨道在受父级确定性高度约束的网格里被压回父容器尺寸、网格盒子本身不随全部轨道增长，溢出部分被外层 overflow:hidden 裁掉，导致内层 .table-content 的 overflow:auto 滚动区算不到完整轨道范围——表现就是拖动横向/纵向滚动条仍显示不全。
  claim [supported]: 手动配置分区的行列输入上限是 99，因此常态会出现 99×99=9801 个分区格子。
  claim [unverified]: 分区预览把 localPartitionInfo.partitionCount 作为 previewPartitionCount 直接驱动网格 CSS 变量 --rows/--columns。
  claim [unverified]: .partTopology 的行轨与列轨均使用 minmax(80px, 1fr)，且网格盒子带 min-height:100% / width:max-content / min-width:100%，使网格盒子的高度由上层的确定性尺寸兜底而不是由全部轨道内容撑开。
  claim [conditional]: 内层滚动区 .table-content（overflow:auto，宽高 calc(100% - 16px)）是唯一可滚动容器，外层 .partition-topology-preview 设为 overflow:hidden，一旦网格盒子不增长，溢出轨道会落在滚动区之外被裁掉，滚动条无法到达最后一行/列。
  claim [supported]: 退出条件不是后端数据错误：分区数只影响渲染，手动模式不经过 autoGeneratePartition 即可显示预览，因此 IPC 透传与 calibration-subsystem 与本缺陷无因果。
  question [verification]: 需要确认是单轴还是双轴裁切，以决定是否只改 grid-template-rows 还是同时移除 width:max-content/min-width 组合。; need 在复现环境输入 40×40 后分别拖到底的截图/录屏（含横纵滚动条缩略位置）
  question [choice]: 外层 overflow:hidden 是否可改为 overflow:auto 属于交互/样式设计取舍：是保留外层裁切只修内层滚动区，还是允许外层承担滚动。; need 设计/UI 对预览区溢出行为的期望（裁切 vs 滚动）
  remaining: 静态检查：cd calibrationtool/web && npx vue-tsc --noEmit（仅确认改动未引入类型错误）
  remaining: 手工回归（必做）：LEDTool 校正工具 → 全屏亮色度校正 → 手动配置分区，分别输入 10×10、40×40、99×99，检查拓扑预览最后一行与最后一列可通过横纵滚动条完整到达，且分区名不互相压盖
  remaining: 回归非本单行为：自动配置分区模式下「自动生成分区」后的预览不受影响（同组件另一入口 previewPartitionCount 缺省走 store）
  remaining: 回归开始校正页 partitionPreview（isStartCalibration=true）分区切换点击命中正确格子
- BGCM2026051104084: plan_only
  analysis: completed; actionability: {'allowed': True, 'reason': ''}
  currentTarget: 画面显示回读颜色与实际一致
  cause: 画面显示的颜色回读只在 environmentInfoStore.getAllSendCardInfoByScreen() 里做，而该函数①在 screens.screen 为空时直接 return（新建工程/重开工具后该字段为空，EnvironmentPrep.onMounted 触发时被整段跳过）；②在 getAllSendCardInfoByScreen 接口返回非数组/空数组时 return null（同样跳过后续回读）；③真正回读时把设备返回的 LEDTestSignalType 用只含小写 red/green/blue/white 的 colorMap 映射，映射不到就把 cameraInfoStore.screenColor 写成 'NONE' 并落库。结果：回读要么不发生、要么落空，ColorRadioGroup 拿到的既不是设备自检真实颜色也不是合法的 R/G/B/W 选项值，页面表现为固定落在某个默认通道（实测为红色），而不是与实际一致。
  claim [supported]: 画面显示颜色回读的唯一触发点是 EnvironmentPrep.onMounted 中 fire-and-forget 调用 getAllSendCardInfoByScreen()，没有 await/catch。
  claim [conditional]: getAllSendCardInfoByScreen() 在 screens.screen 为空时直接 return，且在 getAllSendCardInfoByScreen 接口返回非数组/空数组时 return null，两条早退都发生在第 288 行颜色回读之前，因此重开工具/新建工程时回读根本不会执行。
  claim [supported]: 用户在下拉中选择屏幕只触发 useScreenList 的 watch → updateScreens/saveScreens，不会重新触发颜色回读，因此「选择屏幕之后」页面仍不会得到设备自检颜色。
  claim [conditional]: 回读映射 colorMap 只认小写 red/green/blue/white；设备/子系统写侧存在大写 'R'|'G'|'B' 以及 dotGrid/black/checkerboard/white 等取值，映射落空时第 303 行把 screenColor 置为 undefined、第 309-312 行以 'NONE' 落库，'NONE' 不是 ColorRadioGroup 的任一选项值。
  claim [conditional]: ColorRadioGroup 直接把 props.modelValue 塞进 el-radio-group，没有任何合法值归一化；当 modelValue 为 'NONE'/undefined 时组内无有效选项，UI 落到默认外观而非设备真实颜色。
  claim [conditional]: electron 侧 getTestSingleCfg 的 catch 分支缺 return（仅调用 commonResponse.getError），错误时 IPC 返回 undefined，渲染层拿到 undefined 后 res2.LEDTestSignalType 抛 TypeError，回读同样失效且无提示。
  question [verification]: 「红色」的确切来源决定修复是只需要补回读时机/映射，还是要处理设备重启后的自检色复位；需要一次现场日志确认 console.log('原始 LEDTestSignalType:', ...) 打印的值。; need 重开工具→新建工程→选屏幕→进入环境准备时的渲染层日志：'getTestSingleCfg 回读结果'、'原始 LEDTestSignalType' 两行
  question [verification]: 决定 colorMap 需要覆盖哪些取值，以及是否应保留原值而不是写 'NONE'。; need LEDTool /getTestSingleCfg 单次响应体（含 LEDTestSignalType、solidColorPercent 字段与类型）
  remaining: 1) 在 environmentInfo.ts 第 292/302 行日志下，复现「重开工具→新建工程→选屏幕→环境准备→画面显示」，确认 getTestSingleCfg 是否被调用、返回的 LEDTestSignalType 原值、mappedColor 是否为 undefined。
  remaining: 2) 在 ColorRadioGroup 里临时打印 props.modelValue，确认页面显示红色时 store 中 screenColor 是 'R'、'NONE' 还是 undefined。
  remaining: 3) 修复后验证：新建工程→选屏幕→把颜色设为蓝→关闭并重开工具→再次进入环境准备-画面显示，单选框应显示与实际屏幕自检颜色一致；再切到非纯色模式（dotGrid/black）验证不会误写成 'NONE' 覆盖用户设置。
  remaining: 4) 静态检查：web 侧 vue-tsc --noEmit / lint 覆盖改动文件；electron 侧 tsc --noEmit。
- BGCM2026051104842: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1. 区域定位步骤完成2. 红色采集步骤完成3. 绿色采集步骤完成4. 蓝色采集步骤完成5. 系数生成步骤完成6. 系数上传步骤完成7. 系数固化步骤完成
  cause: [Conditional / unverified] 「画面显示」当前颜色的唯一来源是设备回读链路 EnvironmentPrep.onMounted → environmentInfoStore.getAllSendCardInfoByScreen() → ProjectDetail_getTestSingleCfg → /getTestSingleCfg → colorMap[res2.LEDTestSignalType] → cameraInfoStore.screenColor。该链路有三处缺陷叠加，任一处失败都会让回读值不落库、界面仍显示 DB/默认颜色（当前代码默认 screenColor='G'，失败时还会被写成非法值 'NONE'）：(1) main 侧 getTestSingleCfg 不复核 ledToolPassThrough 的 success，失败时把 data:null 用 getResponse 包成 code 200 的“成功空数据”，且 catch 分支漏 return；(2) renderer 侧回读处无空值/异常保护，直接访问 this.data.sendCardList[0].ip 与 res2.LEDTestSignalType，抛错即中断整个 getAllSendCardInfoByScreen，回读值永不写入 cameraInfoStore；(3) EnvironmentPrep 在 onMounted 里 fire-and-forget 调用该 action，与 useScreenList 的屏幕拓扑加载（填充 sendCardList）并发且未 await/未 catch，拓扑未就绪时 sendCardList[0] 为 undefined。
  claim [conditional]: main 侧 getTestSingleCfg 不判断 ledToolPassThrough 返回的 success，失败时返回 commonResponse.getResponse(null)，被包装成 code=200 + data=null，回读失败对渲染层完全静默。
  claim [supported]: main 侧 getTestSingleCfg 的 catch 分支写成 commonResponse.getError(...) 而没有 return，异常路径返回 undefined，渲染层随后对 undefined 取 .code 会再次抛错。
  claim [supported]: renderer 侧回读处无任何存在性保护：先取 this.data.sendCardList[0].ip/port，再直接读 res2.LEDTestSignalType；sendCardList 为空或 res2 为 null 都会抛 TypeError，整个 getAllSendCardInfoByScreen 中断，cameraInfoStore.screenColor 不会被回读值覆盖。
  claim [conditional]: 映射失败时该 action 会把 screenColor 持久化为字符串 'NONE'（不是 R/G/B/W 任一合法单选项），ColorRadioGroup 因此无任何选中项，正是“未获取当前设备实际的画面显示颜色”的可见表现。
  claim [conditional]: EnvironmentPrep.onMounted 以 fire-and-forget 方式调用 getAllSendCardInfoByScreen()，同时 useScreenList 的 immediate watcher 异步调用 getScrrenLayout() 填充 sendCardList；两者无先后依赖保证，回读可能在 sendCardList 尚未就绪时执行。
  claim [conditional]: 回读失败后界面回落值来自 cameraInfoStore 的 DB 值或 DEFAULT_CAMERA_INFO.screenColor='G'，因此用户看到的是“与设备实际不符/无选中”的颜色，而非设备真实状态。
  claim [unverified]: 回读只采信 sendCardList[0] 一张发送卡，多发送卡屏幕的颜色聚合语义缺失。
  question [verification]: LEDTool 真实响应结构决定映射失败是否还有第三种成因，进而决定是否需要改 colorMap 而不是只改空值保护。; need 现场抓取 ProjectDetail_getTestSingleCfg 的 IPC 返回值（或 LEDTool /getTestSingleCfg 的 HTTP 响应体），确认字段名与取值集合。
  question [choice]: 多发送卡时“设备实际颜色”是取首卡、要求全卡一致、还是不一致时展示“未知”，会改变修复实现与验收口径。; need 确认被测型号 DS-DT60P-02HI06NO 的发送卡数量及测试环境的期望展示行为。
  question [verification]: 确认触发点究竟是竞态还是错误吞掉，决定修复是否必须调整调用时序（仅加空值保护可能仍复现）。; need 复现时检查 console 中 'getTestSingleCfg 回读结果:' 是否打印、以及是否存在 sendCardList 为空导致的 TypeError。
  remaining: 1) 静态检查：在 calibrationtool 下执行 `npx vue-tsc --noEmit`（或项目既有 typecheck 脚本），确认新增的空值保护无类型错误。
  remaining: 2) 单测/逻辑验证（若该仓库有测试）：对 getAllSendCardInfoByScreen 造三类输入（sendCardList 为空、getTestSingleCfg 返回 null、返回 {LEDTestSignalType:'green'}），断言不抛错且仅在合法颜色时写入 screenColor。
  remaining: 3) 实机复现：首次打开校正工具进入环境准备，观察 console 是否打印 'getTestSingleCfg 回读结果:' 与 '原始 LEDTestSignalType:'，并核对底栏「画面显示-屏幕颜色」是否与设备实际一致；再切屏、重开工具各验证一次。
  remaining: 4) 失败路径验证：令 LEDTool /getTestSingleCfg 不可用（或返回非 200），确认回读失败时给出明确提示且不再把 'NONE' 写库、界面不再静默显示默认色。
  remaining: 5) 上游业务链路回归：执行票面 7 个步骤（区域定位→采集 R/G/B→系数生成/上传/固化），确认颜色控制未被改动破坏。
- BGCM2026051201340: plan_only
  analysis: completed; actionability: {'allowed': True, 'reason': ''}
  currentTarget: 显示英文正常，界面无中文、乱码显示
  cause: [Conditional / unverified] 粗调相机阶段的提示文案本身已全部走 i18n（roughAdjustSegments 全部是 $lan 键，en_US 中 9 个 roughAdjustTip.* 键均存在且为英文），中文残留来自粗略调整 ComTip 内「操作说明」弹层引用的示意图资源：ComTip.vue 对 apertureAdjust.svg 无条件使用同一张（内嵌 base64 位图，无语义文本节点，即图内文字被“烧”进图片）的图片，而同页的 cameraPosition 却提供了 _cn/_en 两套资源，说明该资源缺少英文版本，英文界面下仍显示中文截图，即缺陷所述的“操作提示未翻译”。
  claim [supported]: 粗调提示条文案由 roughAdjustSegments 组成，9 个片段全部通过 $lan 关键字获取，不存在硬编码中文。
  claim [unverified]: en_US/projectDetail.json 已完整提供 cameraAdjust.roughAdjustTip.* 的英文译文，因此提示条在英文环境下应显示英文。
  claim [conditional]: 粗调进行中 addTipVisible 为 true，ComTip 渲染「操作说明」弹层，其中 apertureAdjust.svg 被无条件引用，而 cameraPosition 图按 _cn/_en 分语言切换，说明孔径示意图缺少英文版本。
  claim [supported]: apertureAdjust.svg 不含 <text>/<tspan> 语义文本，文字被栅格化为 base64 图片，无法通过 CSS/运行时切换语言。
  claim [conditional]: 相机精调提示在 updateCameraAdjustTip 中使用硬编码的中文全角标点「，」「；」「（」「）」，英文界面会出现中文标点；属同页面相邻步骤的附带问题，非本单「粗调相机」目标的直接成因。
  question [verification]: 需要确认实际出现中文的控件位置；若是「操作说明」弹层示意图，本单修复目标是新增英文本地化资源；若是提示条文字，则需改查运行时 locale 与 $lan 解析路径。; need 缺陷复现截图或视频，标明中文出现的具体控件（提示条 / 弹层缩略图）
  remaining: cd calibrationtool/web && npx vue-tsc --noEmit（或项目 lint）确认改动类型/语法无误
  remaining: 构建后切换语言为 en_US，进入 项目 → 相机调节 页面，点击 Camera Coarse Adjustment 进入粗调
  remaining: 观察顶部 ComTip 提示条：应为英文 1./2./3./4. 四步提示（对应 roughAdjustTip.*）
  remaining: 悬停『Operation Description』，确认弹层内光圈调节示意图为英文标注，无中文残留
  remaining: 回归 zh_CN：确认中文界面示意图仍为原 apertureAdjust.svg
- BGCM2026051201741: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 显示英文正常，界面无中文、乱码显示
  cause: [Conditional / unverified] 英文版出现的“Device not connected”并非页面自身拼装，而是亮度计（luxMeter）域的错误文案英文翻译丢掉了设备名：calibration-subsystem 的 en_US/luxMeter.json 中 luxMeter_200009 / luxMeter_200008 把主语写成了泛化 device（"Device not connected." / "the device is not connected"），而对应 zh_CN 原文本身就是“设备未连接”，翻译是照中文直译，所以英文读起来是“设备”而不是“亮度计”。Electron 侧亮度计控制器对子系统返回的 msg 基本原样透传，最终在界面上呈现为英文措辞不准确。相机调节-粗调页面本身没有任何亮度计连接校验（只有一个相机连接校验），因此问题不在 CameraAdjust.vue 的页面逻辑，而在被复用的底层/共享错误文案。
  claim [supported]: calibration-subsystem 的英文亮度计文案中确实存在“Device not connected”这类泛化主语表述，与工单“翻译对应的是设备未连接而非亮度计”完全对应。
  claim [supported]: 中文源文案本身使用“设备未连接”（luxMeter_200009 / luxMeter_200008），说明英文是照中文直译而来，泛化来自源文案而非翻译时新增。
  claim [conditional]: Electron 侧亮度计控制器把子系统返回的 msg 原样返回渲染层（commonResponse.getError(res.msg || ...)），因此子系统英文文案会未经改写地显示到界面。
  claim [conditional]: 相机调节-粗调页面自身没有亮度计连接校验，说明报错来源不在该页面，而在共享状态组件或后端透传文案。
  claim [conditional]: 前端存在 CalibrationTool.boxConfig.deviceNotConnected.name = "Device not connected."，但其唯一使用点是箱体校正的 checkDeviceStatus（仅判屏幕与相机），与亮色度校正的相机调节页面无关。
  question [verification]: 需要定位到实际弹窗文本，才能在子系统 i18n 与前端 i18n 之间确定唯一修复点；否则可能改错文件。; need 英文界面下粗调相机触发该提示的截图或完整英文原文（含是否带“Failed to disconnect / capture channel”等前后缀）。
  question [choice]: 若只改英文，中文仍写“设备未连接”，语义口径不统一，后续容易再次被判为翻译不准。; need 产品/测试确认：仅修英文，还是中英同时统一为“亮度计未连接 / Luminance meter not connected”。
  question [verification]: 若子系统按请求语言返回文案，需要确认粗调场景下确实取 en_US 资源，否则修复英文资源无效果。; need 子系统 locale 选择逻辑（路由/请求头/全局语言开关）与一次英文界面下的接口返回 msg 抓包结果。
  remaining: 在英文界面复现：进入亮色度校正 → 相机调节 → 点击“Camera Coarse Adjustment”，截取亮度计未连接提示的完整英文原文。
  remaining: 用完整原文在两个仓库中逐字搜索，确认唯一命中文件与 key。
  remaining: 若改动 calibration-subsystem/src/locale/en_US/luxMeter.json：校验 JSON 可解析、key 数量与中文文件一致、无残留 “Device not connected” 于亮度计域。
  remaining: 若改到前端 i18n：分别校验 en_US 与 zh_CN（以及其它语言目录）key 成对存在，页面无中文/乱码，粗调流程与按钮状态不变。
