# led（electron_node 双仓）Agent-3 批次评测报告

> 依据 `docs/field-eval/agent3/templates/batch-evaluation-report.md` 填写。
> 本批只到报告路径（`applyFix=false`）。运行日期 2026-11-17，全部重新生成。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 / 评测负责人 | runs-2026-11-17/led / 2026-11-17 / 运行者本人 |
| 项目类型及版本 / 每仓HEAD与dirty | electron_node（LED 校正）/ `bug-fix-demo-project/led`（calibration-subsystem + calibrationtool） |
| Agent3 commit / 模型 / SDK/CLI | 5c5c2f9 / EB-DeepSeek-Flash / claude-agent-sdk 0.2.182 |
| 运行模式 / 生效预算 / 并发及超时 | analyze_mode=sdk，applyFix=false，max_turns=24 |
| 原始资料 / Agent1/2产物 | 137 条 CSV（PJ01PD20251231223） |
| 选样方法 | 沿用 2026-11-16 的同样 6 票号 |
| **posture 变更** | **必须用 alpha**：137 票全部为 Closed/Delay/Cancel，beta 会 100% 排除（实测 excluded=137） |
| 重跑/中断 | Agent-2 **超时截断**：17 组只跑 4 组 |

## 2. 样本与验收覆盖

原始输入项：137；唯一缺陷：134（3 条 hard_reject）；重复关联：0；导入失败：0。

| 样本类别 | 数量 | 票ID |
|---|---|---|
| 清晰且当前仓可修 | 5 | 2234/3043/4084/4842/1340 |
| 模糊/缺图/缺日志 | 1 | 1741（needs_info） |
| 实际进行了二次执行 | 0 | 未做二轮 |

| 阶段 | 唯一票数 | 未继续的原因 |
|---|---|---|
| 收到输入 | 137 | — |
| 有明确报告去向 | 134 | 3 条 hard_reject |
| 曾生成候选 / 当前有效候选 | 130 / 130 | **但 6 票样本拿到完全相同的并列候选** |
| 已人工审阅候选 | 6 | — |
| 已尝试应用 / 完整应用成功 | N/A | applyFix=false |
| 已业务验收 | N/A | 未做 |
| 已执行相关回归验收 | N/A | 未做 |

## 3. 质量指标

| 指标 | n/N | 结果或范围 | 限制 |
|---|---|---|---|
| 报告覆盖 | 6/6 | 全部 plan_only | — |
| 候选产出 / 当前有效候选 | 6/6 / 6/6 | 全部有候选 | 但 Agent-2 候选全是同一路径 |
| 已核查票中的严重事实错误 | 0/6 | Agent-3 纠正了 Agent-2 的错误候选 | — |
| 补丁完整可应用 | N/A | 报告路径 | — |
| 原样接受 | N/A | 未验收 | — |
| 验收覆盖 | 0/6 | — | — |
| 阻断正确且补充请求有效 | N/A | 无阻断票 | — |
| 二次执行取得可核实进展 | N/A | 未做 | — |

## 4. 成本

| 成本项 | 有记录样本数 | 总量 | 中位数 | 范围/异常案例 |
|---|---|---|---|---|
| Agent运行分钟 | 6 | ~40 分钟 | ~6.7 分钟/票 | — |
| Token / 费用 | 4 组 | Agent-2 **$27.24**（但只覆盖 32/131 票） | — | 第1组 $11.25 触顶 max_turns |
| 人工审阅 | 6 | 待填 | — | — |

是否估算：Agent-3 费用估算；**预算触顶：Agent-2 因 1800 秒超时中止，17 组只跑 4 组**。

## 5. 逐票结果

| 缺陷 | 首次→最终结果 | 验收状态 | 主要问题来源 | 证据/详情 |
|---|---|---|---|---|
| BGCM2026051102234 | plan_only | 待验收 | Agent2（并列假候选） | loc@1=❌ `i18n/zh_CN/projectDetail.json`；真值 `PartitionConfig.vue` |
| BGCM2026051103043 | plan_only | 待验收 | Agent2（并列假候选） | loc@1=✅ `partitionPreview.vue` |
| BGCM2026051104084 | plan_only | 待验收 | — | loc@1=✅ `environmentInfo.ts` |
| BGCM2026051104842 | plan_only | 待验收 | — | loc@1=❌ `electron/controller/projectDetail/index.ts`；loc@3=✅ |
| BGCM2026051201340 | plan_only | 待验收 | — | loc@1=❌ `ComTip.vue`；loc@3=✅ |
| BGCM2026051201741 | plan_only | 待验收 | — | loc@3WithAlt=✅ `calibration-subsystem/src/locale/en_US/luxMeter.json` |

## 6. 代表案例

### 成功案例：BGCM2026051103043（拓扑预览分区显示不全）

Agent-2 给的是并列假候选（6 票全是 `electron/electron/controller/camera/index.ts`）。Agent-3 独立定位到 `calibrationtool/web/src/views/config/components/partitionPreview.vue`，与真值完全一致——正是"拓扑预览"组件。

为何有效：Agent-3 没有继承 Agent-2 的错误候选，而是按缺陷描述（"拓扑预览中的分区显示不全"）重新 grep。可复用：当 Agent-2 多票候选高度重复时（并列假命中），Agent-3 必须完全独立重新定位。

### 失败或回归案例：BGCM2026051102234（分区配置按钮名称）

Agent-3 给 `calibrationtool/web/src/i18n/zh_CN/projectDetail.json`，真值为 `PartitionConfig.vue`。缺陷是"切换至手动配置分区模式按钮名称与UI不一致"，Agent-3 判断为 i18n 文案问题，但实际是按钮文本定义位置。属于**判断偏差**而非幻觉（文件存在且相关）。

### 二次修复案例：本批未做

## 7. 环节归因与改进

| 环节 | 有证据的问题及票ID | 影响 | 优先级 | 建议与验证办法 |
|---|---|---|---|---|
| 原始资料 | CSV 137 票全为非 Open 状态，beta posture 完全无法使用 | 必须切 alpha | 中 | Agent-1 的 posture 说明需澄清"历史缺陷批"场景 |
| Agent1 | 无（alpha 下 134/137 有效） | — | — | — |
| Agent2 | ① **超时静默截断**：`BUGFIX_INVESTIGATION_TIMEOUT_SECONDS=1800` 导致 17 组只跑 4 组，99 票 not_investigated；② **6 票并列假候选**（同一路径）；③ run.log 完全没有记录超时中止 | Agent-2 对 led 基本失效 | **高** | ① 超时/组数中止必须写入产物与日志；② `_shared_signatures` 识别到并列假命中时应删除候选，不只降 confidence；③ 提供 `BUGFIX_INVESTIGATION_MAX_GROUPS` 显式控制 |
| Agent3分析 | 3 票 loc@1 未命中（但 loc@3 命中 2 票） | 可接受 | 中 | — |
| Agent3编辑 | N/A | — | — | — |
| 验证/交付 | 未做人工验收 | — | — | 后续按模板 |
| 环境/外部依赖 | electron_node 双仓（calibrationtool + calibration-subsystem），路径前缀长 | 增加定位难度 | 低 | — |

## 8. 结论

- **G0 = PASS**。
- **loc@1 = 2/6，loc@3 = 5/6，withAlternatives = 6/6**：首候选命中率低，但前三候选与备选答案覆盖 6/6。
- **outcome = 6/6**。
- **verdict = usable_pending_g3**。

**本批最重要的发现（Agent-2 缺陷）**：

1. **超时静默截断**：`investigation.py:100-101` 的 `time.monotonic() - started >= seconds` 触发 `break`，17 组只跑 4 组，99/131 票 `not_investigated`。**run.log 里完全没有超时记录**，事后无法从产物判断是"模型没找到"还是"根本没跑"。

2. **并列假候选**：6 票样本全部拿到 `electron/electron/controller/camera/index.ts` 同一候选。`_shared_signatures()` 能识别这种情况，但只用于降低 confidence，**不删除候选**，导致 Agent-3 收到污染输入。

**Agent-3 表现**：在 Agent-2 输入质量极差（99 票未调查、6 票假候选）的前提下，仍达到 loc@3 = 5/6、withAlt = 6/6，说明其独立定位能力可靠。
