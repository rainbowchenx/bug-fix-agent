# runs-2026-11-17 交付包说明

三 Agent 缺陷分析工作流（Agent-1 → Agent-2 → Agent-3）在 4 个真实产品线上的运行与评测产物。
运行日期 2026-11-17，架构 commit 5c5c2f9。**Agent-3 只出报告（applyFix=false 全程生效，无一处改码）。**

**本批全部重新生成，未复用 2026-11-16 的任何产物。**

## 顶层

- `最终结果报告.md` — 四仓总览、与昨天对比、8 项关键发现。**从这里看起。**
- `<产品线>/` — peitao（报警 device_web）/ transport（交通 device_web）/ hcp（3.2 微前端）/ led（校正 electron 双仓）

## 每仓目录与要求对应关系

| 目录/文件 | 内容 | 对应要求 |
|---|---|---|
| `00-原始工单/` | 原始工单 CSV（已脱敏） | ① 信息丢失检查的**数据源** |
| `01-agent1/` | preflight.txt + defect-batch.json（全量）+ defect-batch-6.json（6 票） | ① Agent-1 条目 |
| `02-agent2/` | code-knowledge.json（候选与调查理由）+ run.log | ② Agent-2 分析 |
| `03-agent3/` | analysis-report.json（六票正式报告）+ cases.json（真值）+ score.json（评测）+ defects/（逐票 attempt 明细） | ④ 修改判断的数据源 |
| `ticket-dossiers/<缺陷ID>/` | 逐票五段式档案（①原始工单对照 ②Agent-2 线索 ③Claude 过程 ④修改判断） | ①②③④ |
| `ticket-review-summary.csv` | 54 列逐票评分表 | 评测汇总 |
| `batch-evaluation-report.md` | 按模板填写的批次报告（含环节归因与改进建议） | 评测报告 |

## 评测结果汇总

| 产品线 | G0 | loc@1 | loc@3 | withAlt | outcome | verdict |
|---|---|---|---|---|---|---|
| peitao | PASS | 6/6 | 6/6 | 6/6 | 6/6 | usable_pending_g3 |
| transport | PASS | 3/6 | 3/6 | 3/6 | 4/6 | mixed |
| hcp | PASS | 6/6 | 6/6 | 6/6 | 6/6 | usable_pending_g3 |
| led | PASS | 2/6 | 5/6 | 6/6 | 6/6 | usable_pending_g3 |
| **合计** | **4/4 PASS** | **17/24** | **20/24** | **21/24** | **22/24** | — |

## 数据脱敏

人员标识字段（当前处理人 / 处理人姓名 / 提交人 / 解决人 / 发现人等）**全部保留**，仅把真实姓名与工号替换为可读代称 `USER_A`、`USER_B` … `USER_BX`：

- 同一真人在全包内映射到同一代称，跨票对照关系仍可追踪
- 多人字段保持逗号分隔形式
- 缺陷单号、标题、步骤、期望等业务内容原样保留，不影响信息丢失检查
- 运行机路径用户名替换为 `USER_OP`
- 扫描核验：全包 0 处真实人员标识残留

## 已知限制

- Agent-3 未做人工验收，`repair.successRate = null`，所有票「待验收」
- G3（人工根因评分）未做
- led 的 Agent-2 因超时只覆盖 32/131 票（24%）
- 未做二轮反馈注入（⑤ 二轮修复案例）
