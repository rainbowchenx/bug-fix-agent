# hcp（micro_frontend）Agent-3 批次评测报告

> 依据 `docs/field-eval/agent3/templates/batch-evaluation-report.md` 填写。
> 本批只到报告路径（`applyFix=false`）。运行日期 2026-11-17，全部重新生成。

## 1. 范围与配置

| 字段 | 填写 |
|---|---|
| 批次ID / 日期 / 评测负责人 | runs-2026-11-17/hcp / 2026-11-17 / 运行者本人 |
| 项目类型及版本 / 每仓HEAD与dirty | micro_frontend（hcp 3.2）/ `bug-fix-demo-project/hcp/hcp` |
| Agent3 commit / 模型 / SDK/CLI | 5c5c2f9 / EB-DeepSeek-Flash / claude-agent-sdk 0.2.182 |
| 运行模式 / 生效预算 / 并发及超时 | analyze_mode=sdk，applyFix=false，max_turns=24，四仓并行 |
| 业务skill及版本 / 可用环境 | 包内置 SOP；CodeGraph 索引 11032 文件已就绪 |
| 原始资料 / Agent1/2产物 / 产出目录 | 26+11 两份 CSV（PJ14PD20260509167）合并 37 条 |
| 选样方法 | 沿用 2026-11-16 的同样 6 票号；全部 strict |
| 重跑/中断/临时修改 | Agent-2 分 **5 组（8+8+8+8+5）全部 completed** —— 本次核心验证点 |

## 2. 样本与验收覆盖

原始输入项：26+11=37；唯一缺陷：37（0 重复）；导入失败：0。

| 样本类别 | 数量 | 票ID |
|---|---|---|
| 清晰且当前仓可修 | 6 | 见逐票表 |
| 环境依赖 | 0 | — |
| 实际进行了二次执行 | 0 | 未做二轮 |

| 阶段 | 唯一票数 | 未继续的原因 |
|---|---|---|
| 收到输入 | 37 | — |
| 有明确报告去向 | 37 | — |
| 曾生成候选 / 当前有效候选 | 12 / 12 | 25 票空候选 |
| 已人工审阅候选 | 6 | — |
| 已尝试应用 / 完整应用成功 | N/A | applyFix=false |
| 已业务验收 | N/A | 未做 |
| 已执行相关回归验收 | N/A | 未做 |

## 3. 质量指标

| 指标 | n/N | 结果或范围 | 限制 |
|---|---|---|---|
| 报告覆盖 | 6/6 | 全部 plan_only | — |
| 候选产出 / 当前有效候选 | 6/6 / 6/6 | 全部有候选 | — |
| 已核查票中的严重事实错误 | 0/6 | 无路径不存在、无幻觉文件名 | — |
| 补丁完整可应用 | N/A | 报告路径 | — |
| 原样接受 | N/A | 未验收 | — |
| 验收覆盖 | 0/6 | — | — |
| 阻断正确且补充请求有效 | N/A | 无阻断票 | — |
| 二次执行取得可核实进展 | N/A | 未做 | — |

**拒绝候选数量、原因及待验收票：** 全部 6 票待验收。

## 4. 成本

| 成本项 | 有记录样本数 | 总量 | 中位数 | 范围/异常案例 |
|---|---|---|---|---|
| Agent运行分钟 | 6 | ~35 分钟 | ~5.8 分钟/票 | — |
| Token / 费用 | 5 组 | Agent-2 **$20.00**（昨天 $13.19 但只覆盖 16/37 票） | — | 单组最高 $5.93 |
| 人工审阅 | 6 | 待填 | — | — |

是否估算：Agent-3 费用估算；预算触顶：6/6 报 max_turns（分析均 completed）。

## 5. 逐票结果

| 缺陷 | 首次→最终结果 | 验收状态 | 主要问题来源 | 证据/详情 |
|---|---|---|---|---|
| BGCM2026110302952 | plan_only | 待验收 | — | loc@1=✅ `Resource/components/sadp_detection/` |
| BGCM2026110303610 | plan_only | 待验收 | — | loc@1=✅ `Resource/components/DeviceBasicInfo.vue:2154-2157`（onvif 提示按钮引导） |
| BGCM2026110304123 | plan_only | 待验收 | — | loc@1=✅ `Resource/view/encoder/HotSpare.vue:294`（注释明确"添加热备下发协议期间显示"） |
| BGCM2026110304635 | plan_only | 待验收 | — | loc@1=✅ `Resource/components/remoteConfig/LinkageConfigForm.vue:471`（`v-loading`） |
| BGCM2026110304762 | plan_only | 待验收 | — | loc@1=✅ `Resource/view/access/AccessList.vue:336-339`（刷新按钮 `:loading`） |
| BGCM2026110303220 | plan_only | 待验收 | — | loc@1=✅ `Resource/components/sadp_detection/` |

## 6. 代表案例

### 成功案例：BGCM2026110304123（热备图标改 loading）

原始票：`[WEB基础组] 添加热备提示图标改成 loading`。

上游输入：Agent-2 在这一票**无候选**（conf=low, gap=no_path_token_overlap）。

Agent-3 机制证据：独立 grep 后定位到 `src/Resource/view/encoder/HotSpare.vue`，第 294 行注释写明「轻量 loading 提示实例（添加热备下发协议期间显示，协议返回后关闭）」，第 616 行「展示轻量 loading 提示（参考编码设备列表太阳能唤醒）」。与缺陷描述完全对应。

为何有效：Agent-2 只看路径名（`distribution/clusterManage/` 里有 hotStandbyInfo.vue 但那是集群热备），Agent-3 读代码后找到了真正的"添加热备协议下发"链路。可复用：空候选票必须由 Agent-3 独立 grep，不能依赖目录名猜测。

### 失败或回归案例：无

### 二次修复案例：本批未做

## 7. 环节归因与改进

| 环节 | 有证据的问题及票ID | 影响 | 优先级 | 建议与验证办法 |
|---|---|---|---|---|
| 原始资料 | 无 | — | — | — |
| Agent1 | 无（37/37 字段完整） | — | — | — |
| Agent2 | ① 25/37 空候选（68%）；② 全 37 票 `investigationStatus=partial`（facts/searchedScopes 为空） | 候选率低，但本次 Agent-3 仍全部定位成功 | 中 | ① 检查 prompt 是否要求模型填 facts；② 评估 partial 判定是否过严 |
| Agent3分析 | 6/6 报 max_turns | 分析 completed，但 evidence 收集受限 | 中 | 评估提高 max_turns |
| Agent3编辑 | N/A | — | — | — |
| 验证/交付 | 未做人工验收 | — | — | 后续按模板 |
| 环境/外部依赖 | CodeGraph 索引 11032 文件、657MB db，`status` 调用约 3.5s | 可接受 | 低 | — |

## 8. 结论

- **G0 = PASS**。
- **loc@1 = 6/6，loc@3 = 6/6**（真值经二次 grep 复核修正后）。
- **outcome = 6/6**。
- **verdict = usable_pending_g3**。

**本批两项核心验证**：

1. **16 票上限已解除**：昨天 hcp 因 `MAX_PROMPT_TICKETS=16` 导致 21/37 票 `not_investigated`；本次 `investigate_groups()` 分 5 组共 339 turns，**37/37 票全部调查**，费用从 $13.19 增至 $20.00。

2. **真值定义需按代码内容而非目录名**：首轮评测 loc@1 仅 2/6，逐条 grep 后发现是我的真值错了 4 处。Agent-3 给出的 `HotSpare.vue`、`LinkageConfigForm.vue`、`AccessList.vue`、`DeviceBasicInfo.vue` 全部真实存在且含对应缺陷代码，比按目录名猜的 `distribution/`、`Maintenance/` 更精确。昨天报告称"2 票真值前缀过窄"，实际是 4 票都错。
