# BGCM2026110304762 [WEB基础组(正式批)] 门禁设备列表刷新按钮置灰后图标还是高亮的

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [WEB基础组(正式批)] 门禁设备列表刷新按钮置灰后图标还是高亮的 | [WEB基础组(正式批)] 门禁设备列表刷新按钮置灰后图标还是高亮的 | 否 |
| 测试模块 | WEB基础组(正式批) | WEB基础组(正式批) | 否 |
| 前置条件 | 具备门禁设备管理权限 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1.进入门禁设备管理2.查看设备列表3.查看在线状态/类型 | 1.进入门禁设备管理2.查看设备列表3.查看在线状态/类型 | 否 |
| 测试数据 | 门禁设备已接入 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 门禁设备列表正确展示(明眸/一体机/道闸/门禁主机) | 门禁设备列表正确展示(明眸/一体机/道闸/门禁主机) | 否 |
| 实际结果 | 门禁设备列表刷新按钮置灰后图标还是高亮的 | 门禁设备列表刷新按钮置灰后图标还是高亮的 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：门禁设备列表加载前置条件：具备门禁设备管理权限操作步骤：1.进入门禁设备管理2.查看设备列表3.查看在线状态/类型测试数据：门禁设备已接入预期结果：门禁设备列表正确展示(明眸/一体机/道闸/门禁主机)实际结果：门禁设备列表刷新按钮置灰后图标还是高亮的问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`low`
- 分析说明：微前端读序已遵循：缺陷 testModule=WEB基础组，按 playbook 先定位到 Resource 微应用（src/Resource），再由 DeviceListActionBar 追到共享组件与共享主题（src/Common），src/Common 不作为微应用处理。上游给出的 defectCodeMatches 为空、softStart 无候选，本轮定位完全由 CodeGraph + 直接读文件完成。图查询返回的大量 BI/DisplayDms/Map 命中与门禁无关，已排除。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`0d18cedb-b8bf-481b-af85-77ac37b92d55`
- attemptId：`d3c7fafa50a5`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：门禁设备列表正确展示(明眸/一体机/道闸/门禁主机)
- **代码关联**：src/Resource/view/access/AccessList.vue; src/Resource/components/DeviceRefreshPopover.vue; src/Resource/components/DeviceListActionBar.vue; src/Common/libs/hui-intl/index.css; src/Common/assets/less/theme/hcp/reset.less; src/Resource/common/less/deviceList.less
- **机制**：[Conditional / unverified] 门禁设备列表的刷新入口是图标型 el-button（icon='icomoon-common_btn_refresh'），其禁用态只有按钮容器级的通用样式（如 .el-button.is-disabled{opacity:.4}），而共享主题 hui-intl 里按类型区分的禁用色规则使用 :not(.is-icon) 显式排除了图标按钮，且缺少『禁用按钮内 i 图标改色为 --c-ic-dis』的对应规则（该规则仅存在于 .el-input-number__increase/.el-decrease），Repository 主题 reset.less 也只写了 iconButton 的 hover/active 而未写禁用态。因此按钮本体进入 is-disabled 后图标字形颜色未被重置，视觉上仍为高亮。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 门禁设备列表为 src/Resource/view/access/AccessList.vue（Access.vue 只是 keep-alive 壳）。 | fact | `supported` |  |
| C2 | 操作列刷新按钮是 icon-only 的 el-button（icon=icomoon-common_btn_refresh），禁用条件为 ProtocolTypeCategory===3，另有 :loading 与刷新中行联动。 | fact | `supported` |  |
| C3 | 工具栏『刷新』按钮由 DeviceRefreshPopover 渲染，其禁用只依赖 props.disabled，而 DeviceListActionBar 渲染 refresh-popover 时未传 disabled（默认 false）。 | fact | `conditional` | 未在本轮逐行核对 DeviceListActionBar 之外的调用方是否传 disabled |
| C4 | 共享主题对图标按钮的禁用态缺少图标置灰规则：文本禁用色规则限定 .el-button.is-disabled.el-button--default:not(.is-icon)，而 .is-disabled i{color:var(--c-ic-dis)} 只出现在 .el-input-number 上下调整按钮上。 | hypothesis | `conditional` | 该 minified 主题文件为单行，grep 只取到局部片段，未排除其它行/其它选择器组合覆盖图标色; 未在浏览器中确认生效规则；若通用 .el-button.is-disabled{opacity:.4} 已足以让图标同等变淡，则本假设不成立 |
| C5 | 仓库主题 src/Common/assets/less/theme/hcp/reset.less 对 .el-button--iconButton 只定义 hover/active:not(.is-disabled)，没有定义禁用态图标颜色，属于同一处样式缺口。 | fact | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：在共享主题补齐『禁用按钮内图标同色置灰』规则（优先对齐 hui-intl 中 .el-input-number 的写法），使 icon-only 按钮的 i 字形在 is-disabled 时使用 --c-ic-dis；若确认是工具栏按钮则将同样的禁用态图标色一并覆盖。不改动预期结果（列表正确展示明眸/一体机/道闸/门禁主机）。
- 步骤：
  1. 1. 先按 Q1 确认置灰按钮归属（行内刷新 vs 工具栏刷新），只在对应位置上修复，避免全局误伤其它模块。
  1. 2. 首选方案：在项目主题层（src/Common/assets/less/theme/hcp/reset.less，与现有 .el-button--iconButton.is-icon:hover/active:not(.is-disabled) 相邻）追加禁用态规则，例如 .el-button.is-icon.is-disabled i { color: var(--c-ic-dis) }，必要时 дополнить .el-button.is-disabled i。
  1. 3. 若确认问题仅出现在门禁列表且不希望影响全局：退化为在 src/Resource/common/less/deviceList.less 的 .operation-column 或 AccessList.vue scoped 样式内做局部覆盖。
  1. 4. 顺手核对 DeviceListActionBar 未向 refresh-popover 传递 disabled 是否属于本缺陷成因之一（若产品要求无选中时置灰，则应补 :disabled），但不要把该补充行为当作本缺陷的修复前提。
  1. 5. 验证：门禁设备列表中存在 ProtocolTypeCategory===3（禁用刷新）的行时，刷新图标与按钮文字/背景同步变灰；同时抽查 VideoIntercomList / TicketBoxList / VisitorTerminalList 等同样使用该图标按钮的列表，确认样式一致。
- 目标文件：`src/Common/assets/less/theme/hcp/reset.less`, `src/Resource/common/less/deviceList.less`, `src/Resource/view/access/AccessList.vue`, `src/Resource/components/DeviceRefreshPopover.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['启动 portal 前端，进入 门禁设备管理 → 设备列表，构造一条 ProtocolTypeCategory===3 的门禁设备（刷新按钮为禁用态）。', 'DevTools 选中该刷新按钮的 <i class="icomoon-common_btn_refresh">，记录 computed color 与命中规则，确认是否已应用 --c-ic-dis。', '若修复落在 reset.less/deviceList.less：对比修复前后按钮与图标颜色是否同步变灰，并抽查 VideoIntercomList.vue、TicketBoxList.vue、VisitorTerminalLi；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Resource/view/access/AccessList.vue`
- 首候选：`src/Resource/view/access/AccessList.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
