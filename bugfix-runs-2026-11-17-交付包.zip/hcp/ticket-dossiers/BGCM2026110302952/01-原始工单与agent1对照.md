# BGCM2026110302952 [WEB基础组(正式批)] 在线设备发现未设置邮箱二维码中文案按钮刷新溢出

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [WEB基础组(正式批)] 在线设备发现未设置邮箱二维码中文案按钮刷新溢出 | [WEB基础组(正式批)] 在线设备发现未设置邮箱二维码中文案按钮刷新溢出 | 否 |
| 测试模块 | WEB基础组(正式批) | WEB基础组(正式批) | 否 |
| 前置条件 | 1.用户已登录平台2.已进入服务器网络在线设备发现页面3.存在1台支持在线发现且支持配置密保的未激活设备 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1.勾选1台未激活在线设备2.点击激活按钮3.在激活面板输入8-16位密码并再次确认密码4.点击激活5.激活成功后自动弹出设置密保对话框6.在用户名输入框输入admin7.设置密码、邮箱地址及密保答案并点击保存 | 1.勾选1台未激活在线设备2.点击激活按钮3.在激活面板输入8-16位密码并再次确认密码4.点击激活5.激活成功后自动弹出设置密保对话框6.在用户名输入框输入admin7.设置密码、邮箱地址及密保答案并点击保存 | 否 |
| 测试数据 | 1台在线设备；密码Hcp@123456；用户名admin；邮箱test@hikvision.com | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 1.设置密保对话框显示用户名输入框2.用户名输入生效并提交服务端成功3.结果对话框显示设置成功4.关闭后在线设备列表刷新 | 1.设置密保对话框显示用户名输入框2.用户名输入生效并提交服务端成功3.结果对话框显示设置成功4.关闭后在线设备列表刷新 | 否 |
| 实际结果 | 在线设备发现未设置邮箱二维码中文案按钮刷新溢出 | 在线设备发现未设置邮箱二维码中文案按钮刷新溢出 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：服务器网络在线设备激活后设置密保支持输入用户名保存成功前置条件：1.用户已登录平台2.已进入服务器网络在线设备发现页面3.存在1台支持在线发现且支持配置密保的未激活设备操作步骤：1.勾选1台未激活在线设备2.点击激活按钮3.在激活面板输入8-16位密码并再次确认密码4.点击激活5.激活成功后自动弹出设置密保对话框6.在用户名输入框输入admin7.设置密码、邮箱地址及密保答案并点击保存测试数据：1台在线设备；密码Hcp@123456；用户名admin；邮箱test@hikvision.com预期结果：1.设置密保对话框显示用户名输入框2.用户名输入生效并提交服务端成功3.结果对话框显示设置成功4.关闭后在线设备列表刷新实际结果：在线设备发现未设置邮箱二维码中文案按钮刷新溢出问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`low`
- 分析说明：定位依据：matchGap 为 no_path_token_overlap，softStartLocalization 为空，因此按 micro_frontend 读序从 src/Resource（在线设备发现所在微应用）入手；通过 codegraph_explore 命中 SetPasswordProtectionDialog 与 reset-password-dialog，再 Grep『二维码』『hcp_devrsc_get_qr_code/mail_reset_pwd_step1』收敛到唯一文件 reset-password-dialog.vue。该文件中『二维码』相关代码 100% 集中在此，未见第二个候选文件。所有路径均已用 Read 打开确认。注意：溢出属渲染行为，静态代码只能给出可信的机制与修复点，无法证明像素级越界量。附带发现（非本缺陷因果、仅提示）：SetPasswordProtectionDialog.vue:509 也使用了同样的 `.el-dialog__wrapper` scoped 写法，存在同源失效风险。; analyze=sdk; partial=tru
- sessionId：`84856837-4648-4293-9c2d-06035aed2d2a`
- attemptId：`eb568026a629`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1.设置密保对话框显示用户名输入框2.用户名输入生效并提交服务端成功3.结果对话框显示设置成功4.关闭后在线设备列表刷新
- **代码关联**：src/Resource/components/sadp_detection/reset-password-dialog.vue; src/Resource/i18n/zh_CN/hcpLang_msg.json; src/Resource/i18n/en/hcpLang_msg.json
- **机制**：[Conditional / unverified] i18n + 固定像素布局耦合：在线设备发现「重置密码 → 邮箱重置」面板（reset-password-dialog.vue）在「未设置邮箱」态下渲染的是固定 100x100 占位块 + 行内 min/max-width 按钮 + 未填充 {0} 的中文步骤文案；这些模板里写死的是 px 宽高而不是自适应宽度，中文文案（hcp_devrsc_mail_reset_pwd_step1 / hcp_devrsc_load_failed / refresh / hcp_devrsc_get_qr_code）比英文长，且弹窗 scoped 样式的作用域写法与 hui el-dialog 的实际 DOM 结构不匹配，缺少 body 的宽度/换行约束，于是中文文案与按钮在弹窗内横向溢出。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | 邮箱重置面板在未设置邮箱态下用固定 100x100 的 div 承载「加载失败 / 刷新」中文文案与按钮，宽高写死，中文比英文长时容易在 100px 内挤压或撑出容器。 | hypothesis | `conditional` | 实际布局效果需浏览器实测（当前未运行页面）; 缺陷描述中的「按钮刷新」指该占位块内的 refresh 链接 |
| c2 | 步骤文案 `$t('hcp_devrsc_mail_reset_pwd_step1').replace('{0}', QrCodeMail)` 在 QrCodeMail 为空串时渲染成「…并将其发送至 」的截断句，是「未设置邮箱」态下的文案缺陷（i18n 未覆盖该状态）。 | fact | `conditional` | QrCodeMail 的初值为 '' 且失败分支只清空 QrCodeImage 不清空文案占位 |
| c3 | 该面板的 scoped 样式挂在 `.el-dialog__wrapper` 祖先下再 :deep 到 `.set-password-dialog .el-dialog__body-wrapper` 去限制高度/滚动，但该祖先选择器是否命中取决于 hui el-dialog 的真实 DOM（弹窗通常挂到 body），未命中时 body 无宽度/溢出约束。 | hypothesis | `unverified` | 未读取 hui el-dialog 组件源码确认 DOM 结构 |
| c4 | 「获取二维码」按钮用 :min-width=105 / :max-width=480 这类行内属性控制宽度，中文按钮文案较英文长，且外层 flex 容器未设置 min-width:0 / width:100%，flex 子项默认不收缩，易把内容顶出弹窗。 | hypothesis | `conditional` | min-width/max-width 由 hui el-button 映射为样式而非文字截断 |
| c5 | 本缺陷是文案国际化长度差异暴露的布局健壮性问题，而不是服务端数据/接口缺陷：模板中所有相关元素都在 reset-password-dialog.vue 的邮箱重置块内。 | conclusion | `conditional` | 缺陷标题中的「二维码中文案按钮刷新」均指该面板 |

## ④ 最终修改判断与验证

- **建议修改**：在 reset-password-dialog.vue 的邮箱重置块内去除硬编码像素尺寸、给 flex 容器加 min-width:0/width:100% 与中文换行（word-break/line-height）约束，并让被 .el-dialog__body-wrapper 包裹的样式选择器真实生效；同时为「未设置邮箱」态补一条完整文案（不依赖空 QrCodeMail 拼接）。
- 步骤：
  1. 1) 把 94 行 flex 容器的行内样式收敛成一个类（如 .mail-reset-block），设置 width:100%; min-width:0; 文本 word-break:break-word; white-space:normal;
  1. 2) 96-105 行的「获取二维码」按钮去掉 :min-width/:max-width 行内约束，改由容器宽度与按钮默认样式决定；如需固定宽，改用对齐项目的统一按钮宽度变量。
  1. 3) 113-129 行的加载失败占位块把 width/height:100px 改成按内容自适应（min-width:100px; padding; height:auto），并给「加载失败」「刷新」允许换行；二维码 img 保持 100x100。
  1. 4) 95/131 行步骤文案改为：当 QrCodeMail 为空时使用专门的「未设置邮箱」文案 key，避免渲染成「发送至 」截断句；若产品要求，则补 zh_CN/en 两套 key。
  1. 5) 819-856 行 scoped 样式去掉不起作用的 .el-dialog__wrapper 祖先，直接 :deep(.set-password-dialog) .el-dialog__body-wrapper 做高度与 overflow-y:auto / overflow-x:hidden 约束；必要时给内容区一个统一 padding-right 避免右侧贴边被裁。
  1. 6) 回归：分别在中英文下验证「已设置邮箱 / 未设置邮箱 / 二维码加载失败」三态，弹窗不出现横向滚动、按钮不越界；确认不影响 SetPasswordProtectionDialog 复用样式。
- 目标文件：`src/Resource/components/sadp_detection/reset-password-dialog.vue`, `src/Resource/i18n/zh_CN/hcpLang_msg.json`, `src/Resource/i18n/en/hcpLang_msg.json`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['在 10.33.43.25 环境进入 服务器网络 → 在线设备发现，选中 1 台未激活且支持在线发现的设备，打开『重置设备密码』并将方式切到『邮箱重置』。', '构造未设置邮箱的设备（服务端不返回 ServerMailboxAddr），分别在中/英文下打开该面板。', 'DevTools 中检查 `.set-password-dialog .el-dialog__body-wrapper` 的 scrollWidth 与 clientWidth、以及 100x100 占位块内 span 的 offsetWidth，确认越界元素。', '改后回归三态：已设置邮箱、未设置邮箱、二维码加载失败；；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Resource/components/sadp_detection/`
- 首候选：`src/Resource/components/sadp_detection/reset-password-dialog.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
