# BGCM2026110304123 [WEB基础组(正式批)] 添加热备提示图标改成loading

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [WEB基础组(正式批)] 添加热备提示图标改成loading | [WEB基础组(正式批)] 添加热备提示图标改成loading | 否 |
| 测试模块 | WEB基础组(正式批) | WEB基础组(正式批) | 否 |
| 前置条件 | 存在主备两台编码设备 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1.进入编码设备-热备2.创建热备组3.配置主/备设备4.保存并验证 | 1.进入编码设备-热备2.创建热备组3.配置主/备设备4.保存并验证 | 否 |
| 测试数据 | 两台设备互联在线 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 热备组创建成功，主设备故障时切换备用 | 热备组创建成功，主设备故障时切换备用 | 否 |
| 实际结果 | 添加热备提示图标改成loading | 添加热备提示图标改成loading | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：热备设备配置与切换前置条件：存在主备两台编码设备操作步骤：1.进入编码设备-热备2.创建热备组3.配置主/备设备4.保存并验证测试数据：两台设备互联在线预期结果：热备组创建成功，主设备故障时切换备用实际结果：添加热备提示图标改成loading问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/Resource/view/resourceAppManagement/components/loading.vue` | exact basename "loading" from title/titleTag/testModule/intent | grep |
| `src/DownloadCenter/view/components/Downloading.vue` | basename contains "loading" from title/titleTag/testModule/intent | grep |
| `src/Intruder/view/subsystem/FaultLoading.vue` | basename contains "loading" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：微前端 read order 校验：testModule「WEB基础组」对应 src/Resource 微应用；router/index.js 中 /resource/encoder/hot-spare → HotSpare.vue（src/Resource/router/index.js:552-556），从 EncoderList.toHotSparePage 进入，链路闭合。已排除 resourceAppManagement/loading.vue 等软启动 basename 误命中。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`122d46ef-6178-40ea-ba3e-8df2551d72cf`
- attemptId：`906a3f13a5a0`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：热备组创建成功，主设备故障时切换备用
- **代码关联**：src/Resource/view/encoder/HotSpare.vue; node_modules/hui-intl/src/components/message/src/main.vue; node_modules/hui-intl/src/components/message/src/main.js
- **机制**：编码设备「热备」页添加热备组时，下发协议期间的提示走的是 hui-intl 的 Message 组件且 type 固定为 'info'，而 Message 组件的图标映射表只包含 success/info/warning/error 四个静态反馈图标（无 loading 类型），因此提示条渲染的是静态 info 图标而非旋转 loading 图标；测试要求把该提示图标改成 loading。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 热备页「添加」按钮 → HotSpareForm 校验通过后 emit('save') → HotSpare.addHotSpare：先弹确认框，确认后调用 showMessageLoading() 再调 hotSpareAPI.addHotSpare | fact | `supported` |  |
| C2 | showMessageLoading() 调用 Message({ message, type: 'info', duration: 0, showClose: false })，因此提示条渲染的是 info 类型的静态 feedback 图标，没有 loading 动画 | fact | `supported` |  |
| C3 | hui-intl 的 Message 组件 main.vue 中 typeMap 仅有 success/info/warning/error 四项，图标由 `h-icon-feedback_*_md` 给出；不存在 loading 类型，因此仅改 type 无法得到 loading 图标 | fact | `supported` |  |
| C4 | Message 支持以 VNode 作为内容（main.js 检测 isVNode 后写入 vnodemessage，main.vue 用 `<component :is="vnodemessage" />` 渲染），因此可在提示内容里放 el-load-icon / h-an-icon-loading 动画图标而不改组件库 | conclusion | `supported` |  |
| C5 | el-load-icon（ElLoadIcon）在本仓各微应用中被直接使用且无局部 import（如 src/Broadcast/components/realTimeBroadcast/PlayDialog.vue:16、src/BI/view/components/export/exportingFileDialog.vue:12），说明其由 hui/hui-intl 插件全局注册，可直接在 VNode 中引用 | hypothesis | `conditional` |  |
| C6 | 提示关闭时机在三条回调（success / errorResponse / error）与 beforeUnmount 兜底中均已覆盖，改为 loading 图标不改变关闭时机，无需改动请求层 | fact | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：在 HotSpare.vue 的 showMessageLoading() 中，把 Message 的纯文本内容替换为包含动画 loading 图标（el-load-icon，即 h-an-icon-loading 四条斜线动画）的 VNode/小型展示组件，保持常驻（duration:0）与原有文案 hcp_devrsc_hot_spare_adding，不改动请求与关闭时机。
- 步骤：
  1. 在 src/Resource/view/encoder/HotSpare.vue 新增一个极小的提示内容组件（可内联对象组件或独立 HotSpareAddingTip.vue）：模板为 `<span class="hot-spare-adding"><el-load-icon class="hot-spare-adding__icon" /><span>{{ $t('hcp_devrsc_hot_spare_adding') }}</span></span>`，样式控制图标 16px、与文字间距 8px
  1. showMessageLoading() 改为 `const { h } = require('vue')` 等价的 `import { h } from 'vue'`，调用 `this.messageInstance = Message({ message: h(HotSpareAddingTip), type: 'info', duration: 0, showClose: false })`，利用 Message 的 vnode 内容渲染能力（hui-intl message/src/main.js isVNode 分支）
  1. 确认 el-load-icon 全局可用；若该微应用未注册，则回退为手写 `<span class="el-loading-icon h-an-icon-loading"><span class="path1"/>…` 结构（hui-intl index.css 已提供动画样式，TVWall largeScreenControl.js:7635 已有相同写法可参照）
  1. 保持 closeMessageLoading() 与 beforeUnmount 兜底逻辑不变，验证 success / errorResponse(含 99999 错误列表分支) / error 三条路径都能关闭提示
  1. 验证：进入编码设备-热备 → 添加 → 选择备机/主机 → 确认后提示条显示旋转 loading 图标 + 文案；协议返回后提示消失、列表刷新
- 目标文件：`src/Resource/view/encoder/HotSpare.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['手工回归：编码设备 → 热备 → 添加，填完备机/主机后确认，观察提示条图标是否为旋转 loading、文案为「正在添加热备，请稍候...」', '异常路径回归：构造 addHotSpare 返回 99999 + NVRErrorList，确认提示条关闭且失败详情弹窗正常；网络错误路径同样确认提示关闭', '中途离开页面（beforeUnmount）确认提示不残留（右上角不再有常驻 Message）', '静态检查：对改动文件跑 eslint / vue-tsc（若存在）']；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Resource/view/encoder/HotSpare.vue`
- 首候选：`src/Resource/view/encoder/HotSpare.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
