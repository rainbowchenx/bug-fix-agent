# BGCM2026110303220 [WEB基础组(正式批)] 本地发现问答重置问题未翻译，本地发现和服务器网络都有问题

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [WEB基础组(正式批)] 本地发现问答重置问题未翻译，本地发现和服务器网络都有问题 | [WEB基础组(正式批)] 本地发现问答重置问题未翻译，本地发现和服务器网络都有问题 | 否 |
| 测试模块 | WEB基础组(正式批) | WEB基础组(正式批) | 否 |
| 前置条件 | 1.用户已登录平台2.平台已安装并连上SADP本地控件3.局域网内有1台待发现的在线编码设备 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1. 进入本地网络发现页面2. 点击开始发现按钮启动SADP服务3. 待控件上报设备列表 | 1. 进入本地网络发现页面2. 点击开始发现按钮启动SADP服务3. 待控件上报设备列表 | 否 |
| 测试数据 | 1台在线编码设备，设备序列号SN-0001 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示 | 1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示 | 否 |
| 实际结果 | 本地发现问答重置问题未翻译 | 本地发现问答重置问题未翻译 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：本地网络正常发现设备列表数据前置条件：1.用户已登录平台2.平台已安装并连上SADP本地控件3.局域网内有1台待发现的在线编码设备操作步骤：1. 进入本地网络发现页面2. 点击开始发现按钮启动SADP服务3. 待控件上报设备列表测试数据：1台在线编码设备，设备序列号SN-0001 预期结果：1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示实际结果：本地发现问答重置问题未翻译问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`low`
- gap：`no_path_token_overlap`
- 候选：**空**（Agent-2 未定位到路径）

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`low`
- 分析说明：CodeGraph 首查命中的是 Map 的 marker.translate.ts（无关同名符号）；真实落点通过 sadp_detection 目录 + ResetPasswordDialog 引用定位。Resource 的 i18n 目录只有 en/zh_CN 两套 json，无独立 js 加载器，模块语言在 src/Resource/vue.app.js 中通过 addModuleLanguage('Resource', [...]) 注册。en 语言包中 hcp_devrsc_sadp_protocol、hcp_devrsc_apply_loading 为空串（属对照证据，不代表本缺陷因果）。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`8a2f44cd-9c81-47c3-a5a2-680926c6b6b4`
- attemptId：`b1819a39beb2`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示
- **代码关联**：src/Resource/components/sadp_detection/reset-password-dialog.vue; src/Resource/components/sadp_detection/sadp-operation.vue; src/Resource/i18n/en/hcpLang_name.json; src/Resource/i18n/en/hcpLang_msg.json
- **机制**：[Conditional / unverified] 缺陷报告的实际结果是“本地发现问答重置问题未翻译”，标题补充“本地发现和服务器网络都有问题”。本地发现与服务器发现的复位密码入口共用同一组件 src/Resource/components/sadp_detection/reset-password-dialog.vue（sadp-operation.vue 无论 isServerNetwork 真假都渲染该 Dialog），其“问答重置”区块靠 i18n key 拼装显示：题目正文走 questionOptions + getQuestionText 映射 hcp_devrsc_security_question_${n}，标签走 $t('hcp_devrsc_question_' + (i+1)) / $t('hcp_devrsc_answer_' + (i+1))。Resource 语言包只为 hcp_devrsc_security_question_1..15 与 hcp_devrsc_question_1..3 / hcp_devrsc_answer_1..3 提供了翻译；一旦设备（本地控件 arrayQuestion 或服务端 SecurityQuestionList）回传的 QuestionID 在 1..15 之外、类型不匹配（dwId 为字符串而 questionOptions.value 为 number，getQuestionText 用了严格 ===），或题目条目数超过 3，$t 就会按 Common/i18n/index.js 的兜底逻辑原样返回 key（或 getQuestionText 返回空串），页面呈现即为“未翻译/空白”。因此缺陷落在该共享弹框的问答渲染与语言包 key 覆盖上，而不是设备发现列表本身。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | 本地发现与服务器发现的复位密码弹框是同一个组件，因此两侧出现同一现象符合“本地发现和服务器网络都有问题”的描述。 | fact | `supported` |  |
| c2 | 问答区块的题目正文由 getQuestionText 通过严格相等匹配 questionOptions（value 为数字 1..15）得到，匹配失败返回空串，即“未翻译/空白”。 | hypothesis | `conditional` | 控件回传 dwId 与 questionOptions.value 类型不一致，或 dwId 超出 1..15 |
| c3 | 问答区块的标签 key 只覆盖 hcp_devrsc_question_1..3 / hcp_devrsc_answer_1..3；当 SecurityQuestionList 长度大于 3 时 $t 会原样返回 key，页面显示未翻译的 key 字符串。 | hypothesis | `conditional` | 设备配置的安全问题数量多于 3 条 |
| c4 | i18n 兜底逻辑在找不到 key 时返回 key 本身（而非空），因此“未翻译”在 UI 上的主要形态是直接展示 hcp_devrsc_* 原始 key。 | fact | `unverified` |  |
| c5 | 本地发现页存在真实的空翻译条目（如 en 语言包 hcp_devrsc_sadp_protocol 值为空串、hcp_devrsc_apply_loading 值为空串），属于同一 i18n 缺陷簇，但不是本缺陷 observed 所述“问答重置问题”的直接因果点。 | fact | `unverified` | 空串值在 commonI18n 中按“已找到”返回空字符串，从而呈现为空白 |

## ④ 最终修改判断与验证

- **建议修改**：在 reset-password-dialog.vue 收敛问答文案来源：题目正文与标签统一由 questionOptions 按 QuestionID 归一化（Number() 转换 + 1..15 范围校验）后取同一套 key，避免严格相等失配；对超出已定义 key 范围的情况提供兜底文案而不是暴露原始 key；并按需补齐语言包缺失项。
- 步骤：
  1. 1) 在 reset-password-dialog.vue 的 getQuestionText 中把 qa.QuestionID 归一化为 Number 再与 questionOptions.value 比较，匹配失败时回退到 hcp_devrsc_security_question_1 或显式兜底文案，禁止返回空串。
  1. 2) 把模板中的 $t('hcp_devrsc_question_' + (i + 1)) / $t('hcp_devrsc_answer_' + (i + 1)) 改为不依赖条目序号的稳定 key（例如复用 hcp_devrsc_security_question_ 系列或固定 hcp_devrsc_question_1/answer_1），确保条目数变化时不出现原始 key。
  1. 3) 校对 src/Resource/i18n/en、zh_CN 下 hcpLang_name.json / hcpLang_msg.json 中与本次链路相关的空值条目（hcp_devrsc_sadp_protocol、hcp_devrsc_apply_loading 等）作为附带清理，但不得以此替代问答渲染的修复。
  1. 4) 用英文环境在本地网络发现与服务器网络分别打开“重置密码 → 问答重置”，确认题目正文、问题标签、回答标签均为英文且无 hcp_devrsc_* 原样 key。
- 目标文件：`src/Resource/components/sadp_detection/reset-password-dialog.vue`, `src/Resource/i18n/en/hcpLang_name.json`, `src/Resource/i18n/en/hcpLang_msg.json`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['静态核对：确认 reset-password-dialog.vue 中 getQuestionText 的严格相等与 questionOptions.value 的类型约定，并列出 Resource 语言包里实际存在的 hcp_devrsc_question_N / hcp_devrsc_answer_N / hcp_devrsc_security_question_N 全部 key。', '运行态：在英文环境进入本地网络发现页，对一台支持问答重置的在线设备点击重置密码，切到“Reset by Security Question”，记录题目正文与标签的实际渲染文本。', '对照：切到服务器；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Resource/components/sadp_detection/`
- 首候选：`src/Resource/components/sadp_detection/reset-password-dialog.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
