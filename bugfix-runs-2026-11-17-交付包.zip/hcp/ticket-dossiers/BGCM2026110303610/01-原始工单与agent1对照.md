# BGCM2026110303610 [WEB基础组(正式批)] 点击开启onvif按钮，应该跳转到onvif页面

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [WEB基础组(正式批)] 点击开启onvif按钮，应该跳转到onvif页面 | [WEB基础组(正式批)] 点击开启onvif按钮，应该跳转到onvif页面 | 否 |
| 测试模块 | WEB基础组(正式批) | WEB基础组(正式批) | 否 |
| 前置条件 | 存在ISUP接入编码设备 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1.进入编码设备-添加2.选择ISUP协议3.输入设备ID(或设备ID段)4.保存 | 1.进入编码设备-添加2.选择ISUP协议3.输入设备ID(或设备ID段)4.保存 | 否 |
| 测试数据 | ISUP设备ID正确 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 设备添加成功，ISUP接入显示正常 | 设备添加成功，ISUP接入显示正常 | 否 |
| 实际结果 | 点击开启onvif按钮，应该跳转到onvif页面 | 点击开启onvif按钮，应该跳转到onvif页面 | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：通过ISUP协议添加编码设备前置条件：存在ISUP接入编码设备操作步骤：1.进入编码设备-添加2.选择ISUP协议3.输入设备ID(或设备ID段)4.保存测试数据：ISUP设备ID正确预期结果：设备添加成功，ISUP接入显示正常实际结果：点击开启onvif按钮，应该跳转到onvif页面问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/Resource/view/resource/camera/onvifStreamOptions.vue` | basename contains "onvif" from title/titleTag/testModule/intent | grep |
| `src/Integration/view/gateWay/onvif/constants.js` | package/dir "onvif" from title/titleTag/testModule/intent | grep |
| `src/Integration/view/gateWay/onvif/components/OnvifUserForm.vue` | basename contains "onvif" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：已通过 CodeGraph 确认路由注册与页面存在性，并用 Read 复核 DeviceBasicInfo / EncoderAdd / deviceAccessControl / onvifGateway 的相关片段。architectureMap 指向的 Integration ONVIF 页本身无缺陷；缺陷位于 Resource 微应用复用的 DeviceBasicInfo 组件。isShowOnvifProtocolTips 与 EncoderAdd.changeProtocol→judgeOnvif 的细节仅来自 grep，未逐行 Read，故 c4 标为 conditional。; analyze=sdk; partial=true; reason=max_turns
- sessionId：`f56ede06-b409-470a-8cd8-07a52836d16f`
- attemptId：`6021a4579793`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：设备添加成功，ISUP接入显示正常
- **代码关联**：src/Resource/components/DeviceBasicInfo.vue; src/Resource/view/encoder/EncoderAdd.vue; src/System/view/deviceAccessControl/deviceAccessControl.vue; src/Integration/view/gateWay/onvif/onvifGateway.vue
- **机制**：[Conditional / unverified] 编码设备添加页（src/Resource/components/DeviceBasicInfo.vue）中『接入协议』下方的 ONVIF 开启引导链接是从紧邻的 HPP 区块复制而来的，点击处理仍然指向 Hik-Partner Pro 站点接入页 `system_HikProConnectSites`，因此用户点击『开启 ONVIF』引导按钮时打开的是 HPP 站点页面而不是 ONVIF 配置页面。同时该链接的显示条件 `isShowOnvifProtocolTips` 复用了通用的 `disabledProtocolTip`（ISUP 未开启时也会被赋值），导致在 ISUP 协议添加流程里也出现这个 ONVIF 引导按钮，与用例实际观察场景吻合。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| c1 | ONVIF 引导链接的点击目标是 `system_HikProConnectSites`（HPP 站点接入页），而非任何 ONVIF 配置页。 | conclusion | `conditional` | 渲染条件 isShowOnvifProtocolTips && !isClient 成立时用户可见并可点击 |
| c2 | 该 ONVIF 区块与其下方的 HPP 区块（第 90-94 行）使用完全相同的 `toRouterJump('system_HikProConnectSites')` 与相同文案 key，属复制粘贴遗留。 | fact | `supported` |  |
| c3 | 提示文案 hcp_devrsc_disable_onvif_tip 指向『到系统配置启用』，与该链接实际跳转的 HPP 站点页语义不符。 | fact | `conditional` | i18n 文案与代码同源，未做运行时校验 |
| c4 | EncoderAdd.initProtocolList 中 `disabledProtocolTip` 在 ISUP 未开启时也会被赋值，而 isShowOnvifProtocolTips 只判断 `disabledProtocolTip && !IsSupportOnvif`，且 IsSupportOnvif 仅在 SDK/ONVIF 协议下由 judgeOnvif 刷新，因此 ISUP 添加流程中可能错误展示 ONVIF 引导按钮。 | hypothesis | `conditional` | IsSupportOnvif 初始为 false 且 ISUP 协议切换不会调用 judgeOnvif（该段为 grep 证据，未逐行 Read changeProtocol） |
| c5 | 修复后可选目标页面之一为 System『设备接入协议配置』页，其存在『接入ONVIF协议』(label_enable_onvif) 开关，路由 name 为 DeviceAccessControl。 | fact | `supported` |  |
| c6 | 另一可选目标为三方集成 ONVIF 网关页，页面标题取 hcp_integration_onvif_gateway，路由 name 为 OnvifGateway。 | fact | `supported` |  |

## ④ 最终修改判断与验证

- **建议修改**：把 ONVIF 引导链接的跳转目标从 HPP 站点页改为 ONVIF 配置页，并把显示条件从通用 disabledProtocolTip 解耦为『ONVIF 明确未启用』，避免 ISUP 流程误显示。
- 步骤：
  1. 1) 在 src/Resource/components/DeviceBasicInfo.vue 第 69-74 行，将 ONVIF 区块的 @click 由 toRouterJump('system_HikProConnectSites') 改为 ONVIF 目标路由名（按 q1 结论二选一：System 设备接入协议配置用 'system_DeviceAccessControl'；Integration ONVIF 网关用 'integration_OnvifGateway'，pathNameRule 中亦可用 path '/integration/onvifGateway'）。
  1. 2) 同一处文案 key 由通用的 hcp_show_hik_connect_tip 换成 ONVIF 语义文案（可复用 Resource 已有 hcp_devrsc_disable_onvif_tip 或新增『去开启』类 key），避免 ONVIF 引导按钮显示为 HPP 文案。
  1. 3) 将 isShowOnvifProtocolTips 的判定改为显式的 ONVIF 未启用标志（例如由 EncoderAdd 传入新 prop onvifDisabled，仅在 !supportOnvif 时置 true），不再复用 disabledProtocolTip，防止 ISUP 未开启场景下误显示 ONVIF 引导按钮。
  1. 4) 若 (3) 采纳，同步在 EncoderAdd.initProtocolList（第 1008-1032 行）维护该新标志，并保持 disabledProtocolTip 仅用于提示文案，不改动文案内容与多协议冲突时的既有覆盖顺序。
  1. 5) 不改动 Integration 侧路由与 onvifGateway.vue 页面逻辑——路由与页面均已存在且正确。
- 目标文件：`src/Resource/components/DeviceBasicInfo.vue`, `src/Resource/view/encoder/EncoderAdd.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：["静态核对：src/Resource/components/DeviceBasicInfo.vue 中 ONVIF 区块不再出现 'system_HikProConnectSites'，且 HPP 区块仍保留该跳转未受影响。", '静态核对：isShowOnvifProtocolTips 不再直接依赖 disabledProtocolTip，EncoderAdd 传入的 ONVIF 未启用标志在 !supportOnvif 时才为 true。', '手工回归：编码设备-添加，选择海康SDK/IP段且 ONVIF 未启用 → 点击引导按钮 → 落到约定的 ONVIF 配置页并可看到 ONVIF；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Resource/components/DeviceBasicInfo.vue`
- 首候选：`src/Resource/components/DeviceBasicInfo.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
