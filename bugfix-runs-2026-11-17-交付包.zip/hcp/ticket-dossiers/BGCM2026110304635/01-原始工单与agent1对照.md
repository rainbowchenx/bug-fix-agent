# BGCM2026110304635 [WEB基础组(正式批)] 门禁设备联动配置页面按钮建议增加loading

## ① 原始工单 vs Agent-1 条目（信息丢失检查）

| 字段 | 原始工单（sourceDocument） | Agent-1 defect-batch | 是否丢失 |
|---|---|---|---|
| 标题 | [WEB基础组(正式批)] 门禁设备联动配置页面按钮建议增加loading | [WEB基础组(正式批)] 门禁设备联动配置页面按钮建议增加loading | 否 |
| 测试模块 | WEB基础组(正式批) | WEB基础组(正式批) | 否 |
| 前置条件 | 门禁设备在线 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 操作步骤 | 1.进入门禁设备列表2.选择设备点击远程配置3.跳转设备配置界面 | 1.进入门禁设备列表2.选择设备点击远程配置3.跳转设备配置界面 | 否 |
| 测试数据 | 平台可连接设备 | —（Agent-1 无对应字段） | **是（Agent-1 无字段）** |
| 预期结果 | 远程配置跳转成功，可进入设备设置 | 远程配置跳转成功，可进入设备设置 | 否 |
| 实际结果 | 门禁设备联动配置页面按钮建议增加loading | 门禁设备联动配置页面按钮建议增加loading | 否 |
| 严重级别 | 低 | 低 | 否 |
| 缺陷状态 | Open | Open | 否 |

原始缺陷描述全文：

```text
用例名称：门禁设备远程配置跳转前置条件：门禁设备在线操作步骤：1.进入门禁设备列表2.选择设备点击远程配置3.跳转设备配置界面测试数据：平台可连接设备预期结果：远程配置跳转成功，可进入设备设置实际结果：门禁设备联动配置页面按钮建议增加loading问题：1.2.初步定位：无。建议：1.2.如其他项目或产品中存同样缺陷，请说明
```

- 池判定：`strict`
- 期望质量：`explicit`

## ② Agent-2 分析线索（含注入 skill）

- investigationStatus：`partial`
- confidence：`medium`

| 候选路径 | 理由 | 来源 |
|---|---|---|
| `src/Resource/view/resourceAppManagement/components/loading.vue` | exact basename "loading" from title/titleTag/testModule/intent | grep |
| `src/DownloadCenter/view/components/Downloading.vue` | basename contains "loading" from title/titleTag/testModule/intent | grep |
| `src/Intruder/view/subsystem/FaultLoading.vue` | basename contains "loading" from title/titleTag/testModule/intent | grep |

## ③ Claude Code 实际过程

- outcome：`plan_only`
- analysisStatus：`completed`
- confidence：`medium`
- 分析说明：链路：远程配置页 RemoteConfig.vue:596 内嵌 <linkage-config> → LinkageConfig.vue 列表与增删 → 路由跳转 accessLinkageConfigForm / elevatorLinkageConfigForm（src/Resource/router/index.js:681/796）→ LinkageConfigForm.vue 表单保存。软启动给出的 3 个 loading 同名文件（resourceAppManagement/components/loading.vue 等）与本缺陷无关，已排除。; analyze=sdk
- sessionId：`4a1544d0-d5ce-4a11-8134-2dd04f0b5159`
- attemptId：`ddeff6774ec8`
- execution：`completed` / resolution：`analysis_only`

### 机制主张（editDecision）

- **目标行为**：远程配置跳转成功，可进入设备设置
- **代码关联**：src/Resource/components/remoteConfig/LinkageConfigForm.vue; src/Resource/components/remoteConfig/LinkageConfig.vue; src/Common/http/hcp/isapi.js; src/Resource/components/remoteConfig/RemoteConfig.vue
- **机制**：[Conditional / unverified] 联动配置相关页面的写操作按钮（表单页『保存』、列表区『删除全部』/行内『删除』）都没有 loading 绑定：模板上未使用 el-button 的 :loading，脚本内也没有 submitLoading/deleting 之类的状态位。保存走 deviceAPI.setLinkageConfig（ISAPI PUT，最长 2 分钟超时），仅在 success 回调里提示并返回，失败时无任何复位；删除走 $confirm 后调 deviceAPI.deleteLinkageConfig，请求期间同样无反馈。公共 http 层已明确不再展示全局 loading（isapi.js showLoading 默认 false 且相关代码被注释），因此设备响应慢时按钮无任何进行中反馈，并可被重复点击触发重复下发。缺陷描述『按钮建议增加loading』即指此处缺失的按钮级 loading 状态。

### 根因主张（claims）

| claimId | 主张 | 角色 | 状态 | 假设 |
|---|---|---|---|---|
| C1 | 联动配置表单页（路由 accessLinkageConfigForm / elevatorLinkageConfigForm）的『保存』按钮未绑定任何 loading 属性，点击即触发 onSave。 | fact | `supported` |  |
| C2 | 保存请求 deviceAPI.setLinkageConfig 只有 success 回调，没有 complete/error 分支，失败路径下按钮无状态可复位，请求期间也无进行中反馈。 | fact | `supported` |  |
| C3 | 联动配置列表区（内嵌在远程配置页）的『删除全部』与行内『删除』按钮无 loading/禁用态；删除请求在 $confirm 之后发出，请求期间仍可再次点击。 | fact | `supported` |  |
| C4 | 公共 http 层不提供全局 loading 兜底，故按钮自身是唯一可见反馈来源。 | fact | `supported` |  |
| C5 | 同目录既有约定做法是组件内维护 submitLoading 并绑定到主操作按钮（RemoteConfig.vue:1019/1977/2027-2042），本次缺失属于未遵循既有约定。 | conclusion | `conditional` | 以 RemoteConfig.vue 的 submitLoading 作为该目录的编码约定基线 |
| C6 | 设备在线但响应慢时，无 loading 会导致重复点击重复下发联动配置（重复条目或并发写冲突）。 | hypothesis | `unverified` | ISAPI 对并发 PUT 不去重; 设备侧写入耗时足以覆盖用户双击间隔 |

## ④ 最终修改判断与验证

- **建议修改**：为联动配置相关写操作按钮补齐组件内 loading 状态（沿用同目录 RemoteConfig.vue 的 submitLoading 约定）：表单页保存按钮绑定 submitLoading 并以 complete 复位；列表区删除按钮绑定删除 loading 并在请求结束后复位，同时用 loading 隐含禁用避免重复点击。
- 步骤：
  1. 1. src/Resource/components/remoteConfig/LinkageConfigForm.vue：data 增加 submitLoading: false。
  1. 2. 同文件第 573 行保存按钮改为 <el-button type="primary" :loading="submitLoading" @click="onSave()">，保持 $t('btn_save') 文案不变。
  1. 3. onSave() 通过校验后、发起 deviceAPI.setLinkageConfig 前置 submitLoading = true；进入请求前若 submitLoading 为 true 直接 return（防重入）。
  1. 4. setLinkageConfig 回调补 complete: () => { this.submitLoading = false; }（success 内保留 message 与 this.back()；失败时依赖 complete 复位，避免按钮卡死）。
  1. 5. src/Resource/components/remoteConfig/LinkageConfig.vue：data 增加 deleteLoading: false（如需行级反馈可加 deletingIndex: null）。
  1. 6. deleteAll / 行内删除按钮绑定 :loading="deleteLoading"（行级则用 :loading="deletingIndex === scope.row.linkageIndex"），deleteLinkageConfig 进入请求前置位、在 deleteLinkageConfig 的 complete 中复位；『删除全部』保留原有 tableData.length === 0 的 disabled 条件。
  1. 7. 不修改 toAddPage/toEditPage（纯路由跳转，无需 loading），不改动远程配置主页面既有 submitLoading 逻辑。
- 目标文件：`src/Resource/components/remoteConfig/LinkageConfigForm.vue`, `src/Resource/components/remoteConfig/LinkageConfig.vue`
- applyFix：`False`（报告路径，未改码）
- 建议验证：['静态检查：npx eslint src/Resource/components/remoteConfig/LinkageConfigForm.vue src/Resource/components/remoteConfig/LinkageConfig.vue', '手动验证 A（保存）：设备列表 → 在线门禁设备 → 远程配置 → 联动配置 → 添加 → 保存；用慢响应/断网模拟，确认保存按钮出现 loading 且期间不可再次提交，失败后 loading 复位、按钮可再次点击。', '手动验证 B（删除）：联动配置列表删除单条与『删除全部』，确认按钮进入 loading、请求结束后复位，；executed=`False`

### 评测结果

- G0：`PASS` 
- loc@1：`True` / loc@3：`True`
- outcome 相符：`True`
- 期望路径：`src/Resource/components/remoteConfig/LinkageConfigForm.vue`
- 首候选：`src/Resource/components/remoteConfig/LinkageConfigForm.vue`

### 人工复核

- 待填写：需对候选路径做 `grep` 确认是否指向缺陷机制（已验证 / 部分验证 / 无法评估）

## ⑤ 用户补充后的二轮修复

- 本批未做二轮反馈注入（按交付范围只到五段式前四段 + 评测）。
