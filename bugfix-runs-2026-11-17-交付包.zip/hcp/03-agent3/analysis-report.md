# Repair report PJ14PD20260509167

tickets: 6

- BGCM2026110302952: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1.设置密保对话框显示用户名输入框2.用户名输入生效并提交服务端成功3.结果对话框显示设置成功4.关闭后在线设备列表刷新
  cause: [Conditional / unverified] i18n + 固定像素布局耦合：在线设备发现「重置密码 → 邮箱重置」面板（reset-password-dialog.vue）在「未设置邮箱」态下渲染的是固定 100x100 占位块 + 行内 min/max-width 按钮 + 未填充 {0} 的中文步骤文案；这些模板里写死的是 px 宽高而不是自适应宽度，中文文案（hcp_devrsc_mail_reset_pwd_step1 / hcp_devrsc_load_failed / refresh / hcp_devrsc_get_qr_code）比英文长，且弹窗 scoped 样式的作用域写法与 hui el-dialog 的实际 DOM 结构不匹配，缺少 body 的宽度/换行约束，于是中文文案与按钮在弹窗内横向溢出。
  claim [conditional]: 邮箱重置面板在未设置邮箱态下用固定 100x100 的 div 承载「加载失败 / 刷新」中文文案与按钮，宽高写死，中文比英文长时容易在 100px 内挤压或撑出容器。
  claim [conditional]: 步骤文案 `$t('hcp_devrsc_mail_reset_pwd_step1').replace('{0}', QrCodeMail)` 在 QrCodeMail 为空串时渲染成「…并将其发送至 」的截断句，是「未设置邮箱」态下的文案缺陷（i18n 未覆盖该状态）。
  claim [unverified]: 该面板的 scoped 样式挂在 `.el-dialog__wrapper` 祖先下再 :deep 到 `.set-password-dialog .el-dialog__body-wrapper` 去限制高度/滚动，但该祖先选择器是否命中取决于 hui el-dialog 的真实 DOM（弹窗通常挂到 body），未命中时 body 无宽度/溢出约束。
  claim [conditional]: 「获取二维码」按钮用 :min-width=105 / :max-width=480 这类行内属性控制宽度，中文按钮文案较英文长，且外层 flex 容器未设置 min-width:0 / width:100%，flex 子项默认不收缩，易把内容顶出弹窗。
  claim [conditional]: 本缺陷是文案国际化长度差异暴露的布局健壮性问题，而不是服务端数据/接口缺陷：模板中所有相关元素都在 reset-password-dialog.vue 的邮箱重置块内。
  question [blocking]: 两种「未设置邮箱」状态的模板分支不同，修复点不同；无法确定就修不准。; need 缺陷截图或 DOM 快照：显示邮箱重置区域中是否存在邮箱输入框、二维码图片、以及「加载失败/刷新」占位块。
  question [choice]: 修布局（自适应宽度/换行）与修文案（未设置邮箱时给专门提示）是两种方案，影响改动面与验收口径。; need 产品/UI 对「未设置邮箱」提示文案与按钮字号的期望；或确认仅需不溢出。
  question [verification]: 溢出属渲染行为，静态阅读无法定量证明。; need 在 10.33.43.25 环境按用例步骤复现后，取该弹窗的 computed width 与 scrollWidth 对比。
  remaining: 在 10.33.43.25 环境进入 服务器网络 → 在线设备发现，选中 1 台未激活且支持在线发现的设备，打开『重置设备密码』并将方式切到『邮箱重置』。
  remaining: 构造未设置邮箱的设备（服务端不返回 ServerMailboxAddr），分别在中/英文下打开该面板。
  remaining: DevTools 中检查 `.set-password-dialog .el-dialog__body-wrapper` 的 scrollWidth 与 clientWidth、以及 100x100 占位块内 span 的 offsetWidth，确认越界元素。
  remaining: 改后回归三态：已设置邮箱、未设置邮箱、二维码加载失败；同时验证『设置密保』弹窗未受影响。
- BGCM2026110303610: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 设备添加成功，ISUP接入显示正常
  cause: [Conditional / unverified] 编码设备添加页（src/Resource/components/DeviceBasicInfo.vue）中『接入协议』下方的 ONVIF 开启引导链接是从紧邻的 HPP 区块复制而来的，点击处理仍然指向 Hik-Partner Pro 站点接入页 `system_HikProConnectSites`，因此用户点击『开启 ONVIF』引导按钮时打开的是 HPP 站点页面而不是 ONVIF 配置页面。同时该链接的显示条件 `isShowOnvifProtocolTips` 复用了通用的 `disabledProtocolTip`（ISUP 未开启时也会被赋值），导致在 ISUP 协议添加流程里也出现这个 ONVIF 引导按钮，与用例实际观察场景吻合。
  claim [conditional]: ONVIF 引导链接的点击目标是 `system_HikProConnectSites`（HPP 站点接入页），而非任何 ONVIF 配置页。
  claim [supported]: 该 ONVIF 区块与其下方的 HPP 区块（第 90-94 行）使用完全相同的 `toRouterJump('system_HikProConnectSites')` 与相同文案 key，属复制粘贴遗留。
  claim [conditional]: 提示文案 hcp_devrsc_disable_onvif_tip 指向『到系统配置启用』，与该链接实际跳转的 HPP 站点页语义不符。
  claim [conditional]: EncoderAdd.initProtocolList 中 `disabledProtocolTip` 在 ISUP 未开启时也会被赋值，而 isShowOnvifProtocolTips 只判断 `disabledProtocolTip && !IsSupportOnvif`，且 IsSupportOnvif 仅在 SDK/ONVIF 协议下由 judgeOnvif 刷新，因此 ISUP 添加流程中可能错误展示 ONVIF 引导按钮。
  claim [supported]: 修复后可选目标页面之一为 System『设备接入协议配置』页，其存在『接入ONVIF协议』(label_enable_onvif) 开关，路由 name 为 DeviceAccessControl。
  claim [supported]: 另一可选目标为三方集成 ONVIF 网关页，页面标题取 hcp_integration_onvif_gateway，路由 name 为 OnvifGateway。
  question [choice]: 跳转目标页面存在两种合理解释，直接决定写入的 routerJump name（system_DeviceAccessControl 或 integration_OnvifGateway），是本次修复落点的关键分支。; need 产品/需求口径：『开启ONVIF』引导按钮的期望落地页；或同类产品中该按钮的既有实现截图
  question [verification]: 需确认现场按钮文案与代码中这条 btn-jump-link（文案为『前往配置』）是同一入口，否则可能还存在第二个未定位的按钮。; need 缺陷页面的按钮截图或 DOM 片段（含文案与 class）
  remaining: 静态核对：src/Resource/components/DeviceBasicInfo.vue 中 ONVIF 区块不再出现 'system_HikProConnectSites'，且 HPP 区块仍保留该跳转未受影响。
  remaining: 静态核对：isShowOnvifProtocolTips 不再直接依赖 disabledProtocolTip，EncoderAdd 传入的 ONVIF 未启用标志在 !supportOnvif 时才为 true。
  remaining: 手工回归：编码设备-添加，选择海康SDK/IP段且 ONVIF 未启用 → 点击引导按钮 → 落到约定的 ONVIF 配置页并可看到 ONVIF 开关。
  remaining: 手工回归：编码设备-添加，协议选择 ISUP → 协议提示区不应出现 ONVIF 引导按钮。
  remaining: 手工回归：HPP（Hik-Partner Pro）提示区的『前往配置』仍能正常跳到 HikProConnectSites。
  remaining: 可选静态检查：对改动文件执行 eslint（仓库 lint 脚本），确认无新增告警。
- BGCM2026110304123: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 热备组创建成功，主设备故障时切换备用
  cause: 编码设备「热备」页添加热备组时，下发协议期间的提示走的是 hui-intl 的 Message 组件且 type 固定为 'info'，而 Message 组件的图标映射表只包含 success/info/warning/error 四个静态反馈图标（无 loading 类型），因此提示条渲染的是静态 info 图标而非旋转 loading 图标；测试要求把该提示图标改成 loading。
  claim [supported]: 热备页「添加」按钮 → HotSpareForm 校验通过后 emit('save') → HotSpare.addHotSpare：先弹确认框，确认后调用 showMessageLoading() 再调 hotSpareAPI.addHotSpare
  claim [supported]: showMessageLoading() 调用 Message({ message, type: 'info', duration: 0, showClose: false })，因此提示条渲染的是 info 类型的静态 feedback 图标，没有 loading 动画
  claim [supported]: hui-intl 的 Message 组件 main.vue 中 typeMap 仅有 success/info/warning/error 四项，图标由 `h-icon-feedback_*_md` 给出；不存在 loading 类型，因此仅改 type 无法得到 loading 图标
  claim [supported]: Message 支持以 VNode 作为内容（main.js 检测 isVNode 后写入 vnodemessage，main.vue 用 `<component :is="vnodemessage" />` 渲染），因此可在提示内容里放 el-load-icon / h-an-icon-loading 动画图标而不改组件库
  claim [conditional]: el-load-icon（ElLoadIcon）在本仓各微应用中被直接使用且无局部 import（如 src/Broadcast/components/realTimeBroadcast/PlayDialog.vue:16、src/BI/view/components/export/exportingFileDialog.vue:12），说明其由 hui/hui-intl 插件全局注册，可直接在 VNode 中引用
  claim [supported]: 提示关闭时机在三条回调（success / errorResponse / error）与 beforeUnmount 兜底中均已覆盖，改为 loading 图标不改变关闭时机，无需改动请求层
  question [choice]: 「图标改成 loading」有两种落地：Message 内容内嵌 loading 图标（轻量、保持现有位置与文案），或改为 this.$loading() 全屏遮罩（与 RecordServerHotSpare.vue 一致）。选择不同会改变 targetFiles 与交互形态。; need 测试/产品确认：是否只要求提示条内图标为动画 loading，允许保留 Message 形态
  question [follow_up]: editHotSpare 与 syncPlatformToDevice 等热备操作未加任何下发中提示（仅 add 有），属同页面的不一致；本单未要求，仅记录避免顺手扩大改动。; need 同类缺陷在其他产品是否也要求 edit/sync 加 loading 提示
  remaining: 手工回归：编码设备 → 热备 → 添加，填完备机/主机后确认，观察提示条图标是否为旋转 loading、文案为「正在添加热备，请稍候...」
  remaining: 异常路径回归：构造 addHotSpare 返回 99999 + NVRErrorList，确认提示条关闭且失败详情弹窗正常；网络错误路径同样确认提示关闭
  remaining: 中途离开页面（beforeUnmount）确认提示不残留（右上角不再有常驻 Message）
  remaining: 静态检查：对改动文件跑 eslint / vue-tsc（若存在）
- BGCM2026110304635: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 远程配置跳转成功，可进入设备设置
  cause: [Conditional / unverified] 联动配置相关页面的写操作按钮（表单页『保存』、列表区『删除全部』/行内『删除』）都没有 loading 绑定：模板上未使用 el-button 的 :loading，脚本内也没有 submitLoading/deleting 之类的状态位。保存走 deviceAPI.setLinkageConfig（ISAPI PUT，最长 2 分钟超时），仅在 success 回调里提示并返回，失败时无任何复位；删除走 $confirm 后调 deviceAPI.deleteLinkageConfig，请求期间同样无反馈。公共 http 层已明确不再展示全局 loading（isapi.js showLoading 默认 false 且相关代码被注释），因此设备响应慢时按钮无任何进行中反馈，并可被重复点击触发重复下发。缺陷描述『按钮建议增加loading』即指此处缺失的按钮级 loading 状态。
  claim [supported]: 联动配置表单页（路由 accessLinkageConfigForm / elevatorLinkageConfigForm）的『保存』按钮未绑定任何 loading 属性，点击即触发 onSave。
  claim [supported]: 保存请求 deviceAPI.setLinkageConfig 只有 success 回调，没有 complete/error 分支，失败路径下按钮无状态可复位，请求期间也无进行中反馈。
  claim [supported]: 联动配置列表区（内嵌在远程配置页）的『删除全部』与行内『删除』按钮无 loading/禁用态；删除请求在 $confirm 之后发出，请求期间仍可再次点击。
  claim [supported]: 公共 http 层不提供全局 loading 兜底，故按钮自身是唯一可见反馈来源。
  claim [conditional]: 同目录既有约定做法是组件内维护 submitLoading 并绑定到主操作按钮（RemoteConfig.vue:1019/1977/2027-2042），本次缺失属于未遵循既有约定。
  claim [unverified]: 设备在线但响应慢时，无 loading 会导致重复点击重复下发联动配置（重复条目或并发写冲突）。
  question [choice]: 缺陷只写『联动配置页面按钮』未指明具体按钮，影响修复范围（仅表单页保存 vs 同时覆盖列表区删除按钮）。; need 缺陷单截图或验证人确认：缺 loading 的按钮是『保存』、『删除全部』、行内『删除』中的哪一个/哪些。
  question [verification]: 需确认是否存在功能性后果（重复提交产生重复联动配置），以决定是否同时加防重入保护而不只是视觉 loading。; need 在慢响应设备上连续点击保存/删除，观察后端联动配置条目数量是否异常增加。
  remaining: 静态检查：npx eslint src/Resource/components/remoteConfig/LinkageConfigForm.vue src/Resource/components/remoteConfig/LinkageConfig.vue
  remaining: 手动验证 A（保存）：设备列表 → 在线门禁设备 → 远程配置 → 联动配置 → 添加 → 保存；用慢响应/断网模拟，确认保存按钮出现 loading 且期间不可再次提交，失败后 loading 复位、按钮可再次点击。
  remaining: 手动验证 B（删除）：联动配置列表删除单条与『删除全部』，确认按钮进入 loading、请求结束后复位，且不会重复发出 DELETE 请求（Network 面板核对请求次数）。
  remaining: 回归：确认远程配置主页面保存按钮原有 submitLoading 行为不变，联动配置新增/编辑路由跳转不受影响。
- BGCM2026110304762: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 门禁设备列表正确展示(明眸/一体机/道闸/门禁主机)
  cause: [Conditional / unverified] 门禁设备列表的刷新入口是图标型 el-button（icon='icomoon-common_btn_refresh'），其禁用态只有按钮容器级的通用样式（如 .el-button.is-disabled{opacity:.4}），而共享主题 hui-intl 里按类型区分的禁用色规则使用 :not(.is-icon) 显式排除了图标按钮，且缺少『禁用按钮内 i 图标改色为 --c-ic-dis』的对应规则（该规则仅存在于 .el-input-number__increase/.el-decrease），Repository 主题 reset.less 也只写了 iconButton 的 hover/active 而未写禁用态。因此按钮本体进入 is-disabled 后图标字形颜色未被重置，视觉上仍为高亮。
  claim [supported]: 门禁设备列表为 src/Resource/view/access/AccessList.vue（Access.vue 只是 keep-alive 壳）。
  claim [supported]: 操作列刷新按钮是 icon-only 的 el-button（icon=icomoon-common_btn_refresh），禁用条件为 ProtocolTypeCategory===3，另有 :loading 与刷新中行联动。
  claim [conditional]: 工具栏『刷新』按钮由 DeviceRefreshPopover 渲染，其禁用只依赖 props.disabled，而 DeviceListActionBar 渲染 refresh-popover 时未传 disabled（默认 false）。
  claim [conditional]: 共享主题对图标按钮的禁用态缺少图标置灰规则：文本禁用色规则限定 .el-button.is-disabled.el-button--default:not(.is-icon)，而 .is-disabled i{color:var(--c-ic-dis)} 只出现在 .el-input-number 上下调整按钮上。
  claim [supported]: 仓库主题 src/Common/assets/less/theme/hcp/reset.less 对 .el-button--iconButton 只定义 hover/active:not(.is-disabled)，没有定义禁用态图标颜色，属于同一处样式缺口。
  question [choice]: 行内刷新图标按钮 与 工具栏『刷新』按钮 的禁用来源不同，决定修复落在 AccessList.vue 还是 DeviceRefreshPopover.vue/DeviceListActionBar.vue。; need 缺陷截图或复现说明，标明被置灰的是行内操作列图标还是工具栏『刷新』按钮
  question [verification]: 需要确认是哪条 CSS 让按钮变灰而图标不变，才能判定应改共享主题还是局部覆盖。; need 浏览器 DevTools 中被禁用按钮的 computed color/opacity 及命中规则（是否为 .el-button.is-disabled{opacity:.4} 或仓库内 !important 覆盖）
  remaining: 启动 portal 前端，进入 门禁设备管理 → 设备列表，构造一条 ProtocolTypeCategory===3 的门禁设备（刷新按钮为禁用态）。
  remaining: DevTools 选中该刷新按钮的 <i class="icomoon-common_btn_refresh">，记录 computed color 与命中规则，确认是否已应用 --c-ic-dis。
  remaining: 若修复落在 reset.less/deviceList.less：对比修复前后按钮与图标颜色是否同步变灰，并抽查 VideoIntercomList.vue、TicketBoxList.vue、VisitorTerminalList.vue 三处同类按钮无回归。
  remaining: 执行项目 lint（如 npm run lint）确认样式文件无语法错误。
- BGCM2026110303220: plan_only
  analysis: completed; actionability: {'allowed': False, 'reason': 'blocking question unresolved'}
  currentTarget: 1. 页面展示发现的设备列表，包含设备序列号、IP地址、端口、协议类型2. 列表中的设备与局域网实际设备一致3. 列表数量为1条4. 页面无报错提示
  cause: [Conditional / unverified] 缺陷报告的实际结果是“本地发现问答重置问题未翻译”，标题补充“本地发现和服务器网络都有问题”。本地发现与服务器发现的复位密码入口共用同一组件 src/Resource/components/sadp_detection/reset-password-dialog.vue（sadp-operation.vue 无论 isServerNetwork 真假都渲染该 Dialog），其“问答重置”区块靠 i18n key 拼装显示：题目正文走 questionOptions + getQuestionText 映射 hcp_devrsc_security_question_${n}，标签走 $t('hcp_devrsc_question_' + (i+1)) / $t('hcp_devrsc_answer_' + (i+1))。Resource 语言包只为 hcp_devrsc_security_question_1..15 与 hcp_devrsc_question_1..3 / hcp_devrsc_answer_1..3 提供了翻译；一旦设备（本地控件 arrayQuestion 或服务端 SecurityQuestionList）回传的 QuestionID 在 1..15 之外、类型不匹配（dwId 为字符串而 questionOptions.value 为 number，getQuestionText 用了严格 ===），或题目条目数超过 3，$t 就会按 Common/i18n/index.js 的兜底逻辑原样返回 key（或 getQuestionText 返回空串），页面呈现即为“未翻译/空白”。因此缺陷落在该共享弹框的问答渲染与语言包 key 覆盖上，而不是设备发现列表本身。
  claim [supported]: 本地发现与服务器发现的复位密码弹框是同一个组件，因此两侧出现同一现象符合“本地发现和服务器网络都有问题”的描述。
  claim [conditional]: 问答区块的题目正文由 getQuestionText 通过严格相等匹配 questionOptions（value 为数字 1..15）得到，匹配失败返回空串，即“未翻译/空白”。
  claim [conditional]: 问答区块的标签 key 只覆盖 hcp_devrsc_question_1..3 / hcp_devrsc_answer_1..3；当 SecurityQuestionList 长度大于 3 时 $t 会原样返回 key，页面显示未翻译的 key 字符串。
  claim [unverified]: i18n 兜底逻辑在找不到 key 时返回 key 本身（而非空），因此“未翻译”在 UI 上的主要形态是直接展示 hcp_devrsc_* 原始 key。
  claim [unverified]: 本地发现页存在真实的空翻译条目（如 en 语言包 hcp_devrsc_sadp_protocol 值为空串、hcp_devrsc_apply_loading 值为空串），属于同一 i18n 缺陷簇，但不是本缺陷 observed 所述“问答重置问题”的直接因果点。
  question [blocking]: “显示原始 key”与“显示空白”指向两条不同的修复路径（补语言包 vs 修 QuestionID 映射），直接决定修复目标位置。; need 缺陷现场截图或 DOM 文本：问答区域题目/标签的原始字符串
  question [verification]: 确认控件/服务端返回的 QuestionID 取值范围与类型，才能判定 getQuestionText 的严格相等是否失配。; need JS_GetSecurityQuestion 的 response.arrayQuestion（含 dwId、byMark）与服务端 SecurityQuestionList 原始响应
  question [choice]: 若问题数量可能超过 3 条，需要决定是扩充 hcp_devrsc_question_/answer_ 语言 key，还是改为复用 hcp_devrsc_security_question_ 序号标签。; need 产品确认问答重置最多可配置的密保问题条数
  remaining: 静态核对：确认 reset-password-dialog.vue 中 getQuestionText 的严格相等与 questionOptions.value 的类型约定，并列出 Resource 语言包里实际存在的 hcp_devrsc_question_N / hcp_devrsc_answer_N / hcp_devrsc_security_question_N 全部 key。
  remaining: 运行态：在英文环境进入本地网络发现页，对一台支持问答重置的在线设备点击重置密码，切到“Reset by Security Question”，记录题目正文与标签的实际渲染文本。
  remaining: 对照：切到服务器网络发现，对同类设备重复上述步骤，验证本地/服务端两套数据源（arrayQuestion.dwId vs SecurityQuestionList item）是否都出现未翻译。
  remaining: 验证修复：修复后重复上述两步，确认问答标题、题目正文、回答标签均为英文，且页面不出现任何 hcp_devrsc_* 原始 key。
